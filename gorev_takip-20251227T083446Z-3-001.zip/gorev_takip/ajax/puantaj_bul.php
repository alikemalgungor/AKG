<?php
// puantaj_bul.php

header("Content-Type: application/json");
session_start();

try {
    // DB Bağlantısını Dahil Et
    require_once "../config/db.php";
    $db_conn = $conn;

    $tc_no = $_SESSION["tc_no"] ?? "11111111111"; 

    $data = json_decode(file_get_contents("php://input"), true);
    $yil = $data['yil'] ?? null;
    $ay = $data['ay'] ?? null;

    if (!$yil || !$ay) {
        throw new Exception("Yıl veya ay bilgisi eksik.");
    }

    $tablo_aylik = "puantaj_aylik";
    $tablo_mahalle = "puantaj_mahalleler";

    // 1. Aylık puantaj özet bilgilerini ve GÖREV KODLARINI (gun1-gun31) puantaj_aylik tablosundan çek
    $stmt_aylik = $db_conn->prepare("SELECT * FROM $tablo_aylik WHERE tc_no=? AND yil=? AND ay=?");
    $stmt_aylik->execute([$tc_no, $yil, $ay]);
    $aylik = $stmt_aylik->fetch(PDO::FETCH_ASSOC);

    if (!$aylik) {
        echo json_encode(["status" => "error", "message" => "Seçilen aya ait puantaj kaydı bulunamadı."]);
        exit;
    }

    // 2. Mahalle verilerini puantaj_mahalleler tablosundan çek
    // MAHALLE METİNLERİ BURADAN GELİYOR (gun1, gun2, ... sütunlarından)
    $stmt_mahalle = $db_conn->prepare("SELECT * FROM $tablo_mahalle WHERE tc_no=? AND yil=? AND ay=?");
    $stmt_mahalle->execute([$tc_no, $yil, $ay]);
    $mahalle_kaydi = $stmt_mahalle->fetch(PDO::FETCH_ASSOC);


    // 3. Günlük görev ve mahalle verilerini JS'in okuyacağı 1'den 31'e kadar indeksli dizilere dönüştür
    $gunler = [];       
    $mahalleler = [];   

    for ($i = 1; $i <= 31; $i++) {
        // GÖREV KODU: puantaj_aylik tablosundan çekiliyor.
        $gunler[$i] = $aylik['gun' . $i] ?? '';
        
        // MAHALLE BİLGİSİ: puantaj_mahalleler tablosundan, 'gun' + $i sütunundan çekiliyor.
        $mahalleler[$i] = ($mahalle_kaydi && isset($mahalle_kaydi['gun' . $i])) 
            ? $mahalle_kaydi['gun' . $i] 
            : '';
    }
    
    // 4. Aylık özet verilerini, günlük dizilerle birleştir
    $response_data = array_merge($aylik, [
        "gunler" => $gunler, 
        "mahalleler" => $mahalleler 
    ]);
    
    // Güvenlik/Temizlik (gun1-gun31 sütunlarını ana çıktıdan kaldır)
    unset($response_data['id'], $response_data['tc_no'], $response_data['yil'], $response_data['ay']); 
    for ($i = 1; $i <= 31; $i++) {
         // puantaj_aylik'teki gunX sütunlarını kaldır
         unset($response_data['gun' . $i]); 
    }
    // Mahalle kaydındaki gunX sütunları zaten ana dizide yok.

    // Başarılı yanıtı döndür
    echo json_encode([
        "status" => "success",
        "data" => $response_data 
    ]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "DB hatası: Kayıtlar getirilemedi. Detay: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Sunucu hatası: " . $e->getMessage()]);
}
?>