<?php
header("Content-Type: application/json");
session_start();

// Hata ayıklama için geçici olarak açılabilir:
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

$tablo_aylik = "puantaj_aylik";
$tablo_mahalle = "puantaj_mahalleler";

try {
    // DB Bağlantısını Harici Dosyadan Al (PDO nesnesini kullanmak için)
    require_once "../config/db.php";
    $db_conn = $conn; // Varsayım: ../config/db.php dosyası $conn adında bir PDO nesnesi döndürüyor.

    if (!isset($_SESSION["tc_no"])) {
        throw new Exception("Oturum sona ermiş veya yetkisiz erişim!");
    }
    $tc_no = $_SESSION["tc_no"];

    $data = json_decode(file_get_contents("php://input"), true);
    
    // Gelen Veriler
    $yil = $data['yil'] ?? null;
    $ay = $data['ay'] ?? null;
    $gunler_kod = $data['gunler'] ?? [];
    $gunler_mahalle = $data['mahalleler'] ?? [];

    // Ek Veriler (Hata önlemek için ?? 0 eklendi)
    $toplam_kon_gor_puani = $data['toplam_kon_gor_puani'] ?? 0;
    $toplam_sofor_puani  = $data['toplam_sofor_puani'] ?? 0;
    $toplam_seyyar_gorev = $data['toplam_seyyar_gorev'] ?? 0;
    $toplam_arazi_gorev  = $data['toplam_arazi_gorev'] ?? 0;
    $toplam_aylik_puan = $data['toplam_aylik_puan'] ?? 0;

    // Temel Kontroller
    if (!$yil || !$ay || !is_numeric($yil) || !is_numeric($ay) || empty($gunler_kod)) {
        throw new Exception("Eksik veya geçersiz Yıl/Ay/Günler verisi.");
    }

    $parametreler_default = [$tc_no, $yil, $ay];
    
    // --- 1. puantaj_aylik (Kod/Puan) Kayıt İşlemi ---

    $stmt_kod = $db_conn->prepare("SELECT id FROM $tablo_aylik WHERE tc_no=? AND yil=? AND ay=?");
    $stmt_kod->execute($parametreler_default);
    $mevcut_kod = $stmt_kod->fetch(PDO::FETCH_ASSOC);

    $gunAlanlari = [];
    foreach ($gunler_kod as $i => $deger) $gunAlanlari[] = "gun" . ($i+1) . "=?";

    $aylik_veriler = [
        $toplam_kon_gor_puani, $toplam_sofor_puani, $toplam_seyyar_gorev, 
        $toplam_arazi_gorev, $toplam_aylik_puan
    ];

    if ($mevcut_kod) {
        // UPDATE
        $sql = "UPDATE $tablo_aylik SET " . implode(",", $gunAlanlari) . ",
                toplam_kon_gor_puani=?, toplam_sofor_puani=?, toplam_seyyar_gorev=?,
                toplam_arazi_gorev=?, toplam_aylik_puan=?, kayit_tarihi=NOW() WHERE id=?";
        $stmt = $db_conn->prepare($sql);
        $stmt->execute(array_merge(
            $gunler_kod, $aylik_veriler, [$mevcut_kod['id']]
        ));
    } else {
        // INSERT
        // PHP 7.3 uyumluluğu için arrow function yerine foreach kullandık
        $alanlar = [];
        foreach (array_keys($gunler_kod) as $i) $alanlar[] = "gun".($i+1);
        
        $alanlar = array_merge($alanlar, [
            "tc_no","yil","ay",
            "toplam_kon_gor_puani","toplam_sofor_puani",
            "toplam_seyyar_gorev","toplam_arazi_gorev","toplam_aylik_puan","kayit_tarihi"
        ]);
        $soruIsaretleri = array_fill(0, count($gunler_kod) + 8, "?"); // 8 parametre + gün sayısı
        $sql = "INSERT INTO $tablo_aylik (".implode(",",$alanlar).") 
                VALUES (".implode(",",$soruIsaretleri).", NOW())"; // NOW() soru işareti değil
        
        $stmt = $db_conn->prepare($sql);
        $stmt->execute(array_merge(
            $gunler_kod, $parametreler_default, $aylik_veriler
        ));
    }

    // --- 2. puantaj_mahalleler (Mahalle Kaydı) İşlemi ---

    // Sadece mahalle bilgisi olan günler için işlem yap
    if (!empty(array_filter($gunler_mahalle))) {
        $stmt_mahalle = $db_conn->prepare("SELECT id FROM $tablo_mahalle WHERE tc_no=? AND yil=? AND ay=?");
        $stmt_mahalle->execute($parametreler_default);
        $mevcut_mahalle = $stmt_mahalle->fetch(PDO::FETCH_ASSOC);

        $gunAlanlari_mahalle = [];
        foreach ($gunler_mahalle as $i => $v) $gunAlanlari_mahalle[] = "gun" . ($i+1) . "=?";
        
        if ($mevcut_mahalle) {
            // UPDATE
            $sql = "UPDATE $tablo_mahalle SET ".implode(",", $gunAlanlari_mahalle).", kayit_tarihi=NOW() WHERE id=?";
            $stmt = $db_conn->prepare($sql);
            $stmt->execute(array_merge($gunler_mahalle, [$mevcut_mahalle['id']]));
        } else {
            // INSERT
            $mahalle_alanlar = [];
            foreach (array_keys($gunler_mahalle) as $i) $mahalle_alanlar[] = "gun".($i+1);

            $mahalle_alanlar = array_merge($mahalle_alanlar, ["tc_no","yil","ay","kayit_tarihi"]);
            $soruIsaretleri_mahalle = array_fill(0, count($gunler_mahalle) + 3, "?"); 
            
            $sql = "INSERT INTO $tablo_mahalle (".implode(",", $mahalle_alanlar).") 
                    VALUES (".implode(",", $soruIsaretleri_mahalle).", NOW())";
            $stmt = $db_conn->prepare($sql);
            $stmt->execute(array_merge($gunler_mahalle, $parametreler_default));
        }
    }
    
    $mesaj = "Puantaj ve Mahalle kayıtları başarıyla tamamlandı.";
    echo json_encode(["status"=>"success","message"=>$mesaj]);

} catch (PDOException $e) {
    echo json_encode(["status"=>"error","message"=>"DB hatası: ".$e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status"=>"error","message"=>"Sunucu hatası: ".$e->getMessage()]);
}
?>