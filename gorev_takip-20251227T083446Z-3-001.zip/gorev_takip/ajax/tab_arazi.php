<?php
// ajax/tab_arazi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include_once '../config/db.php';

$birim_id = $_SESSION['birim_id'] ?? 0;
$user_id  = $_SESSION['user_id'];
$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$secili_ay = isset($_GET['ay']) ? intval($_GET['ay']) : date('m');

// YETKİ KONTROLÜ
$yetkili_birimler = [2]; 
if (!in_array($birim_id, $yetkili_birimler)) {
    exit('<div class="alert alert-danger m-3"><i class="fas fa-lock me-2"></i> Bu sekmeye erişim yetkiniz bulunmamaktadır.</div>');
}

// 1. DÖNEM HESAPLAMA
if ($secili_ay <= 3) { $bas_ay = 1; $bit_ay = 3; $donem_ad = "1. ÇEYREK (OCAK - ŞUBAT - MART)"; }
elseif ($secili_ay <= 6) { $bas_ay = 4; $bit_ay = 6; $donem_ad = "2. ÇEYREK (NİSAN - MAYIS - HAZİRAN)"; }
elseif ($secili_ay <= 9) { $bas_ay = 7; $bit_ay = 9; $donem_ad = "3. ÇEYREK (TEMMUZ - AĞUSTOS - EYLÜL)"; }
else { $bas_ay = 10; $bit_ay = 12; $donem_ad = "4. ÇEYREK (EKİM - KASIM - ARALIK)"; }

// 2. GÖREV TÜRLERİNİ ÇEK (DB'den)
$gt_sql = "SELECT id, ad, varsayilan_aciklama FROM gorev_turleri WHERE (birim_id = ? OR birim_id = 0) AND aktif = 1 AND yer_turu = 'arazi' ORDER BY ad ASC";
$stmt_gt = $pdo->prepare($gt_sql);
$stmt_gt->execute([$birim_id]);
$gorev_turleri_db = $stmt_gt->fetchAll(PDO::FETCH_ASSOC);

// 3. PUANTAJ VERİLERİNİ ÇEK
$sql = "SELECT p.*, m.gun1 as m1, m.gun2 as m2, m.gun3 as m3, m.gun4 as m4, m.gun5 as m5, m.gun6 as m6, m.gun7 as m7, m.gun8 as m8, m.gun9 as m9, m.gun10 as m10, m.gun11 as m11, m.gun12 as m12, m.gun13 as m13, m.gun14 as m14, m.gun15 as m15, m.gun16 as m16, m.gun17 as m17, m.gun18 as m18, m.gun19 as m19, m.gun20 as m20, m.gun21 as m21, m.gun22 as m22, m.gun23 as m23, m.gun24 as m24, m.gun25 as m25, m.gun26 as m26, m.gun27 as m27, m.gun28 as m28, m.gun29 as m29, m.gun30 as m30, m.gun31 as m31 
        FROM puantaj_aylik p 
        LEFT JOIN puantaj_mahalleler m ON p.personel_id = m.personel_id AND p.yil = m.yil AND p.ay = m.ay 
        WHERE p.personel_id = ? AND p.yil = ? AND p.ay BETWEEN ? AND ? ORDER BY p.ay ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$raw_puantaj = $stmt->fetchAll(PDO::FETCH_ASSOC);

$puantaj_verileri = [];
$arazi_kilitli_mi = false; // Varsayılan açık

foreach($raw_puantaj as $rp) { 
    $puantaj_verileri[$rp['ay']] = $rp; 
    // Sadece seçili ayın kilit durumuna bakıyoruz
    if($rp['ay'] == $secili_ay) {
        if(($rp['kilit_arazi'] ?? '') == 'Kilitli') {
            $arazi_kilitli_mi = true;
        }
    }
}

// 4. DETAYLARI ÇEK
$stmt_detay = $pdo->prepare("SELECT * FROM arazi_tazminati_detay WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ?");
$stmt_detay->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$kayitli_detaylar_raw = $stmt_detay->fetchAll(PDO::FETCH_ASSOC);
$detay_map = [];
foreach($kayitli_detaylar_raw as $d) { 
    $detay_map[$d['ay']][$d['gun']] = [
        'aciklama' => $d['aciklama'],
        'gorev_turu_id' => $d['gorev_turu_id']
    ]; 
}

$arazi_kodlari = ["AT", "AK", "AS", "AKS", "Arazi Tazminatı", "Arazi + Kontrol", "Arazi + Seyyar", "Arazi + Kontrol + Seyyar"];
$listelenecek = [];

for ($a = $bas_ay; $a <= $bit_ay; $a++) {
    if (!isset($puantaj_verileri[$a])) continue;
    $ay_kilitli = (($puantaj_verileri[$a]['kilit_arazi'] ?? '') == 'Kilitli');
    
    for ($g = 1; $g <= 31; $g++) {
        $kod = trim($puantaj_verileri[$a]['gun'.$g] ?? '');
        if (in_array($kod, $arazi_kodlari)) {
            $ts = strtotime("$yil-$a-$g");
            $listelenecek[] = [
                'ay' => $a, 'gun' => $g,
                'tarih' => sprintf("%02d.%02d.%04d", $g, $a, $yil),
                'gun_ad' => ($ts) ? ['Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi','Pazar'][date('N', $ts)-1] : "",
                'mahalle' => $puantaj_verileri[$a]['m'.$g] ?? '',
                'aciklama' => $detay_map[$a][$g]['aciklama'] ?? '',
                'gorev_turu_id' => $detay_map[$a][$g]['gorev_turu_id'] ?? '',
                'kilit' => $ay_kilitli 
            ];
        }
    }
}
?>

<style>
    .arazi-table { table-layout: fixed; width: 100%; border-collapse: collapse; }
    .col-ay      { width: 90px; } 
    .col-tarih   { width: 100px; } 
    .col-mahalle { width: 140px; } 
    .col-islem   { width: 220px; } 
    .col-aciklama { width: auto; }

    .arazi-table thead th { background: #f8f9fa; color: #333; font-weight: 600; font-size: 11px; padding: 10px 5px; text-transform: uppercase; }
    .arazi-table td { font-size: 13px; vertical-align: middle; padding: 5px; }
    
    .arazi-input { width: 100% !important; display: block; }
    
    .month-divider {
        background: #ced4da !important;
        color: #000 !important;
        font-weight: bold !important;
        font-size: 13px !important;
        padding: 8px 10px !important;
        border-top: 2px solid #6c757d !important;
    }
</style>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="mb-0 fw-bold text-primary"><i class="fas fa-tractor me-2"></i>Arazi Tazminatı Cetveli (<?php echo $donem_ad; ?>)</h6>
        <div class="d-flex gap-2 align-items-center">
            <?php if(!$arazi_kilitli_mi): ?>
                <button type="button" class="btn btn-sm btn-outline-warning text-dark fw-bold" onclick="araziHizliDoldur()">
                    <i class="fas fa-magic"></i> Hızlı Doldur
                </button>
                <span class="badge bg-success p-2"><i class="fas fa-pen"></i> DÜZENLEMEYE AÇIK</span>
            <?php else: ?>
                <span class="badge bg-danger p-2"><i class="fas fa-lock"></i> ARAZİ KAYITLARI KİLİTLİ</span>
                <button class="btn btn-sm btn-dark" onclick="window.open('../pages/yazdir_arazi.php?yil=<?=$yil?>&ay=<?=$secili_ay?>','_blank')">
                    <i class="fas fa-print"></i> YAZDIR
                </button>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card-body p-0">
        <?php if(empty($listelenecek)): ?>
            <div class="text-center p-5 text-muted">Takvimde arazi kodu bulunamadı.</div>
        <?php else: ?>
            <form id="formAraziDetay">
                <input type="hidden" name="action" value="arazi_detay_kaydet"> <input type="hidden" name="yil" value="<?php echo $yil; ?>">
                
                <table class="table table-bordered arazi-table mb-0">
                    <thead>
                        <tr class="text-center">
                            <th class="col-ay">Ay</th>
                            <th class="col-tarih">Tarih</th>
                            <th class="col-mahalle">Mahalle</th>
                            <th class="col-islem">Görev Türü</th>
                            <th class="col-aciklama">Yapılan Hizmet / Açıklama</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $current_month = 0; $aylar = ["", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK"];
                        foreach($listelenecek as $l): 
                            if($current_month != $l['ay']):
                                $current_month = $l['ay'];
                                echo '<tr><td colspan="5" class="month-divider">'.$aylar[$l['ay']].'</td></tr>';
                            endif;
                        ?>
                        <tr class="satir-arazi <?php echo $l['kilit'] ? 'table-light text-muted' : ''; ?>" data-mahalle="<?php echo $l['mahalle']; ?>">
                            <td class="text-center small fw-bold"><?php echo $aylar[$l['ay']]; ?></td>
                            <td class="text-center small"><?php echo $l['tarih']; ?><br><small><?php echo $l['gun_ad']; ?></small></td>
                            <td class="text-center small text-primary fw-bold"><?php echo $l['mahalle']; ?></td>
                            <td>
                                <select name="detay[<?php echo $l['ay']; ?>][<?php echo $l['gun']; ?>][gorev_turu]" class="form-select form-select-sm arazi-islem-select" <?php echo $l['kilit'] ? 'disabled' : ''; ?>>
                                    <option value="">Seçiniz...</option>
                                    <?php foreach($gorev_turleri_db as $gt): ?>
                                        <option value="<?php echo $gt['id']; ?>" 
                                                data-aciklama="<?php echo htmlspecialchars($gt['varsayilan_aciklama']); ?>"
                                                <?php echo ($l['gorev_turu_id'] == $gt['id']) ? 'selected' : ''; ?>>
                                            <?php echo $gt['ad']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="detay[<?php echo $l['ay']; ?>][<?php echo $l['gun']; ?>][aciklama]" 
                                       class="form-control form-control-sm arazi-input" 
                                       value="<?php echo htmlspecialchars($l['aciklama']); ?>"
                                       <?php echo $l['kilit'] ? 'readonly disabled' : ''; ?>>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if(!$arazi_kilitli_mi): ?>
                <div class="card-footer bg-light d-flex justify-content-end p-3 gap-2">
                    <button type="button" class="btn btn-primary btn-sm fw-bold px-4" onclick="kaydetVeKilitleArazi()">
                        <i class="fas fa-check-double me-1"></i> ONAYLA VE YAZDIR
                    </button>
                </div>
                <?php endif; ?>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
// Select değişince açıklamayı otomatik doldur
$(document).on('change', '.arazi-islem-select', function() {
    let row = $(this).closest('tr');
    let mahalle = row.data('mahalle');
    let secilenOpt = $('option:selected', this);
    let aciklama = secilenOpt.data('aciklama');
    
    if (aciklama) {
        if(aciklama.includes("{mahalle}")) {
            aciklama = aciklama.replace("{mahalle}", mahalle);
        } else {
            // Mahalle ismini Baş Harfi Büyük hale getirelim (Görsel amaçlı)
            let duzgunMahalle = mahalle.charAt(0).toUpperCase() + mahalle.slice(1).toLowerCase();
            aciklama = duzgunMahalle + " mahallesinde " + aciklama;
        }
        row.find('.arazi-input').val(aciklama);
    }
});

// HIZLI DOLDUR FONKSİYONU
function araziHizliDoldur() {
    if(!confirm("Boş alanlar varsayılan değerlerle doldurulsun mu?")) return;

    let aranacakKelime = "Mera Arazi Kontrol"; 

    $('.satir-arazi').each(function() {
        let sel = $(this).find('.arazi-islem-select');
        
        if(sel.val() === "" && !sel.prop('disabled')) {
            let bulunanOption = sel.find("option").filter(function() {
                return $(this).text().indexOf(aranacakKelime) > -1;
            });

            if(bulunanOption.length > 0) {
                sel.val(bulunanOption.val()).trigger('change');
            } else {
                sel.prop('selectedIndex', 1).trigger('change');
            }
        }
    });
}

// ONAYLA VE KİLİTLE FONKSİYONU (Düzeltildi: Tüm dönemi kaydeder)
function kaydetVeKilitleArazi() {
    let bosVar = false;
    $('.arazi-input').each(function() {
        if($(this).val().trim() === "" && !$(this).prop('disabled')) {
            $(this).addClass('is-invalid');
            bosVar = true;
        } else {
            $(this).removeClass('is-invalid');
        }
    });

    if(bosVar) { 
        alert("⚠️ Lütfen boş bırakılan alanları doldurunuz!"); 
        return; 
    }
    
    if(!confirm("DİKKAT! Bu işlemi onayladığınızda <?=$donem_ad?> dönemine ait ARAZİ verileri kilitlenecektir.\nDevam edilsin mi?")) return;

    let btn = $('.btn-primary');
    btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Onaylanıyor...');

    // URL AYARI
    let ajaxUrl = "ajax/ajax_puantaj_islem.php";
    if(window.location.href.indexOf("/pages/") > -1) { ajaxUrl = "../ajax/ajax_puantaj_islem.php"; }

    // 1. TÜM FORM VERİLERİNİ KAYDET
    // Formun içinde zaten tüm ayların (bas_ay'dan bit_ay'a kadar) inputları var.
    // Serialize edildiğinde hepsi backend'e gider.
    $.post(ajaxUrl, $('#formAraziDetay').serialize(), function(res) {
        if(res.status == 'success') {
            
            // 2. KİLİTLEME İŞLEMİ (TÜM DÖNEMİ KİLİTLE)
            // 'ay' parametresini göndermiyoruz, onun yerine aralık gönderiyoruz.
            $.post(ajaxUrl, {
                action: 'arazi_kilitle',
                yil: '<?=$yil?>', 
                // BURASI ÖNEMLİ: Sadece seçili ayı değil, dönemi kilitliyoruz.
                bas_ay: '<?=$bas_ay?>',
                bit_ay: '<?=$bit_ay?>'
            }, function(resKilit) {
                if(resKilit.status == 'success') {
                    
                    // Yazdır sayfasını aç
                    let printUrl = "pages/yazdir_arazi.php";
                    if(window.location.href.indexOf("/pages/") > -1) { printUrl = "yazdir_arazi.php"; } else { printUrl = "pages/yazdir_arazi.php"; }
                    
                    window.open(printUrl + '?yil=<?=$yil?>&ay=<?=$secili_ay?>', '_blank');
                    
                    if(typeof loadTabContent === 'function') {
                        loadTabContent('arazi');
                    } else {
                        location.reload();
                    }
                } else {
                    alert("❌ Kilitleme hatası: " + resKilit.message);
                    btn.prop('disabled', false).html('<i class="fas fa-check-double me-1"></i> ONAYLA VE YAZDIR');
                }
            }, 'json');
        } else {
            alert("❌ Kayıt hatası: " + res.message);
            btn.prop('disabled', false).html('<i class="fas fa-check-double me-1"></i> ONAYLA VE YAZDIR');
        }
    }, 'json').fail(function() {
        alert("Sunucu hatası! Dosya yolu kontrol ediniz.");
        btn.prop('disabled', false).html('<i class="fas fa-check-double me-1"></i> ONAYLA VE YAZDIR');
    });
}
</script>