<?php
require __DIR__ . '/../config/db.php';
session_start();
header('Content-Type: application/json');

$tc = $_SESSION["tc_no"] ?? null;
if (!$tc) {
    echo json_encode(["error" => "no_tc"]);
    exit;
}

$yil = isset($_GET['yil']) ? (int)$_GET['yil'] : (int)date('Y');
$ay  = isset($_GET['ay'])  ? (int)$_GET['ay']  : (int)date('m');

$output = [
    "gun_arac"     => [],
    "gun_arac_tur" => [],
    "gun_izin"     => [],
    "gun_rtatil"   => [],
    "birim"        => "",
    "soforluk"     => false,
];

/* ---------------------------------------------------
   1) PERSONEL
--------------------------------------------------- */
$q = $pdo->prepare("
    SELECT pb.id, b.birim_adi
    FROM personel_bilgileri pb
    LEFT JOIN birimler b ON pb.birimler_id = b.id
    WHERE pb.tc_no = :tc
    LIMIT 1
");
$q->execute([":tc"=>$tc]);
$person = $q->fetch(PDO::FETCH_ASSOC);

if (!$person) {
    echo json_encode(["error"=>"personel_yok"]);
    exit;
}

$personel_id   = (int)$person["id"];
$output["birim"] = $person["birim_adi"] ?? "";

/* ---------------------------------------------------
   2) NORMAL ARAÇ GÖREVLERİ (ONAYLI)
--------------------------------------------------- */
$sql = "
SELECT 
    ag.tarih,
    m.ad AS mahalle,
    m.gorev_turu,
    ag.sofor_id
FROM arac_gorevler ag
JOIN arac_gorev_personel ap ON ag.id = ap.gorev_id
LEFT JOIN arac_gorev_mahalle agm ON ag.id = agm.gorev_id
LEFT JOIN mahalleler m ON agm.mahalleler_id = m.id
WHERE ap.personel_id = :pid
  AND ag.onay_durumu = 1
  AND YEAR(ag.tarih) = :yil
  AND MONTH(ag.tarih) = :ay
ORDER BY ag.tarih
";

$s = $pdo->prepare($sql);
$s->execute([
    ":pid" => $personel_id,
    ":yil" => $yil,
    ":ay"  => $ay
]);

foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
    if (empty($r["tarih"]) || empty($r["mahalle"])) continue;

    $g = (int)date("j", strtotime($r["tarih"]));

    $output["gun_arac"][$g][]     = $r["mahalle"];
    $output["gun_arac_tur"][$g][] = $r["gorev_turu"] ?? "";

    if ((int)$r["sofor_id"] === $personel_id) {
        $output["soforluk"] = true;
    }
}

/* ---------------------------------------------------
   3) ÖZEL ARAÇ GÖREVLERİ (ONAYLI)
--------------------------------------------------- */
$sql = "
SELECT 
    oag.gorev_tarihi AS tarih,
    m.ad AS mahalle,
    m.gorev_turu
FROM ozel_arac_gorevler oag
LEFT JOIN mahalleler m ON oag.mahalle_id = m.id
WHERE oag.gorevli_personel_id = :pid
  AND oag.onay_durumu = 1
  AND YEAR(oag.gorev_tarihi) = :yil
  AND MONTH(oag.gorev_tarihi) = :ay
ORDER BY oag.gorev_tarihi
";

$s = $pdo->prepare($sql);
$s->execute([
    ":pid" => $personel_id,
    ":yil" => $yil,
    ":ay"  => $ay
]);

foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $r) {
    if (empty($r["tarih"]) || empty($r["mahalle"])) continue;

    $g = (int)date("j", strtotime($r["tarih"]));

    $output["gun_arac"][$g][]     = $r["mahalle"];
    $output["gun_arac_tur"][$g][] = $r["gorev_turu"] ?? "";
}

/* ---------------------------------------------------
   4) İZİNLER
--------------------------------------------------- */
$q = $pdo->prepare("
    SELECT izin_baslangic, izin_bitis
    FROM personel_izin
    WHERE personel_id = :pid
      AND izin_baslangic <= LAST_DAY(:ym)
      AND izin_bitis >= :ym
");

$ym = sprintf("%04d-%02d-01", $yil, $ay);
$q->execute([":pid"=>$personel_id, ":ym"=>$ym]);

foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $bas = strtotime($r["izin_baslangic"]);
    $bit = strtotime($r["izin_bitis"]);
    for ($d=$bas; $d<=$bit; $d+=86400) {
        if ((int)date("Y",$d)===$yil && (int)date("n",$d)===$ay) {
            $output["gun_izin"][(int)date("j",$d)] = true;
        }
    }
}

/* ---------------------------------------------------
   5) RESMİ TATİLLER
--------------------------------------------------- */
$q = $pdo->prepare("
    SELECT tarih
    FROM resmi_tatil_gunleri
    WHERE YEAR(tarih)=:yil AND MONTH(tarih)=:ay
");
$q->execute([":yil"=>$yil, ":ay"=>$ay]);

foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $output["gun_rtatil"][(int)date("j", strtotime($r["tarih"]))] = true;
}

/* ---------------------------------------------------
   JSON ÇIKIŞ
--------------------------------------------------- */
echo json_encode($output, JSON_UNESCAPED_UNICODE);
