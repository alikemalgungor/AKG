<?php
// ajax/ajax_izin_islem.php
session_start();
header('Content-Type: application/json');
include_once '../config/db.php';

ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Oturum kapalı.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$rol_id  = isset($_SESSION['rol_id']) ? $_SESSION['rol_id'] : 0;
$yonetici_mi = in_array($rol_id, [1, 2]);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    try {
        // --- 0. BAKİYE SORGULA ---
        if ($action === 'bakiye_getir') {
            if (!$yonetici_mi) throw new Exception("Yetkiniz yok.");
            $pid = (int)$_POST['personel_id'];
            $bakiye = $pdo->query("SELECT toplam_izin FROM personel_bilgileri WHERE id = $pid")->fetchColumn();
            echo json_encode(['status' => 'success', 'bakiye' => $bakiye ?: 0]);
            exit;
        }

        // --- 1. KAYDET / GÜNCELLE ---
        if ($action === 'kaydet') {
            if (!$yonetici_mi) throw new Exception("Yetkisiz işlem.");

            $izin_id = !empty($_POST['izin_id']) ? (int)$_POST['izin_id'] : 0;
            
            $hedef_personel_id = (int)$_POST['personel_id'];
            $baslangic = $_POST['izin_baslangic'];
            $bitis     = $_POST['izin_bitis'];
            $sebep_id  = (int)$_POST['sebep_id'];
            $aciklama_id = !empty($_POST['aciklama_id']) ? (int)$_POST['aciklama_id'] : NULL;

            if ($hedef_personel_id <= 0) throw new Exception("Personel seçilmelidir.");
            if (empty($baslangic) || empty($bitis)) throw new Exception("Tarihleri giriniz.");
            
            $d1 = new DateTime($baslangic);
            $d2 = new DateTime($bitis);
            if ($d1 > $d2) throw new Exception("Başlangıç tarihi bitişten büyük olamaz.");
            $gun_farki = $d1->diff($d2)->days + 1;
            
            $yil = $d1->format('Y');
            $ay  = $d1->format('n');

            // *** YENİ EKLENEN KISIM: TARİH ÇAKIŞMA KONTROLÜ ***
            // Mantık: (YeniBaslangic <= EskiBitis) VE (YeniBitis >= EskiBaslangic) ise çakışma vardır.
            // Ayrıca kendi ID'mizi hariç tutuyoruz (Update işlemi için).
            $sql_cakisma = "SELECT count(*) FROM personel_izin 
                            WHERE personel_id = ? 
                            AND id != ? 
                            AND izin_baslangic <= ? 
                            AND izin_bitis >= ?";
            
            $stmt_check = $pdo->prepare($sql_cakisma);
            $stmt_check->execute([$hedef_personel_id, $izin_id, $bitis, $baslangic]);
            $cakisma_sayisi = $stmt_check->fetchColumn();

            if ($cakisma_sayisi > 0) {
                throw new Exception("HATA: Bu personelin belirtilen tarihlerde zaten kayıtlı bir izni var! Lütfen tarihleri kontrol ediniz.");
            }
            // *** ÇAKIŞMA KONTROLÜ BİTTİ ***

            // Yıllık İzin Kontrolü (İsimden Anlama)
            $sebep_adi = $pdo->query("SELECT sebep_adi FROM izin_sebepleri WHERE id = $sebep_id")->fetchColumn();
            $yillik_izin_mi = (stripos($sebep_adi, 'yıllık') !== false || stripos($sebep_adi, 'yillik') !== false);

            $pdo->beginTransaction();

            if ($izin_id > 0) {
                // GÜNCELLEME
                // Eski bakiyeyi iade et (Eğer yıllık ise)
                $eski_kayit = $pdo->query("SELECT * FROM personel_izin WHERE id=$izin_id")->fetch(PDO::FETCH_ASSOC);
                $eski_sebep = $pdo->query("SELECT sebep_adi FROM izin_sebepleri WHERE id={$eski_kayit['sebep_id']}")->fetchColumn();
                if (stripos($eski_sebep, 'yıllık') !== false) {
                    $pdo->prepare("UPDATE personel_bilgileri SET toplam_izin = toplam_izin + ? WHERE id = ?")->execute([$eski_kayit['gun_sayisi'], $eski_kayit['personel_id']]);
                }

                // Yeni bakiyeyi düş (Eğer yıllık ise)
                if ($yillik_izin_mi) {
                    $bakiye = $pdo->query("SELECT toplam_izin FROM personel_bilgileri WHERE id=$hedef_personel_id")->fetchColumn();
                    if ($bakiye < $gun_farki) { $pdo->rollBack(); throw new Exception("Yetersiz Bakiye! Kalan: $bakiye"); }
                    $pdo->prepare("UPDATE personel_bilgileri SET toplam_izin = toplam_izin - ? WHERE id = ?")->execute([$gun_farki, $hedef_personel_id]);
                }

                $sql = "UPDATE personel_izin SET personel_id=?, izin_baslangic=?, izin_bitis=?, gun_sayisi=?, sebep_id=?, aciklama_id=?, yil=?, ay=? WHERE id=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$hedef_personel_id, $baslangic, $bitis, $gun_farki, $sebep_id, $aciklama_id, $yil, $ay, $izin_id]);
                $msg = "Güncellendi.";

            } else {
                // YENİ KAYIT
                if ($yillik_izin_mi) {
                    $bakiye = $pdo->query("SELECT toplam_izin FROM personel_bilgileri WHERE id=$hedef_personel_id")->fetchColumn();
                    if ($bakiye < $gun_farki) { $pdo->rollBack(); throw new Exception("Yetersiz Bakiye! Kalan: $bakiye"); }
                    $pdo->prepare("UPDATE personel_bilgileri SET toplam_izin = toplam_izin - ? WHERE id = ?")->execute([$gun_farki, $hedef_personel_id]);
                }

                $stmt_no = $pdo->prepare("SELECT MAX(sira_no) FROM personel_izin WHERE yil = ?");
                $stmt_no->execute([$yil]);
                $yeni_sira = ($stmt_no->fetchColumn() ?: 0) + 1;

                $sql = "INSERT INTO personel_izin (sira_no, yil, ay, personel_id, izin_baslangic, izin_bitis, gun_sayisi, sebep_id, aciklama_id) VALUES (?,?,?,?,?,?,?,?,?)";
                $pdo->prepare($sql)->execute([$yeni_sira, $yil, $ay, $hedef_personel_id, $baslangic, $bitis, $gun_farki, $sebep_id, $aciklama_id]);
                $msg = "Kaydedildi.";
            }

            $pdo->commit();
            echo json_encode(['status' => 'success', 'message' => $msg]);
        }

        // --- 2. SİL ---
        elseif ($action === 'sil') {
            if (!$yonetici_mi) throw new Exception("Yetkisiz.");
            $id = (int)$_POST['id'];
            $pdo->beginTransaction();
            
            $kayit = $pdo->query("SELECT * FROM personel_izin WHERE id=$id")->fetch(PDO::FETCH_ASSOC);
            $sebep = $pdo->query("SELECT sebep_adi FROM izin_sebepleri WHERE id={$kayit['sebep_id']}")->fetchColumn();
            
            if (stripos($sebep, 'yıllık') !== false) {
                $pdo->prepare("UPDATE personel_bilgileri SET toplam_izin = toplam_izin + ? WHERE id = ?")->execute([$kayit['gun_sayisi'], $kayit['personel_id']]);
            }
            
            $pdo->prepare("DELETE FROM personel_izin WHERE id=?")->execute([$id]);
            $pdo->commit();
            echo json_encode(['status' => 'success', 'message' => 'Silindi.']);
        }

        // --- 3. DETAY ---
        elseif ($action === 'detay_getir') {
            $id = (int)$_POST['id'];
            $data = $pdo->query("SELECT * FROM personel_izin WHERE id = $id")->fetch(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'success', 'data' => $data]);
        }

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>