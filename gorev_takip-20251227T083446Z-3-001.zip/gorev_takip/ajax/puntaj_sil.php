<?php
// Geçici olarak hata raporlamayı kapatalım ki JSON çıktısını bozmasın
ini_set('display_errors', 0); 
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
session_start();

// Tablo İsimleri
$tablo_aylik = "puantaj_aylik";         // Ana puantaj tablosu
$tablo_mahalle = "puantaj_mahalleler";  // Bağlı mahalle detay tablosu

try {
    // DB Bağlantısını Dahil Et
    // Varsayım: ../config/db.php dosyası $conn adında bir PDO nesnesi döndürüyor.
    require_once "../config/db.php";
    $db_conn = $conn; 

    // 1. Oturum Kontrolü
    if (!isset($_SESSION["tc_no"])) {
        throw new Exception("Oturum sona ermiş veya yetkisiz erişim!");
    }
    $tc_no = $_SESSION["tc_no"];

    // 2. JSON Verisini Al ve Kontrol Et
    $data = json_decode(file_get_contents("php://input"), true);
    $yil = $data['yil'] ?? null;
    $ay = $data['ay'] ?? null;

    if (!$yil || !$ay) {
        throw new Exception("Eksik veya geçersiz Yıl/Ay verisi.");
    }
    
    // --- 3. İki Tablodan Aynı Anda Silme İşlemi ---
    
    // A) Ana Puantaj Kaydını Sil (puantaj_aylik)
    $sql_aylik = "DELETE FROM $tablo_aylik WHERE tc_no=? AND yil=? AND ay=?";
    $stmt_aylik = $db_conn->prepare($sql_aylik);
    $stmt_aylik->execute([$tc_no, $yil, $ay]);
    $aylik_rows = $stmt_aylik->rowCount(); 

    // B) Bağlı Mahalle Kayıtlarını Sil (puantaj_mahalleler)
    $sql_mahalle = "DELETE FROM $tablo_mahalle WHERE tc_no=? AND yil=? AND ay=?";
    $stmt_mahalle = $db_conn->prepare($sql_mahalle);
    $stmt_mahalle->execute([$tc_no, $yil, $ay]);
    $mahalle_rows = $stmt_mahalle->rowCount(); 

    // 4. Başarı Mesajı Oluştur (Mantıksal Kontrol)
    $toplam_silinen_satir = $aylik_rows + $mahalle_rows;
    
    if ($toplam_silinen_satir > 0) {
        // En az bir satır silinmişse
        $message = " **Kayıt başarıyla silindi.**";
        $status = 'success';
    } else {
        // Hiçbir satır silinmemişse
        $message = "**Silinecek puantaj kaydı bulunamadı.**"; 
        $status = 'success'; // İşlem, hata vermediği için teknik olarak başarılı sayılır.
    }
    
    echo json_encode(['status' => $status, 'message' => $message]);

} catch (PDOException $e) {
    // Veritabanı (SQL) hatalarını yakala
    echo json_encode(["status"=>"error","message"=>"DB Hatası: Silme sorgusu başarısız. Detay: ".$e->getMessage()]);
} catch (Exception $e) {
    // Oturum veya parametre hatalarını yakala
    echo json_encode(["status"=>"error","message"=>"Sunucu Hatası: ".$e->getMessage()]);
}
?>