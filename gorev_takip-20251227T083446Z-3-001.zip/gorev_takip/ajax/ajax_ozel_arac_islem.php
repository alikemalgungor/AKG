<?php
// ajax/ajax_ozel_arac_islem.php
session_start();
header('Content-Type: application/json');
include_once '../config/db.php';

// Hata Gösterimini Kapat (Üretim ortamında)
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Türkiye Saat Dilimi
date_default_timezone_set('Europe/Istanbul');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Oturum kapalı.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$rol_id  = isset($_SESSION['rol_id']) ? $_SESSION['rol_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    try {
        // --- 0. GÖREV TÜRLERİNİ GETİR ---
        if ($action === 'turleri_getir') {
            $turler = [];
            
            // 1. Personelin Birimini Bul
            $stmt_p = $pdo->prepare("SELECT birimler_id FROM personel_bilgileri WHERE id = ?");
            $stmt_p->execute([$user_id]);
            $birim_id = $stmt_p->fetchColumn();

            // 2. Birime Özel ve Sadece 'Arazi' Olanları Getir
            if ($birim_id && $birim_id > 0) {
                // DİKKAT: yer_turu = 'Arazi' şartını ekledik
                $stmt_t = $pdo->prepare("SELECT id, ad FROM gorev_turleri WHERE birim_id = ? AND aktif = 1 AND yer_turu = 'Arazi' ORDER BY ad");
                $stmt_t->execute([$birim_id]);
                $turler = $stmt_t->fetchAll(PDO::FETCH_ASSOC);
            }

            // 3. Eğer birime özel yoksa, Genel Listeden Sadece 'Arazi' Olanları Getir
            if (empty($turler)) {
                // DİKKAT: Burada da yer_turu = 'Arazi' şartını ekledik
                $turler = $pdo->query("SELECT id, ad FROM gorev_turleri WHERE aktif = 1 AND yer_turu = 'Arazi' ORDER BY ad")->fetchAll(PDO::FETCH_ASSOC);
            }

            echo json_encode(['status' => 'success', 'data' => $turler]);
            exit;
        }

        // --- 1. KAYDET / GÜNCELLE ---
        if ($action === 'kaydet') {
            
            // 1. ADIM: Güvenlik Kontrolü - Müdürün personel kaydı var mı?
            $stmt_check = $pdo->prepare("SELECT id FROM personel_bilgileri WHERE id = ?");
            $stmt_check->execute([$user_id]);
            if (!$stmt_check->fetch()) {
                throw new Exception("VERİTABANI HATASI: Oturum açan ID ($user_id) personel tablosunda bulunamadı! Lütfen sisteme giriş yapan kullanıcının personel kaydını oluşturun.");
            }

            // 2. ADIM: Verileri Al
            $gorev_id       = !empty($_POST['gorev_id']) ? (int)$_POST['gorev_id'] : 0;
            $arac_sahibi    = trim($_POST['arac_sahibi']);
            $arac_plaka     = strtoupper(trim($_POST['arac_plaka']));
            $gorev_tarihi   = $_POST['gorev_tarihi'];
            $cikis_saat     = $_POST['cikis_saat'];
            $gorev_turu_id  = (int)$_POST['gorev_turu_id'];
            $mahalle_id     = (int)$_POST['mahalle_id'];
            $kurum_amiri_id = (int)$_POST['kurum_amiri_id'];

            // 3. ADIM: Zorunlu Alan Kontrolü
            if (empty($arac_sahibi) || empty($arac_plaka) || empty($gorev_tarihi) || empty($cikis_saat) || $mahalle_id <= 0) {
                throw new Exception("Lütfen tüm zorunlu alanları doldurunuz.");
            }

            // 4. ADIM: Zaman Kontrolü
            $bugun_baslangic = new DateTime(date('Y-m-d 00:00:00'));
            $simdi = new DateTime();
            $girilen_zaman = new DateTime($gorev_tarihi . ' ' . $cikis_saat);
            
            // İleri Tarih Toleransı (15 Dakika)
            $tolerans_zamani = clone $simdi;
            $tolerans_zamani->modify('+15 minutes');

            if ($girilen_zaman < $bugun_baslangic) {
                throw new Exception("HATA: Geçmiş bir tarihe görev yazamazsınız. Sadece bugünkü görevleri girebilirsiniz.");
            }
            if ($girilen_zaman > $tolerans_zamani) {
                throw new Exception("HATA: Henüz gelmemiş bir saate/tarihe görev yazamazsınız.");
            }

            // 5. ADIM: Veritabanı İşlemi (GÜNCELLEME veya KAYIT)
            if ($gorev_id > 0) {
                // --- GÜNCELLEME ---
                $mevcut = $pdo->prepare("SELECT onay_durumu, gorev_kapali FROM ozel_arac_gorevler WHERE id = ? AND gorevli_personel_id = ?");
                $mevcut->execute([$gorev_id, $user_id]);
                $m = $mevcut->fetch();

                if (!$m) throw new Exception("Görev bulunamadı.");
                if ($m['gorev_kapali'] == 1 || $m['onay_durumu'] > 0) {
                    throw new Exception("Onaya gönderilmiş veya sonuçlanmış görev güncellenemez.");
                }

                $sql = "UPDATE ozel_arac_gorevler SET 
                        gorev_tarihi = ?, arac_sahibi = ?, arac_plaka = ?, gorev_turu_id = ?, 
                        mahalle_id = ?, kurum_amiri_id = ?, cikis_saat = ? 
                        WHERE id = ? AND gorevli_personel_id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$gorev_tarihi, $arac_sahibi, $arac_plaka, $gorev_turu_id, $mahalle_id, $kurum_amiri_id, $cikis_saat, $gorev_id, $user_id]);
                $msg = "Görev güncellendi.";

            } else {
                // --- YENİ KAYIT ---
                $yil = date('Y', strtotime($gorev_tarihi));
                $stmt_no = $pdo->prepare("SELECT MAX(gorev_no) FROM ozel_arac_gorevler WHERE YEAR(gorev_tarihi) = ?");
                $stmt_no->execute([$yil]);
                $yeni_no = ($stmt_no->fetchColumn() ?: 0) + 1;

                $sql = "INSERT INTO ozel_arac_gorevler 
                        (gorev_no, gorev_tarihi, arac_sahibi, arac_plaka, gorevli_personel_id, gorev_turu_id, mahalle_id, kurum_amiri_id, cikis_saat, gorev_kapali, onay_durumu) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)";
                
                $pdo->prepare($sql)->execute([
                    $yeni_no, 
                    $gorev_tarihi, 
                    $arac_sahibi, 
                    $arac_plaka, 
                    $user_id, // Personel ID (Session'dan gelen)
                    $gorev_turu_id, 
                    $mahalle_id, 
                    $kurum_amiri_id, 
                    $cikis_saat
                ]);
                $msg = "Görev kaydedildi. No: " . $yeni_no;
            }
            
            echo json_encode(['status' => 'success', 'message' => $msg]);
        }

        // --- 2. GÖREV BİTİR (DÖNÜŞ) ---
        elseif ($action === 'gorev_bitir') {
            $id = (int)$_POST['gorev_id'];
            $donus_saat = $_POST['donus_saat'];
            $donus_tarihi = $_POST['donus_tarihi'];

            if(empty($donus_saat) || empty($donus_tarihi)) throw new Exception("Dönüş bilgilerini doldurunuz.");

            $stmt = $pdo->prepare("SELECT gorev_tarihi, cikis_saat FROM ozel_arac_gorevler WHERE id = ? AND gorevli_personel_id = ?");
            $stmt->execute([$id, $user_id]);
            $g = $stmt->fetch();

            if (!$g) throw new Exception("Görev bulunamadı.");

            $cikis_dt = new DateTime(date('Y-m-d H:i', strtotime($g['gorev_tarihi'] . ' ' . $g['cikis_saat'])));
            $donus_dt = new DateTime(date('Y-m-d H:i', strtotime($donus_tarihi . ' ' . $donus_saat)));
            $simdi_dt = new DateTime(date('Y-m-d H:i'));
            $simdi_dt->modify('+15 minutes');

            if ($donus_dt <= $cikis_dt) {
                throw new Exception("HATA: Dönüş saati, çıkış saatinden önce veya aynı olamaz!");
            }
            /*if ($donus_dt > $simdi_dt) {
                throw new Exception("HATA: Gelecekteki bir saate dönüş yapamazsınız.");
            }*/

            $sql = "UPDATE ozel_arac_gorevler SET donus_saat = ?, donus_tarihi = ?, gorev_kapali = 1 WHERE id = ? AND gorevli_personel_id = ?";
            $pdo->prepare($sql)->execute([$donus_saat, $donus_tarihi, $id, $user_id]);
            echo json_encode(['status' => 'success', 'message' => 'Görev kapatıldı.']);
        }

        // --- 3. SİL (İPTAL ET) ---
        elseif ($action === 'sil') {
            $id = (int)$_POST['id'];

            $stmt = $pdo->prepare("SELECT id, onay_durumu, gorev_kapali FROM ozel_arac_gorevler WHERE id = ? AND gorevli_personel_id = ?");
            $stmt->execute([$id, $user_id]);
            $k = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$k || $k['onay_durumu'] > 0 || $k['gorev_kapali'] == 1) {
                throw new Exception("İşlem görmüş görev silinemez.");
            }

            // Son kayıt mı?
            $son_id = $pdo->query("SELECT id FROM ozel_arac_gorevler ORDER BY id DESC LIMIT 1")->fetchColumn();

            if ($id == $son_id) {
                // Sadece son kayıt tamamen silinir
                $pdo->prepare("DELETE FROM ozel_arac_gorevler WHERE id = ?")->execute([$id]);
                $msg = "Son görev tamamen silindi.";
            } else {
                // Aradakiler iptal edilir
                $pdo->prepare("UPDATE ozel_arac_gorevler SET onay_durumu = 3 WHERE id = ?")->execute([$id]);
                $msg = "Görev iptal edildi.";
            }

            echo json_encode(['status' => 'success', 'message' => $msg]);
        }

        // --- 4. DETAY GETİR ---
        elseif ($action === 'detay_getir') {
            $id = (int)$_POST['id'];
            $sql = in_array($rol_id, [1, 2]) ? "SELECT * FROM ozel_arac_gorevler WHERE id = ?" : "SELECT * FROM ozel_arac_gorevler WHERE id = ? AND gorevli_personel_id = ?";
            $stmt = $pdo->prepare($sql);
            in_array($rol_id, [1, 2]) ? $stmt->execute([$id]) : $stmt->execute([$id, $user_id]);
            echo json_encode(['status' => 'success', 'data' => $stmt->fetch(PDO::FETCH_ASSOC)]);
        }

        // --- 5. ONAYLA / REDDET ---
        // --- 5. ONAYLA / REDDET (GÜNCELLENMİŞ VERSİYON) ---
elseif ($action === 'onayla' || $action === 'reddet') {
    
    $islem_yapilacak_id = (int)$_POST['id'];
    $durum = ($action === 'onayla') ? 1 : 2;

    // ÖNCELİKLE: Görevin "Kurum Amiri" olarak kimi kaydettiğine bakalım
    $stmt_gorev = $pdo->prepare("SELECT kurum_amiri_id FROM ozel_arac_gorevler WHERE id = ?");
    $stmt_gorev->execute([$islem_yapilacak_id]);
    $gorev = $stmt_gorev->fetch(PDO::FETCH_ASSOC);

    if (!$gorev) {
        throw new Exception("Görev bulunamadı.");
    }

    // YETKİ KONTROLÜ MANTIĞI:
    // 1. Ya kullanıcının Rolü 1 veya 2 (Yönetici/Müdür) olmalı
    // 2. YA DA kullanıcının ID'si, bu görevdeki "kurum_amiri_id" ile eşleşmeli (Vekalet durumu)
    
    $yonetici_mi = in_array($rol_id, [1, 2]);
    $gorev_atanan_kisi_mi = ($gorev['kurum_amiri_id'] == $user_id);

    if (!$yonetici_mi && !$gorev_atanan_kisi_mi) {
        throw new Exception("YETKİSİZ İŞLEM: Bu görevi onaylama yetkiniz yok. (Ne yöneticisiniz ne de seçilen amirsiniz)");
    }

    // Güvenlik kontrolü geçildi, işlemi yap
    $pdo->prepare("UPDATE ozel_arac_gorevler SET onay_durumu = ? WHERE id = ?")->execute([$durum, $islem_yapilacak_id]);
    echo json_encode(['status' => 'success', 'message' => 'İşlem başarıyla tamamlandı.']);
}

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>