<?php
// ajax/tab_seyyar.php
session_start();
include_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { exit("Oturum kapalı."); }
$user_id = $_SESSION['user_id'];

$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$ay  = isset($_GET['ay']) ? intval($_GET['ay']) : date('m');

// DÖNEM AYARLARI
if ($ay <= 6) {
    $bas_ay = 1; $bit_ay = 6;
    $donem_ad = "1. DÖNEM (OCAK - HAZİRAN)";
    $donem_no = 1;
} else {
    $bas_ay = 7; $bit_ay = 12;
    $donem_ad = "2. DÖNEM (TEMMUZ - ARALIK)";
    $donem_no = 2;
}

// 1. PUANTAJ VERİLERİNİ ÇEK
$sql_p = "SELECT * FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ? ORDER BY ay ASC";
$stmt_p = $pdo->prepare($sql_p);
$stmt_p->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$puantaj_data = [];
foreach($stmt_p->fetchAll(PDO::FETCH_ASSOC) as $p) { $puantaj_data[$p['ay']] = $p; }

// 2. MAHALLELERİ ÇEK
$sql_m = "SELECT * FROM puantaj_mahalleler WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ? ORDER BY ay ASC";
$stmt_m = $pdo->prepare($sql_m);
$stmt_m->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$mahalle_data = [];
foreach($stmt_m->fetchAll(PDO::FETCH_ASSOC) as $m) { $mahalle_data[$m['ay']] = $m; }

// 3. KAYITLI AÇIKLAMALAR
$bas_tarih = "$yil-" . sprintf("%02d", $bas_ay) . "-01";
$stmt_d = $pdo->prepare("SELECT * FROM seyyar_gorev_detay WHERE personel_id = ? AND YEAR(tarih) = ?");
$stmt_d->execute([$user_id, $yil]);
$detay_data = [];
foreach($stmt_d->fetchAll(PDO::FETCH_ASSOC) as $d) {
    $detay_data[$d['tarih']] = $d['aciklama'];
}

// 4. KİLİT KONTROLÜ (Herhangi bir ay kilitliyse dönem kilitli sayılır)
$stmt_lock = $pdo->prepare("SELECT COUNT(*) FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ? AND kilit_seyyar = 'Kilitli'");
$stmt_lock->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$kilitli_mi = ($stmt_lock->fetchColumn() > 0);

$seyyar_kodlari = ["AS", "AKS", "Seyyar", "GS", "KS", "S"]; 
?>

<div class="card border-0 shadow-sm mt-2">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <div>
            <h6 class="mb-0 text-primary fw-bold">Seyyar Görev Yolluğu (<?php echo $donem_ad; ?>)</h6>
        </div>
        
        <div class="d-flex gap-2 align-items-center">
            <span class="badge <?=$kilitli_mi?'bg-danger':'bg-success'?> p-2">
                <i class="fas <?=$kilitli_mi?'fa-lock':'fa-lock-open'?>"></i> <?=$kilitli_mi?'KİLİTLİ':'AÇIK'?>
            </span>

            <?php if ($kilitli_mi): ?>
                <button onclick="window.open('yazdir_seyyar.php?yil=<?php echo $yil; ?>&donem=<?php echo $donem_no; ?>','_blank')" class="btn btn-sm btn-dark">
                    <i class="fas fa-print me-1"></i> YAZDIR
                </button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover table-sm align-middle mb-0" style="font-size:0.85rem;">
                <thead class="table-light text-center">
                    <tr>
                        <th width="50">Sıra</th>
                        <th width="100">Tarih</th>
                        <th width="250">Gidilen Yer (Puantajdan)</th>
                        <th>Açıklama (Yapılan İş / Güzergah Detayı)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $sira = 1;
                    $kayit_var = false;

                    // 6 AYLIK DÖNGÜ
                    for ($ay_dongu = $bas_ay; $ay_dongu <= $bit_ay; $ay_dongu++):
                        if(!isset($puantaj_data[$ay_dongu])) continue;
                        
                        $p_row = $puantaj_data[$ay_dongu];
                        $m_row = $mahalle_data[$ay_dongu] ?? [];

                        for ($gun = 1; $gun <= 31; $gun++):
                            $kod = trim($p_row['gun'.$gun] ?? '');
                            if (in_array($kod, $seyyar_kodlari)):
                                $kayit_var = true;
                                $tam_tarih = sprintf("%04d-%02d-%02d", $yil, $ay_dongu, $gun);
                                $tarih_gorunum = sprintf("%02d.%02d.%04d", $gun, $ay_dongu, $yil);
                                $mahalle = $m_row['gun'.$gun] ?? '';
                                $kayitli_aciklama = $detay_data[$tam_tarih] ?? '';
                    ?>
                    <tr>
                        <td class="text-center fw-bold"><?php echo $sira++; ?></td>
                        <td class="text-center"><?php echo $tarih_gorunum; ?></td>
                        <td class="text-primary fw-bold px-2">
                            <?php echo $mahalle ? $mahalle : '<span class="text-muted fst-italic">-Belirtilmemiş-</span>'; ?>
                            <input type="hidden" class="seyyar-mahalle-input" data-tarih="<?php echo $tam_tarih; ?>" value="<?php echo htmlspecialchars($mahalle); ?>">
                        </td>
                        <td class="p-1">
                            <input type="text" class="form-control form-control-sm seyyar-aciklama-input" 
                                   data-tarih="<?php echo $tam_tarih; ?>" 
                                   value="<?php echo htmlspecialchars($kayitli_aciklama); ?>"
                                   placeholder="Yapılan işlem..."
                                   <?php echo $kilitli_mi ? 'disabled' : ''; ?>>
                        </td>
                    </tr>
                    <?php 
                            endif; 
                        endfor; 
                    endfor; 

                    if (!$kayit_var):
                    ?>
                    <tr>
                        <td colspan="4" class="text-center text-muted py-4">
                            Bu dönem için seyyar görev girişi bulunmamaktadır.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <?php if (!$kilitli_mi && $kayit_var): ?>
    <div class="card-footer bg-light p-3 d-flex justify-content-end">
        <button type="button" class="btn btn-primary fw-bold" onclick="kaydetVeKilitleDonem()">
            <i class="fas fa-print me-1"></i> ONAYLA VE YAZDIR
        </button>
    </div>
    <?php endif; ?>
</div>

<script>
function kaydetVeKilitleDonem() {
    if(!confirm("Bu döneme ait seyyar görev yollukları kaydedilecek ve dönem kilitlenecektir.\n\nOnaylıyor musunuz?")) return;

    let btn = $('.btn-primary');
    let oldHtml = btn.html();
    btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> İşleniyor...');

    let veriListesi = {};
    let veriVar = false;

    // Verileri Topla
    document.querySelectorAll('.seyyar-aciklama-input').forEach(input => {
        let tarih = input.getAttribute('data-tarih');
        let aciklama = input.value;
        let mahalleInput = document.querySelector(`.seyyar-mahalle-input[data-tarih="${tarih}"]`);
        let mahalle = mahalleInput ? mahalleInput.value : "";

        veriListesi[tarih] = { aciklama: aciklama, mahalle: mahalle };
        veriVar = true;
    });

    if (!veriVar) {
        alert("Kaydedilecek veri bulunamadı.");
        btn.prop('disabled', false).html(oldHtml);
        return;
    }

    // 1. ADIM: KAYDET
    $.post("../ajax/ajax_puantaj_islem.php", {
        action: "seyyar_toplu_kaydet",
        veriler: veriListesi
    }, function(res) {
        let response = (typeof res === 'object') ? res : JSON.parse(res);
        
        if(response.status === "success") {
            
            // 2. ADIM: KİLİTLE (Dönem Bazlı)
            $.post("../ajax/ajax_puantaj_islem.php", {
                action: "seyyar_kilitle", // Backend'de bu action'ı "seyyar_kilitle" olarak karşılamalısınız
                donem: '<?=$donem_no?>',
                yil: '<?=$yil?>'
            }, function(resKilit) {
                let kilitResponse = (typeof resKilit === 'object') ? resKilit : JSON.parse(resKilit);
                
                if(kilitResponse.status === "success") {
                    // 3. ADIM: YAZDIRMA PENCERESİNİ AÇ
                    window.open('yazdir_seyyar.php?yil=<?=$yil?>&donem=<?=$donem_no?>', '_blank');
                    
                    // 4. ADIM: SAYFAYI YENİLE
                    alert("✅ İşlem başarılı. Dönem kilitlendi ve rapor açıldı.");
                    loadTabContent('seyyar');
                } else {
                    alert("Kilit Hatası: " + kilitResponse.message);
                    btn.prop('disabled', false).html(oldHtml);
                }
            });

        } else {
            alert("Kayıt Hatası: " + response.message);
            btn.prop('disabled', false).html(oldHtml);
        }
    });
}
</script>