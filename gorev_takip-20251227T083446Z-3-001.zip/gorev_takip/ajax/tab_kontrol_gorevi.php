<?php
// ajax/tab_kontrol_gorevi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { exit('<div class="alert alert-danger">Oturum dolmuş.</div>'); }

$user_id  = $_SESSION['user_id'];
$birim_id = $_SESSION['birim_id'] ?? 0; 
$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$ay  = isset($_GET['ay'])  ? intval($_GET['ay'])  : date('m');

// 1. PUANTAJ VERİSİNİ ÇEK
$sql = "SELECT p.*, m.gun1 as m1, m.gun2 as m2, m.gun3 as m3, m.gun4 as m4, m.gun5 as m5, m.gun6 as m6, m.gun7 as m7, m.gun8 as m8, m.gun9 as m9, m.gun10 as m10, m.gun11 as m11, m.gun12 as m12, m.gun13 as m13, m.gun14 as m14, m.gun15 as m15, m.gun16 as m16, m.gun17 as m17, m.gun18 as m18, m.gun19 as m19, m.gun20 as m20, m.gun21 as m21, m.gun22 as m22, m.gun23 as m23, m.gun24 as m24, m.gun25 as m25, m.gun26 as m26, m.gun27 as m27, m.gun28 as m28, m.gun29 as m29, m.gun30 as m30, m.gun31 as m31 
        FROM puantaj_aylik p 
        LEFT JOIN puantaj_mahalleler m ON p.personel_id = m.personel_id AND p.yil = m.yil AND p.ay = m.ay 
        WHERE p.personel_id = ? AND p.yil = ? AND p.ay = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$user_id, $yil, $ay]);
$puantaj = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$puantaj) { exit('<div class="alert alert-warning">Puantaj bulunamadı.</div>'); }

$kilitli = ($puantaj['kilit_durumu'] === 'Kilitli');

// 2. KAYITLI DETAYLARI ÇEK
$stmt_detay = $pdo->prepare("SELECT * FROM kontrol_gorevi_detay WHERE personel_id = ? AND yil = ? AND ay = ?");
$stmt_detay->execute([$user_id, $yil, $ay]);
$detaylar_raw = $stmt_detay->fetchAll(PDO::FETCH_ASSOC);
$kayitli_detaylar = [];
foreach($detaylar_raw as $d) {
    $kayitli_detaylar[$d['gun']] = $d; 
}

// 3. TANIMLAMALARI ÇEK
$yasal_dayanaklar = $pdo->prepare("SELECT * FROM tanim_kontrol_yasal_dayanak WHERE birim_id = 0 OR birim_id = ?");
$yasal_dayanaklar->execute([$birim_id]);
$yasal_dayanaklar = $yasal_dayanaklar->fetchAll(PDO::FETCH_ASSOC);

// DÜZELTME BURADA: 'AND yer_turu = "daire"' EKLEDİK

$gorev_turleri = $pdo->prepare("SELECT id, ad, varsayilan_aciklama 
                                FROM gorev_turleri 
                                WHERE (birim_id = ? OR birim_id = 0) 
                                AND yer_turu = 'daire' 
                                AND aktif = 1 
                                ORDER BY ad ASC");
$gorev_turleri->execute([$birim_id]);
$gorev_turleri = $gorev_turleri->fetchAll(PDO::FETCH_ASSOC);
// Kontrol Kodları + İzin ve Tatil
$kontrol_kodlari = ["KG", "KS", "AK", "AKS", "Kontrol Görevi", "Kontrol Görevi + Seyyar Görev", "IZ", "RT"];
$gecerli_gunler = [];
for ($i = 1; $i <= 31; $i++) {
    $kod = trim($puantaj['gun' . $i] ?? '');
    if (in_array($kod, $kontrol_kodlari)) { $gecerli_gunler[] = $i; }
}
?>

<style>
    .kontrol-table { table-layout: fixed; width: 100%; border-collapse: collapse; }
    .col-num { width: 40px; } .col-tarih { width: 100px; } .col-mahalle { width: 120px; } 
    .col-tur { width: 165px; } .col-dayanak { width: 165px; } .col-saat { width: 160px; } 
    .kontrol-table thead th { background: #f8f9fa; font-size: 11px; padding: 10px 5px; border: 1px solid #dee2e6; text-align: center; }
    .kontrol-table td { vertical-align: middle; padding: 5px; font-size: 13px; border: 1px solid #dee2e6; }
    .aciklama-input { width: 100% !important; border: 1px solid #ced4da; padding: 4px 8px; }
    .izin-row { background-color: #fff3cd !important; }
    .tatil-row { background-color: #d1e7dd !important; }
</style>

<div class="card shadow-sm border-0 mt-2">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h6 class="mb-0 text-primary fw-bold">Kontrol Görevi Onay (<?=$ay?>/<?=$yil?>)</h6>
        <div class="d-flex gap-2">
            <?php if(!$kilitli): ?>
                <button type="button" class="btn btn-sm btn-outline-warning text-dark" onclick="hizliDoldur()">
                    <i class="fas fa-magic me-1"></i> Hızlı Doldur
                </button>
            <?php endif; ?>
            <span class="badge <?=$kilitli?'bg-danger':'bg-success'?> p-2">
                <i class="fas <?=$kilitli?'fa-lock':'fa-pen'?>"></i> <?=$kilitli?'KİLİTLİ':'AÇIK'?>
            </span>
            <?php if($kilitli): ?>
                <button class="btn btn-sm btn-dark" onclick="window.open('../pages/yazdir_kontrol.php?yil=<?=$yil?>&ay=<?=$ay?>','_blank')">YAZDIR</button>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="card-body p-0">
        <form id="formKontrolDetay">
            <input type="hidden" name="yil" value="<?=$yil?>">
            <input type="hidden" name="ay" value="<?=$ay?>">
            <input type="hidden" name="action" value="kontrol_detay_kaydet">
            
            <table class="table table-hover mb-0 kontrol-table">
                <thead>
                    <tr>
                        <th class="col-num">#</th><th class="col-tarih">Tarih</th><th class="col-mahalle">Mahalle</th>
                        <th class="col-tur">Görev Türü</th><th class="col-dayanak">Dayanak</th>
                        <th>Hizmet / Açıklama</th><th class="col-saat">Saat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($gecerli_gunler as $sira => $gun): 
                        $ts = strtotime("$yil-$ay-$gun");
                        $gun_ad = ['Monday'=>'Pzt','Tuesday'=>'Sal','Wednesday'=>'Çar','Thursday'=>'Per','Friday'=>'Cum','Saturday'=>'Cmt','Sunday'=>'Paz'][date('l', $ts)];
                        $v = $kayitli_detaylar[$gun] ?? [];
                        
                        $puan_kodu = trim($puantaj['gun'.$gun] ?? '');
                        $mahalle_adi = $puantaj['m'.$gun] ?? '';
                        $has_mahalle = (!empty($mahalle_adi) && $mahalle_adi !== '-');

                        // Satır renklendirme
                        $row_class = "";
                        if($puan_kodu == 'IZ') $row_class = "izin-row";
                        if($puan_kodu == 'RT') $row_class = "tatil-row";

                        $def_bas = $has_mahalle ? '09:00' : '08:00';
                        $def_bit = $has_mahalle ? '15:30' : '17:00';
                    ?>
                    <tr class="satir-veri <?=$row_class?>" data-gun="<?=$gun?>" data-mahalle="<?=htmlspecialchars($mahalle_adi ?? '')?>">
                        <td class="text-center small"><?=$sira+1?></td>
                        <td class="text-center small"><?=date('d.m.Y', $ts)?><br><?=$gun_ad?></td>
                        <td class="text-center text-primary small fw-bold">
                            <?php 
                                if($puan_kodu == 'IZ') echo "İzinli Gün";
                                elseif($puan_kodu == 'RT') echo "Resmî Tatil";
                                else echo htmlspecialchars($mahalle_adi ?: '-');
                            ?>
                        </td>
                        
                        <?php if($puan_kodu == 'IZ' || $puan_kodu == 'RT'): ?>
                            <td colspan="4" class="text-center fw-bold text-muted small" style="vertical-align: middle;">
                                -- ÇALIŞILMAYAN GÜN --
                                <input type="hidden" name="detay[<?=$gun?>][aciklama]" value="">
                            </td>
                        <?php else: ?>
                            <td>
                                <select name="detay[<?=$gun?>][gorev_turu]" class="form-select form-select-sm gorev-select" <?=$kilitli?'disabled':''?>>
                                    <option value="">Seç...</option>
                                    <?php foreach($gorev_turleri as $gt): ?>
                                        <option value="<?=$gt['id']?>" data-aciklama="<?=htmlspecialchars($gt['varsayilan_aciklama'] ?? '')?>" <?=($v['gorev_turu_id'] ?? '') == $gt['id'] ? 'selected' : ''?>><?=$gt['ad']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="detay[<?=$gun?>][yasal]" class="form-select form-select-sm" <?=$kilitli?'disabled':''?>>
                                    <option value="">Seç...</option>
                                    <?php foreach($yasal_dayanaklar as $yd): ?>
                                        <option value="<?=$yd['id']?>" <?=($v['yasal_dayanak_id'] ?? '') == $yd['id'] ? 'selected' : ''?>><?=$yd['icerik']?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <?php $mevcut_aciklama = isset($v['aciklama']) ? $v['aciklama'] : ''; ?>
                                <input type="text" name="detay[<?=$gun?>][aciklama]" class="form-control form-control-sm aciklama-input" value="<?=htmlspecialchars((string)$mevcut_aciklama)?>" <?=$kilitli?'disabled':''?>>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <input type="time" class="form-control px-1" name="detay[<?=$gun?>][bas]" value="<?=$v['baslangic_saati'] ?? $def_bas?>" <?=$kilitli?'disabled':''?>>
                                    <input type="time" class="form-control px-1" name="detay[<?=$gun?>][bit]" value="<?=$v['bitis_saati'] ?? $def_bit?>" <?=$kilitli?'disabled':''?>>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if(!$kilitli): ?>
            <div class="card-footer bg-light p-3 d-flex justify-content-end">
                <button type="button" class="btn btn-primary fw-bold" onclick="kaydetVeKilitleAy()">
                    <i class="fas fa-print me-1"></i> ONAYLA VE YAZDIR
                </button>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<script>
// Mahalle Adı Düzenleyici (Türkçe Karakter Destekli)
function capitalizeMahalle(str) {
    if(!str) return "";
    return str.toLocaleLowerCase('tr-TR').split(' ').map(word => word.charAt(0).toLocaleUpperCase('tr-TR') + word.slice(1)).join(' ');
}

// Seçim Değişince Açıklama Yazma (Otomatik)
$(document).off('change', '.gorev-select').on('change', '.gorev-select', function() {
    let row = $(this).closest('tr');
    
    // DÜZELTME BURADA: .data() yerine .attr() kullandık
    let rawMahalle = row.attr('data-mahalle');
    
    let mahalle = (rawMahalle && rawMahalle !== '-' && rawMahalle !== '') ? capitalizeMahalle(String(rawMahalle)) : "";
    let varsayilan = $('option:selected', this).data('aciklama');
    
    let yeniMetin = "";
    if (varsayilan) {
        // Mahalle varsa "X mahallesinde...", yoksa sadece açıklama
        yeniMetin = (mahalle !== "") ? mahalle + " mahallesinde " + varsayilan : varsayilan;
    }
    row.find('.aciklama-input').val(yeniMetin);
});

// --- SENİN KURALLARINA GÖRE HIZLI DOLDUR ---
function hizliDoldur() {
    console.log("Hızlı doldur başladı..."); // Kontrol için konsola yazalım

    $('.satir-veri').each(function() {
        let row = $(this);
        // İzinli veya tatil satırı ise işlem yapma
        if (row.hasClass('izin-row') || row.hasClass('tatil-row')) return;

        let gS = row.find('.gorev-select'); // Görev Kutusu
        let yS = row.find('select[name*="[yasal]"]'); // Yasal Dayanak

        // DÜZELTME BURADA: .data() yerine .attr() kullandık
        let rawMahalle = row.attr('data-mahalle');
        
        // Mahalle var mı kontrolü (Boşlukları temizle ve kontrol et)
        let mahalleVar = (rawMahalle && rawMahalle !== '-' && rawMahalle.trim() !== '');
        
        // Konsoldan takip et (Hata ayıklamak için)
        // console.log("Gün: " + row.attr('data-gun') + " - Mahalle: " + rawMahalle + " - Durum: " + mahalleVar);

        // Görev daha önce seçilmemişse işlem yap
        if(gS.val() === "") {
            let secilecekID = "";

            if (!mahalleVar) {
                // KURAL 1: Mahalle YOKSA -> "Belge Kontrolü"
                secilecekID = textIleOptionBul(gS, "Belge Kontrolü");
            } 
            else {
                // KURAL 2: Mahalle VARSA -> Birime göre öncelik
                
                // A) Veteriner (Aşılama)
                let asilama = textIleOptionBul(gS, "Aşılama");
                // B) Ziraat (İzleme veya Tarla)
                let izleme = textIleOptionBul(gS, "İzleme") || textIleOptionBul(gS, "Tarla");
                // C) Gıda (Gıda Denetimi)
                let gida = textIleOptionBul(gS, "Gıda Denetimi");
                // D) Su Ürünleri
                let suUrunleri = textIleOptionBul(gS, "Su Ürünleri");

                // Hangi seçenek varsa onu seç (Öncelik sırasına göre)
                if(asilama) secilecekID = asilama;
                else if(izleme) secilecekID = izleme;
                else if(gida) secilecekID = gida;
                else if(suUrunleri) secilecekID = suUrunleri;
            }

            // Eğer kurallardan hiçbiri tutmazsa (Listede o görevler yoksa) ilkini seç
            if (!secilecekID) {
                secilecekID = gS.find('option:eq(1)').val();
            }

            // Seçimi Uygula ve Tetikle
            if (secilecekID) {
                gS.val(secilecekID).trigger('change');
            }
        }

        // Yasal Dayanak (Standart 5996 yoksa ilkini seç)
        if(yS.val() === "") {
            let kanun = textIleOptionBul(yS, "5996") || yS.find('option:eq(1)').val();
            yS.val(kanun);
        }
    });
}

// Yardımcı Fonksiyon: Select içinde metne göre ID bulur
function textIleOptionBul(selectNesnesi, aranacakKelime) {
    let bulunanID = "";
    selectNesnesi.find('option').each(function() {
        // Büyük/Küçük harf duyarlılığını kaldırmak için toLowerCase ekledik
        if ($(this).text().toLowerCase().indexOf(aranacakKelime.toLowerCase()) !== -1) {
            bulunanID = $(this).val();
            return false; // Döngüyü kır
        }
    });
    return bulunanID;
}

function kaydetVeKilitleAy() {
    if(!confirm("Veriler kaydedilecek ve ay kilitlenecektir. Onaylıyor musunuz?")) return;
    
    let btn = $('.btn-primary');
    let oldHtml = btn.html();
    btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> İşleniyor...');

    $.post('../ajax/ajax_puantaj_islem.php', $('#formKontrolDetay').serialize(), function(res) {
        if(res.status == 'success') {
            $.post('../ajax/ajax_puantaj_islem.php', { action: 'kilitle', yil: '<?=$yil?>', ay: '<?=$ay?>' }, function(resKilit) {
                if(resKilit.status == 'success') {
                    window.open('../pages/yazdir_kontrol.php?yil=<?=$yil?>&ay=<?=$ay?>', '_blank');
                    alert("✅ Kayıt başarılı. Ay kilitlendi ve yazdırma sayfası açıldı.");
                    loadTabContent('kontrol');
                } else {
                    alert("Kilit Hatası: " + resKilit.message);
                    btn.prop('disabled', false).html(oldHtml);
                }
            }, 'json');
        } else { 
            alert("Kayıt Hatası: " + res.message); 
            btn.prop('disabled', false).html(oldHtml); 
        }
    }, 'json');
}
</script>