<?php
// ajax/ajax_puantaj_islem.php
session_start();
include_once '../config/db.php';
header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors', 0);
error_reporting(E_ALL);

$json = file_get_contents('php://input');
$data = json_decode($json, true);
if (is_array($data)) { $_POST = array_merge($_POST, $data); }

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Oturum süreniz dolmuş.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action  = $_POST['action'] ?? '';

// =================================================================
// KİLİT KONTROL FONKSİYONU
// =================================================================
function getLockStates($pdo, $uid, $yil, $ay) {
    $stmt = $pdo->prepare("SELECT kilit_durumu, kilit_arazi, kilit_seyyar FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay = ?");
    $stmt->execute([$uid, $yil, $ay]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    return $res ?: [
        'kilit_durumu' => 'Açık',
        'kilit_arazi'  => 'Açık',
        'kilit_seyyar' => 'Açık'
    ];
}

try {
    // =================================================================
    // 1. ANA PUANTAJ (TAKVİM) KAYDET
    // =================================================================
    if ($action === 'kaydet') {
        $yil = intval($_POST['yil']); 
        $ay  = intval($_POST['ay']);
        $yeni_gunler = $_POST['gunler'] ?? [];

        $stmt_old = $pdo->prepare("SELECT * FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay = ?");
        $stmt_old->execute([$user_id, $yil, $ay]);
        $eski_kayit = $stmt_old->fetch(PDO::FETCH_ASSOC);

        if ($eski_kayit) {
            if ($eski_kayit['kilit_durumu'] === 'Kilitli') {
                echo json_encode(['status' => 'error', 'message' => 'Bu ay tamamen kilitlenmiştir!']);
                exit;
            }

            $arazi_kodlari = ["AT", "AK", "AS", "AKS", "Arazi Tazminatı", "Arazi + Kontrol", "Arazi + Seyyar", "Arazi + Kontrol + Seyyar"];
            $seyyar_kodlari = ["S", "AS", "AKS", "Seyyar Görev", "Arazi + Seyyar", "Kontrol Görevi + Seyyar Görev", "Arazi + Kontrol + Seyyar"];

            for ($i = 0; $i < 31; $i++) {
                $gun_no = $i + 1;
                $eski_kod = trim($eski_kayit['gun'.$gun_no] ?? '');
                $yeni_kod = trim($yeni_gunler[$i] ?? '');

                if ($eski_kod !== $yeni_kod) {
                    if ($eski_kayit['kilit_arazi'] === 'Kilitli') {
                        if (in_array($eski_kod, $arazi_kodlari) || in_array($yeni_kod, $arazi_kodlari)) {
                            echo json_encode(['status' => 'error', 'message' => "HATA: {$gun_no}. gün Arazi verileri dönemlik kilitlidir. Bu günü değiştiremezsiniz!"]);
                            exit;
                        }
                    }
                    if ($eski_kayit['kilit_seyyar'] === 'Kilitli') {
                        if (in_array($eski_kod, $seyyar_kodlari) || in_array($yeni_kod, $seyyar_kodlari)) {
                            echo json_encode(['status' => 'error', 'message' => "HATA: {$gun_no}. gün Seyyar kayıtları kilitlidir. Değişiklik yapılamaz!"]);
                            exit;
                        }
                    }
                }
            }
        }

        $pdo->beginTransaction();
        $sql1 = "INSERT INTO puantaj_aylik (personel_id, yil, ay, gun1, gun2, gun3, gun4, gun5, gun6, gun7, gun8, gun9, gun10, gun11, gun12, gun13, gun14, gun15, gun16, gun17, gun18, gun19, gun20, gun21, gun22, gun23, gun24, gun25, gun26, gun27, gun28, gun29, gun30, gun31, toplam_kon_gor_puani, toplam_kon_gor_gunu, toplam_sofor_puani, toplam_seyyar_gorev, toplam_arazi_gorev, toplam_aylik_puan) 
                 VALUES (:uid, :yil, :ay, :g1, :g2, :g3, :g4, :g5, :g6, :g7, :g8, :g9, :g10, :g11, :g12, :g13, :g14, :g15, :g16, :g17, :g18, :g19, :g20, :g21, :g22, :g23, :g24, :g25, :g26, :g27, :g28, :g29, :g30, :g31, :p1, :p_gun, :p2, :p3, :p4, :p5)
                 ON DUPLICATE KEY UPDATE gun1=:g1, gun2=:g2, gun3=:g3, gun4=:g4, gun5=:g5, gun6=:g6, gun7=:g7, gun8=:g8, gun9=:g9, gun10=:g10, gun11=:g11, gun12=:g12, gun13=:g13, gun14=:g14, gun15=:g15, gun16=:g16, gun17=:g17, gun18=:g18, gun19=:g19, gun20=:g20, gun21=:g21, gun22=:g22, gun23=:g23, gun24=:g24, gun25=:g25, gun26=:g26, gun27=:g27, gun28=:g28, gun29=:g29, gun30=:g30, gun31=:g31, toplam_kon_gor_puani=:p1, toplam_kon_gor_gunu=:p_gun, toplam_sofor_puani=:p2, toplam_seyyar_gorev=:p3, toplam_arazi_gorev=:p4, toplam_aylik_puan=:p5";
        $stmt1 = $pdo->prepare($sql1);
        $params1 = [':uid'=>$user_id, ':yil'=>$yil, ':ay'=>$ay, ':p1'=>$_POST['toplam_kon_gor_puani']??0, ':p_gun'=>$_POST['toplam_kon_gor_gunu']??0, ':p2'=>$_POST['toplam_sofor_puani']??0, ':p3'=>$_POST['toplam_seyyar_gorev']??0, ':p4'=>$_POST['toplam_arazi_gorev']??0, ':p5'=>$_POST['toplam_aylik_puan']??0];
        for($i=0; $i<31; $i++) { $params1[':g'.($i+1)] = $yeni_gunler[$i] ?? ''; }
        $stmt1->execute($params1);

        $pdo->prepare("DELETE FROM puantaj_mahalleler WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        $sql2 = "INSERT INTO puantaj_mahalleler (personel_id, yil, ay, gun1, gun2, gun3, gun4, gun5, gun6, gun7, gun8, gun9, gun10, gun11, gun12, gun13, gun14, gun15, gun16, gun17, gun18, gun19, gun20, gun21, gun22, gun23, gun24, gun25, gun26, gun27, gun28, gun29, gun30, gun31) VALUES (:uid, :yil, :ay, :m1, :m2, :m3, :m4, :m5, :m6, :m7, :m8, :m9, :m10, :m11, :m12, :m13, :m14, :m15, :m16, :m17, :m18, :m19, :m20, :m21, :m22, :m23, :m24, :m25, :m26, :m27, :m28, :m29, :m30, :m31)";
        $params2 = [':uid'=>$user_id, ':yil'=>$yil, ':ay'=>$ay];
        $mahalleler = $_POST['mahalleler'] ?? [];
        for($i=0; $i<31; $i++) { $params2[':m'.($i+1)] = $mahalleler[$i] ?? ''; }
        $pdo->prepare($sql2)->execute($params2);

        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Kaydedildi.']);
    }

    // =================================================================
    // 2. BUL
    // =================================================================
    elseif ($action === 'bul') {
        $yil = $_POST['yil']; $ay = $_POST['ay'];
        $sql = "SELECT p.*, m.gun1 as m1, m.gun2 as m2, m.gun3 as m3, m.gun4 as m4, m.gun5 as m5, m.gun6 as m6, m.gun7 as m7, m.gun8 as m8, m.gun9 as m9, m.gun10 as m10, m.gun11 as m11, m.gun12 as m12, m.gun13 as m13, m.gun14 as m14, m.gun15 as m15, m.gun16 as m16, m.gun17 as m17, m.gun18 as m18, m.gun19 as m19, m.gun20 as m20, m.gun21 as m21, m.gun22 as m22, m.gun23 as m23, m.gun24 as m24, m.gun25 as m25, m.gun26 as m26, m.gun27 as m27, m.gun28 as m28, m.gun29 as m29, m.gun30 as m30, m.gun31 as m31 FROM puantaj_aylik p LEFT JOIN puantaj_mahalleler m ON p.personel_id = m.personel_id AND p.yil = m.yil AND p.ay = m.ay WHERE p.personel_id = ? AND p.yil = ? AND p.ay = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id, $yil, $ay]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $gunler = []; $mahalleler = [];
            for($i=1; $i<=31; $i++) { $gunler[$i] = $row['gun'.$i]; $mahalleler[$i] = $row['m'.$i]; }
            echo json_encode(['status' => 'success', 'data' => ['gunler'=>$gunler, 'mahalleler'=>$mahalleler, 'toplam_kon_gor_puani'=>$row['toplam_kon_gor_puani'], 'toplam_kon_gor_gunu'=>$row['toplam_kon_gor_gunu'], 'toplam_sofor_puani'=>$row['toplam_sofor_puani'], 'toplam_seyyar_gorev'=>$row['toplam_seyyar_gorev'], 'toplam_arazi_gorev'=>$row['toplam_arazi_gorev'], 'toplam_aylik_puan'=>$row['toplam_aylik_puan'], 'kilit_durumu'=>$row['kilit_durumu']]]);
        } else { echo json_encode(['status' => 'error', 'message' => 'Kayıt bulunamadı.']); }
    }

    // =================================================================
    // 3. SİL İŞLEMİ (Ana Puantaj)
    // =================================================================
    elseif ($action === 'sil') {
        $yil = intval($_POST['yil']); $ay = intval($_POST['ay']);
        $locks = getLockStates($pdo, $user_id, $yil, $ay);
        
        if ($locks['kilit_durumu'] === 'Kilitli' || $locks['kilit_arazi'] === 'Kilitli' || $locks['kilit_seyyar'] === 'Kilitli') {
            echo json_encode(['status' => 'error', 'message' => 'Bu ay onaylanmış veya kilitlenmiş veriler içeriyor. Silmek için Site yöneticisi ile iletişime geçiniz!']);
            exit;
        }

        $pdo->beginTransaction();
        $pdo->prepare("DELETE FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        $pdo->prepare("DELETE FROM puantaj_mahalleler WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        $pdo->prepare("DELETE FROM kontrol_gorevi_detay WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        $pdo->prepare("DELETE FROM arazi_tazminati_detay WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Ayın tüm kayıtları silindi.']);
    }

    // =================================================================
    // 4. KONTROL DETAY KAYDET
    // =================================================================
    elseif ($action === 'kontrol_detay_kaydet') {
        $yil = $_POST['yil']; $ay = $_POST['ay']; $detaylar = $_POST['detay'] ?? [];
        $locks = getLockStates($pdo, $user_id, $yil, $ay);
        if ($locks['kilit_durumu'] === 'Kilitli') { echo json_encode(['status' => 'error', 'message' => 'Ay kilitli!']); exit; }

        $pdo->beginTransaction();
        foreach ($detaylar as $gun => $v) {
            if (empty($v['gorev_turu']) && empty($v['aciklama'])) continue;
            $sql = "INSERT INTO kontrol_gorevi_detay (personel_id, yil, ay, gun, yasal_dayanak_id, gorev_turu_id, aciklama, baslangic_saati, bitis_saati) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE yasal_dayanak_id=VALUES(yasal_dayanak_id), gorev_turu_id=VALUES(gorev_turu_id), aciklama=VALUES(aciklama), baslangic_saati=VALUES(baslangic_saati), bitis_saati=VALUES(bitis_saati)";
            $pdo->prepare($sql)->execute([$user_id, $yil, $ay, $gun, $v['yasal'], $v['gorev_turu'], $v['aciklama'], $v['bas'], $v['bit']]);
        }
        $pdo->commit();
        echo json_encode(['status' => 'success']);
    }

    // =================================================================
    // 5. KİLİTLE (ANA KİLİT)
    // =================================================================
    elseif ($action === 'kilitle') {
        $yil = intval($_POST['yil']); $ay = intval($_POST['ay']);
        $pdo->prepare("UPDATE puantaj_aylik SET kilit_durumu = 'Kilitli' WHERE personel_id = ? AND yil = ? AND ay = ?")->execute([$user_id, $yil, $ay]);
        echo json_encode(['status' => 'success', 'message' => 'Ay sonu kilidi vuruldu.']);
    }

    // =================================================================
    // 6. ARAZİ KİLİTLE
    // =================================================================
    elseif ($action === 'arazi_kilitle') {
        $yil = intval($_POST['yil']); 
        $bas = intval($_POST['bas_ay']); 
        $bit = intval($_POST['bit_ay']);
        $pdo->prepare("UPDATE puantaj_aylik SET kilit_arazi = 'Kilitli' WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ?")->execute([$user_id, $yil, $bas, $bit]);
        echo json_encode(['status' => 'success', 'message' => 'Arazi dönemi kilitlendi.']);
    }

    // =================================================================
    // 7. ARAZİ DETAY KAYDET
    // =================================================================
    elseif ($action === 'arazi_detay_kaydet') {
        $yil = $_POST['yil']; 
        $detaylar = $_POST['detay'] ?? [];
        
        $pdo->beginTransaction();
        foreach ($detaylar as $ay_no => $gunler) {
            $ay_no = intval($ay_no);
            $locks = getLockStates($pdo, $user_id, $yil, $ay_no);
            if ($locks['kilit_arazi'] === 'Kilitli') continue;
            
            foreach ($gunler as $gun => $veriler) {
                $aciklama = isset($veriler['aciklama']) ? trim($veriler['aciklama']) : '';
                $gorev_turu_id = !empty($veriler['gorev_turu']) ? intval($veriler['gorev_turu']) : null;

                if ($aciklama == "" && empty($gorev_turu_id)) continue;
                
                $sql = "INSERT INTO arazi_tazminati_detay (personel_id, yil, ay, gun, aciklama, gorev_turu_id) 
                        VALUES (?, ?, ?, ?, ?, ?) 
                        ON DUPLICATE KEY UPDATE aciklama=VALUES(aciklama), gorev_turu_id=VALUES(gorev_turu_id)";
                $pdo->prepare($sql)->execute([$user_id, $yil, $ay_no, $gun, $aciklama, $gorev_turu_id]);
            }
        }
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Arazi detayları kaydedildi.']);
    }

    // =================================================================
    // 8. SEYYAR KAYDET (YENİ EKLENDİ)
    // =================================================================
    elseif ($action === 'seyyar_kaydet') {
        $tarih = $_POST['tarih'];
        $mahalle = $_POST['mahalle'];
        $aciklama = $_POST['aciklama'];

        if (!empty($tarih) && !empty($mahalle)) {
            // Tarihten yıl ve ayı çıkarıp kilit kontrolü yapalım
            $time = strtotime($tarih);
            $s_yil = date('Y', $time);
            $s_ay = date('n', $time);
            
            $locks = getLockStates($pdo, $user_id, $s_yil, $s_ay);
            if ($locks['kilit_seyyar'] === 'Kilitli') {
                echo json_encode(['status' => 'error', 'message' => 'Bu aya ait seyyar görev kayıtları kilitlidir. Ekleme yapılamaz.']);
                exit;
            }

            $stmt = $pdo->prepare("INSERT INTO seyyar_gorev_detay (personel_id, tarih, mahalle, aciklama) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$user_id, $tarih, $mahalle, $aciklama])) {
                echo json_encode(['status' => 'success', 'message' => 'Kayıt eklendi.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Tarih ve Mahalle bilgisi eksik.']);
        }
    }

    // =================================================================
    // 9. SEYYAR SİL (YENİ EKLENDİ)
    // =================================================================
    elseif ($action === 'seyyar_sil') {
        $id = intval($_POST['id']);
        
        // Önce tarihi bulup kilit kontrolü yapmamız lazım
        $stmt_check = $pdo->prepare("SELECT tarih FROM seyyar_gorev_detay WHERE id = ? AND personel_id = ?");
        $stmt_check->execute([$id, $user_id]);
        $row = $stmt_check->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $time = strtotime($row['tarih']);
            $s_yil = date('Y', $time);
            $s_ay = date('n', $time);
            
            $locks = getLockStates($pdo, $user_id, $s_yil, $s_ay);
            if ($locks['kilit_seyyar'] === 'Kilitli') {
                echo json_encode(['status' => 'error', 'message' => 'Bu dönem kilitli olduğu için silme işlemi yapılamaz.']);
                exit;
            }

            $stmt = $pdo->prepare("DELETE FROM seyyar_gorev_detay WHERE id = ? AND personel_id = ?");
            if ($stmt->execute([$id, $user_id])) {
                echo json_encode(['status' => 'success', 'message' => 'Kayıt silindi.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Silme başarısız.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Kayıt bulunamadı.']);
        }
    }
    // =================================================================
    // 10. SEYYAR DÖNEM KİLİTLE (YENİ)
    // =================================================================
    elseif ($action === 'seyyar_kilitle') {
        $yil = intval($_POST['yil']);
        $donem = intval($_POST['donem']); // 1 veya 2

        if ($donem == 1) { $bas = 1; $bit = 6; } 
        else { $bas = 7; $bit = 12; }

        // O aralıktaki tüm ayların 'kilit_seyyar' sütununu güncelle
        // Eğer ay kaydı yoksa oluşturmaz, sadece var olan puantaj satırlarını kilitler.
        // Genelde puantaj satırı ana sayfadan oluşur ama biz garanti olsun diye UPDATE yapıyoruz.
        
        $sql = "UPDATE puantaj_aylik SET kilit_seyyar = 'Kilitli' WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id, $yil, $bas, $bit]);

        echo json_encode(['status' => 'success', 'message' => 'Seyyar görev dönemi kilitlendi.']);
    }

    // =================================================================
    // 11. SEYYAR DÖNEM KİLİDİNİ AÇ (OPSİYONEL - YÖNETİCİ İÇİN)
    // =================================================================
    elseif ($action === 'seyyar_kilit_ac') {
        $yil = intval($_POST['yil']);
        $donem = intval($_POST['donem']);

        if ($donem == 1) { $bas = 1; $bit = 6; } 
        else { $bas = 7; $bit = 12; }

        $sql = "UPDATE puantaj_aylik SET kilit_seyyar = 'Açık' WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id, $yil, $bas, $bit]);

        echo json_encode(['status' => 'success', 'message' => 'Seyyar görev kilidi açıldı.']);
    }
    // =================================================================
    // 12. SEYYAR TOPLU KAYDET (YENİ SİSTEM)
    // =================================================================
    elseif ($action === 'seyyar_toplu_kaydet') {
        $veriler = $_POST['veriler'] ?? [];
        
        $pdo->beginTransaction();
        
        foreach ($veriler as $tarih => $v) {
            $mahalle = $v['mahalle'] ?? '';
            $aciklama = $v['aciklama'] ?? '';
            
            // Kilit kontrolü (Tarihin yılı ve ayına göre)
            $time = strtotime($tarih);
            $s_yil = date('Y', $time);
            $s_ay = date('n', $time);
            
            $locks = getLockStates($pdo, $user_id, $s_yil, $s_ay);
            if ($locks['kilit_seyyar'] === 'Kilitli') continue; // Kilitliyse atla

            // Eğer açıklama boşsa ve mahalle de yoksa kaydetmeye gerek yok mu? 
            // Hayır, açıklama boş olsa bile mahalleyi kaydetmek isteyebiliriz rapor için.
            
            // INSERT INTO ... ON DUPLICATE KEY UPDATE
            // Yani varsa güncelle, yoksa ekle
            $sql = "INSERT INTO seyyar_gorev_detay (personel_id, tarih, mahalle, aciklama) 
                    VALUES (?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE mahalle=VALUES(mahalle), aciklama=VALUES(aciklama)";
            
            $pdo->prepare($sql)->execute([$user_id, $tarih, $mahalle, $aciklama]);
        }
        
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Tüm değişiklikler kaydedildi.']);
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Hata: ' . $e->getMessage()]);
}
?>