<?php
// ajax/ajax_arac_gorev_islem.php
session_start();

// Yetki Kontrolü
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Yetkiniz yok.']);
    exit();
}

header('Content-Type: application/json');
include_once '../config/db.php'; 
include_once '../includes/functions.php';

// Action değişkenini güvenli al
$action = $_POST['action'] ?? '';

// =================================================================================
// BÖLÜM 1: SADECE OKUMA YAPAN (SELECT) İŞLEMLER (Transaction GEREKTİRMEZ)
// =================================================================================

// 1. ŞOFÖR GÖREV TÜRLERİNİ GETİR (Hatasız Sürüm)
if ($action == 'sofor_gorev_turleri_getir') {
    try {
        $sofor_id = $_POST['sofor_id'];

        // 1. Personelin birim_id'sini al
        $stmt = $pdo->prepare("SELECT birimler_id FROM personel_bilgileri WHERE id = :id");
        $stmt->execute([':id' => $sofor_id]);
        $personel = $stmt->fetch(PDO::FETCH_ASSOC);
        $birim_id = $personel['birimler_id'] ?? 0;

        // 2. Önce birime özel görevleri al
        $stmt = $pdo->prepare("
            SELECT id, ad 
            FROM gorev_turleri 
            WHERE birim_id = :birim_id 
            AND yer_turu = 'arazi'
            AND aktif = 1
            ORDER BY ad ASC
        ");
        $stmt->execute([':birim_id' => $birim_id]);
        $sonuc = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Eğer birime özel görev yoksa, tüm görevleri getir
        if (empty($sonuc)) {
            $stmt = $pdo->prepare("
                SELECT id, ad 
                FROM gorev_turleri 
                WHERE yer_turu = 'arazi'
                AND aktif = 1
                ORDER BY ad ASC
            ");
            $stmt->execute();
            $sonuc = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        echo json_encode(['status' => 'success', 'data' => $sonuc]);
        exit;

    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}


// 2. ARAÇ SON KİLOMETRESİNİ GETİR
if ($action === 'son_km_getir') {
    try {
        $arac_id = (int)$_POST['arac_id'];
        
        $stmt = $pdo->prepare("SELECT km_son FROM araclar WHERE id = ?");
        $stmt->execute([$arac_id]);
        $ana_tablo_km = $stmt->fetchColumn();

        $stmt2 = $pdo->prepare("SELECT MAX(donus_km) FROM arac_gorevler WHERE arac_id = ? AND onay_durumu = 1");
        $stmt2->execute([$arac_id]);
        $gecmis_max_km = $stmt2->fetchColumn();

        $son_km = max((float)$ana_tablo_km, (float)$gecmis_max_km);
        
        echo json_encode(['status' => 'success', 'son_km' => $son_km]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}

// 3. DETAY GETİR
if ($action === 'detay_getir') {
    try {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("SELECT * FROM arac_gorevler WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($data) {
            $stmt_p = $pdo->prepare("SELECT personel_id FROM arac_gorev_personel WHERE gorev_id = ? AND rol = 'Personel'");
            $stmt_p->execute([$id]);
            $data['personel_ids'] = $stmt_p->fetchAll(PDO::FETCH_COLUMN);

            $stmt_m = $pdo->prepare("SELECT mahalleler_id FROM arac_gorev_mahalle WHERE gorev_id = ?");
            $stmt_m->execute([$id]);
            $data['mahalleler_ids'] = $stmt_m->fetchAll(PDO::FETCH_COLUMN);

            $data['cikis_km'] = (string)$data['cikis_km'];
            $data['donus_km'] = (string)$data['donus_km'];
            $data['yakit_alinan'] = (string)$data['yakit_alinan'];
            
            // Tarih formatı düzeltme
            if ($data['donus_tarihi']) {
                $data['donus_tarihi'] = str_replace(' ', 'T', $data['donus_tarihi']);
                if (strpos($data['donus_tarihi'], 'T') === false) {
                     $data['donus_tarihi'] .= 'T' . ($data['bitis_saati'] ? $data['bitis_saati'] : '00:00');
                }
            }
            echo json_encode(['status' => 'success', 'data' => $data]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Kayıt bulunamadı']);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}


// =================================================================================
// BÖLÜM 2: VERİ DEĞİŞİKLİĞİ YAPAN İŞLEMLER (TRANSACTION GEREKTİRİR)
// =================================================================================

$response = ['status' => 'error', 'message' => 'İşlem başarısız.'];

try {
    $pdo->beginTransaction();

    // 4. GÖREV BAŞLAT (KAYDET)
    if ($action === 'kaydet') {

    // Veri Çekme
    $arac_id = (int)$_POST['arac_id'];
    $gorev_turu_id = (int)$_POST['gorev_turu_id'];
    $sofor_id = (int)$_POST['sofor_id'];
    $birim_amiri_id = (int)$_POST['birim_amiri_id'];
    $kurum_amiri_id = (int)$_POST['kurum_amiri_id'];
    $tarih = trim($_POST['tarih']);
    $baslangic_saati = trim($_POST['baslangic_saati']);
    $cikis_km = (float)$_POST['cikis_km']; 

    $mahalleler_ids = isset($_POST['mahalleler_ids']) ? $_POST['mahalleler_ids'] : [];
    $personel_ids = isset($_POST['personel_ids']) ? $_POST['personel_ids'] : [];

    // ZORUNLULUK KONTROLLERİ
    if ($arac_id <= 0) throw new Exception("Araç seçimi zorunludur!");
    if ($gorev_turu_id <= 0) throw new Exception("Görev Türü seçimi zorunludur!");
    if ($sofor_id <= 0) throw new Exception("Şoför seçimi zorunludur!");
    if ($birim_amiri_id <= 0) throw new Exception("Birim Amiri seçimi zorunludur!");
    if ($kurum_amiri_id <= 0) throw new Exception("Kurum Amiri seçimi zorunludur!");
    if (empty($mahalleler_ids)) throw new Exception("En az bir Mahalle seçimi zorunludur!");
    if (empty($tarih)) throw new Exception("Tarih boş bırakılamaz!");
    if (empty($baslangic_saati)) throw new Exception("Saat boş bırakılamaz!");
    if ($cikis_km <= 0) throw new Exception("Çıkış KM girilmelidir!");

    // ARAÇ MÜSAİT Mİ?
    $kontrol_stmt = $pdo->prepare("SELECT gorev_no FROM arac_gorevler WHERE arac_id = ? AND onay_durumu = 0");
    $kontrol_stmt->execute([$arac_id]);
    $aktif_gorev_no = $kontrol_stmt->fetchColumn();

    if ($aktif_gorev_no) {
        throw new Exception("Araç {$aktif_gorev_no} nolu görevde! Önce o görevi bitirin.");
    }

    // --- GÖREV NO (YIL BAZLI) ---
    $yil = date('Y', strtotime($tarih));
    $stmt_no = $pdo->prepare("SELECT MAX(gorev_no) FROM arac_gorevler WHERE YEAR(tarih) = ?");
    $stmt_no->execute([$yil]);
    $max_no = $stmt_no->fetchColumn();
    $yeni_gorev_no = $max_no ? $max_no + 1 : 1;

    // --- SIRA NO (ARAÇ BAZLI, YIL İÇİNDE) ---
    $stmt_sira = $pdo->prepare("SELECT MAX(sira_no) FROM arac_gorevler WHERE arac_id = ? AND YEAR(tarih) = ?");
    $stmt_sira->execute([$arac_id, $yil]);
    $max_sira = $stmt_sira->fetchColumn();
    $yeni_sira_no = $max_sira ? $max_sira + 1 : 1;

    // KAYDET
    $sql = "INSERT INTO arac_gorevler (
                gorev_no, sira_no, tarih, arac_id, baslangic_saati, cikis_km, sofor_id, gorev_turu_id, 
                birim_amiri_id, kurum_amiri_id, onay_durumu, kapali
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0
            )";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $yeni_gorev_no, $yeni_sira_no, $tarih, $arac_id, $baslangic_saati, $cikis_km,
        $sofor_id, $gorev_turu_id, $birim_amiri_id, $kurum_amiri_id
    ]);

    $gorev_id = $pdo->lastInsertId();

    if ($gorev_id) {
        $stmt_p = $pdo->prepare("INSERT INTO arac_gorev_personel (gorev_id, personel_id, rol) VALUES (?, ?, ?)");
        if (!empty($sofor_id)) $stmt_p->execute([$gorev_id, $sofor_id, 'Şoför']);
        foreach ($personel_ids as $pid) {
            if ((int)$pid != (int)$sofor_id) $stmt_p->execute([$gorev_id, $pid, 'Personel']);
        }

        $stmt_m = $pdo->prepare("INSERT INTO arac_gorev_mahalle (gorev_id, mahalleler_id) VALUES (?, ?)");
        foreach ($mahalleler_ids as $mid) {
            $stmt_m->execute([$gorev_id, $mid]);
        }
    }

    $response = [
        'status' => 'success',
        'message' => "Görev başlatıldı. Görev No: $yeni_gorev_no, Sıra No: $yeni_sira_no"
    ];
}

    // 5. GÖREVİ BİTİR (DÖNÜŞ YAP)
    elseif ($action === 'gorev_bitir') {

        $id = (int)$_POST['gorev_id'];
        $donus_saat = $_POST['bitis_saati'] ?? ''; // İsim düzeltmesi: bitis_saati formdan geliyor
        $donus_tarihi = $_POST['donus_tarihi'] ?? '';
        $donus_km = $_POST['donus_km'] ?? 0;
        $yakit = $_POST['yakit_alinan'] ?? 0;

        if (empty($donus_saat) || empty($donus_tarihi)) {
            throw new Exception("Dönüş bilgilerini doldurunuz.");
        }

        // Doğru tablodan çekiyoruz: arac_gorevler
        $stmt = $pdo->prepare("SELECT id, tarih, baslangic_saati, kapali FROM arac_gorevler WHERE id = ?");
        $stmt->execute([$id]);
        $g = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$g) throw new Exception("Görev bulunamadı.");
        if ($g['kapali'] == 1) throw new Exception("Görev zaten kapatılmış.");

        // Saat kontrolü (Basit string karşılaştırma yerine timestamp önerilir ama şimdilik format aynıysa çalışır)
        // $cikis_dt = new DateTime($g['tarih'].' '.$g['baslangic_saati']); ...

        $stmt = $pdo->prepare("
            UPDATE arac_gorevler
            SET 
                bitis_saati = ?,
                donus_tarihi = ?,
                donus_km = ?,
                yakit_alinan = ?,
                onay_durumu = 1,
                kapali = 1
            WHERE id = ?
        ");
        $stmt->execute([$donus_saat, $donus_tarihi, $donus_km, $yakit, $id]);

        $response = ['status' => 'success', 'message' => 'Görev başarıyla tamamlandı.'];
    }

    // 6. SİL
    elseif ($action === 'sil') {

        $id = (int)$_POST['id'];

        $stmt = $pdo->prepare("SELECT id, arac_id, onay_durumu FROM arac_gorevler WHERE id = ?");
        $stmt->execute([$id]);
        $gorev = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$gorev) throw new Exception("Görev bulunamadı.");
        if ($gorev['onay_durumu'] == 1) throw new Exception("Onaylanmış görev silinemez!");

        // Son görev mi kontrolü
        $stmt2 = $pdo->prepare("SELECT MAX(id) FROM arac_gorevler WHERE arac_id = ?");
        $stmt2->execute([$gorev['arac_id']]);
        $son_id = $stmt2->fetchColumn();

        if ($son_id == $id) {
            // Son kayıt -> Tamamen Sil
            $pdo->prepare("DELETE FROM arac_gorev_mahalle WHERE gorev_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM arac_gorev_personel WHERE gorev_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM arac_gorevler WHERE id = ?")->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Son görev tamamen silindi.'];
        } else {
            // Aradaki kayıt -> İptal et (Soft Delete)
            $pdo->prepare("UPDATE arac_gorevler SET onay_durumu = 3, kapali = 1 WHERE id = ?")->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Görev iptal edildi (Arşivlendi).'];
        }
    }

    // 7. GÜNCELLE
    elseif ($action === 'guncelle') {
        $gorev_id = (int)$_POST['gorev_id'];
        
        $check = $pdo->prepare("SELECT onay_durumu FROM arac_gorevler WHERE id = ?");
        $check->execute([$gorev_id]);
        if($check->fetchColumn() == 1) throw new Exception("Onaylanmış görev güncellenemez.");
        
        // Verileri al
        $tarih = trim($_POST['tarih']);
        $arac_id = (int)$_POST['arac_id'];
        $gorev_turu_id = (int)$_POST['gorev_turu_id']; 
        $sofor_id = (int)$_POST['sofor_id'];
        $birim_amiri_id = (int)$_POST['birim_amiri_id'];
        $kurum_amiri_id = (int)$_POST['kurum_amiri_id'];
        $baslangic_saati = trim($_POST['baslangic_saati']);
        $cikis_km = (float)$_POST['cikis_km']; 
        $mahalleler_ids = isset($_POST['mahalleler_ids']) ? $_POST['mahalleler_ids'] : [];

        // Basit Kontrol
        if ($arac_id <= 0) throw new Exception("Araç seçimi zorunludur!");
        
        // Güncelle
        $sql = "UPDATE arac_gorevler SET 
                    tarih = ?, arac_id = ?, baslangic_saati = ?, cikis_km = ?, sofor_id = ?, gorev_turu_id = ?, 
                    birim_amiri_id = ?, kurum_amiri_id = ?
                WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $tarih, $arac_id, $baslangic_saati, $cikis_km, $sofor_id, $gorev_turu_id, 
            $birim_amiri_id, $kurum_amiri_id, $gorev_id
        ]);

        // İlişkileri temizle ve yeniden ekle
        $pdo->prepare("DELETE FROM arac_gorev_personel WHERE gorev_id = ?")->execute([$gorev_id]);
        $pdo->prepare("DELETE FROM arac_gorev_mahalle WHERE gorev_id = ?")->execute([$gorev_id]);

        $personel_ids = isset($_POST['personel_ids']) ? $_POST['personel_ids'] : [];
        
        $stmt_p = $pdo->prepare("INSERT INTO arac_gorev_personel (gorev_id, personel_id, rol) VALUES (?, ?, ?)");
        if (!empty($sofor_id)) $stmt_p->execute([$gorev_id, $sofor_id, 'Şoför']);
        foreach ($personel_ids as $pid) {
            if ((int)$pid != (int)$sofor_id) $stmt_p->execute([$gorev_id, $pid, 'Personel']);
        }

        $stmt_m = $pdo->prepare("INSERT INTO arac_gorev_mahalle (gorev_id, mahalleler_id) VALUES (?, ?)");
        foreach ($mahalleler_ids as $mid) {
            $stmt_m->execute([$gorev_id, $mid]);
        }

        $response = ['status' => 'success', 'message' => 'Görev güncellendi.'];
    }

    // İşlem başarılıysa onayla
    $pdo->commit();

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response = ['status' => 'error', 'message' => 'Veritabanı Hatası: ' . $e->getMessage()];
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response = ['status' => 'error', 'message' => $e->getMessage()];
}

echo json_encode($response);
exit;
?>