<?php
// index.php veya dashboard.php (Ana Sayfa)
session_start();

// Kullanıcı giriş yapmamışsa login sayfasına at
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}

$ad_soyad = $_SESSION["ad_soyad"];
// Yetki kontrolü (Yönetim paneli butonu için)
$yetki = $_SESSION["yetki_id"] ?? 0; 
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ana Sayfa - Görev Takip</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f4f7f6;
            margin: 0; padding: 0;
        }
        .welcome-section {
            background: #007bff;
            padding: 40px 20px;
            color: white;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            padding: 40px 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        .menu-box {
            background: white;
            width: 220px;
            padding: 30px 20px;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            border: 1px solid #eee;
        }
        .menu-box i {
            font-size: 40px;
            color: #007bff;
        }
        .menu-box span {
            font-weight: 600;
            color: #333;
            font-size: 16px;
        }
        .menu-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            background: #fff;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 15px;
            color: #ffcccc;
            text-decoration: none;
            font-size: 14px;
            border: 1px solid #ffcccc;
            padding: 5px 15px;
            border-radius: 20px;
        }
        .logout-btn:hover { background: rgba(255,255,255,0.1); }
        a { text-decoration: none; }
    </style>
</head>
<body>

<div class="welcome-section">
    <h1>Hoş Geldiniz, <?php echo $ad_soyad; ?></h1>
    <p>Araç Kayıt ve Görev Takip Sisteminde yapmak istediğiniz işlemi seçiniz.</p>
    <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Güvenli Çıkış</a>
</div>

<div class="container">

    <a href="pages/puantaj.php">
        <div class="menu-box">
            <i class="fas fa-calendar-check"></i>
            <span>Puantaj İşlemleri</span>
        </div>
    </a>

    <a href="pages/resmi_arac_gorev.php">
        <div class="menu-box">
            <i class="fas fa-car-side"></i>
            <span>Resmî Araç Görev</span>
        </div>
    </a>

    <a href="pages/ozel_arac_gorev.php">
        <div class="menu-box">
            <i class="fas fa-car"></i>
            <span>Özel Araç Görev</span>
        </div>
    </a>

    <a href="pages/izin_takip.php">
        <div class="menu-box">
            <i class="fas fa-user-clock"></i>
            <span>İzin Takip</span>
        </div>
    </a>

    <a href="pages/raporlar/puantaj_rapor.php">
        <div class="menu-box">
            <i class="fas fa-chart-bar"></i>
            <span>Genel Raporlar</span>
        </div>
    </a>

    <?php if($yetki == 1): // Sadece Admin görsün ?>
    <a href="admin/kullanicilar.php">
        <div class="menu-box">
            <i class="fas fa-user-shield"></i>
            <span>Yönetim Paneli</span>
        </div>
    </a>
    <?php endif; ?>

</div>

</body>
</html>