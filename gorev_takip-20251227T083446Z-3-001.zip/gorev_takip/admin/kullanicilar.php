CREATE TABLE kullanicilar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ad_soyad VARCHAR(100) NOT NULL,
    kullanici_adi VARCHAR(50) NOT NULL UNIQUE,
    sifre VARCHAR(255) NOT NULL,
    yetki ENUM('admin','personel') DEFAULT 'personel',
    aktif TINYINT(1) DEFAULT 1,
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Örnek kullanıcı ekleme
INSERT INTO kullanicilar (ad_soyad, kullanici_adi, sifre, yetki)
VALUES ('Ali Kemal Güngör', 'akgungor', 
        '<?= password_hash("123456", PASSWORD_DEFAULT) ?>', 'admin');
