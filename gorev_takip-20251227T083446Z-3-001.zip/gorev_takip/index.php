<?php
// index.php
session_start();
require_once __DIR__ . "/config/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $tc_no = trim($_POST["tc_no"]);
    $sifre = trim($_POST["sifre"]);

    // DÜZELTME 1: SQL sorgusuna 'p.id AS personel_gercek_id' ekledik.
    // Bu sayede Personel Tablosundaki ID'yi (6) alabileceğiz.
    $sql = "SELECT k.*, 
                   p.id AS personel_gercek_id, 
                   p.birimler_id, 
                   b.birim_adi 
            FROM kullanicilar k 
            LEFT JOIN personel_bilgileri p ON k.tc_no = p.tc_no 
            LEFT JOIN birimler b ON p.birimler_id = b.id 
            WHERE k.tc_no = :tc_no AND k.aktif = 1";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute(["tc_no" => $tc_no]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($sifre, $user["sifre"])) {
        session_regenerate_id(true);

        // DÜZELTME 2: Session atamalarını Personel ID öncelikli yapıyoruz.
        
        // Eğer bu kullanıcının personel tablosunda karşılığı varsa (ID: 6) onu kullan
        if (!empty($user["personel_gercek_id"])) {
            $_SESSION["user_id"] = $user["personel_gercek_id"]; // Artık burası 6 olacak!
        } else {
            // Personel kaydı yoksa mecburen kullanıcı ID'sini kullan (ID: 4)
            $_SESSION["user_id"] = $user["id"]; 
        }

        // Diğer bilgiler
        $_SESSION["ad_soyad"]    = $user["ad_soyad"];
        $_SESSION["tc_no"]       = $user["tc_no"];
        $_SESSION["rol_id"]      = $user["rol_id"];
        $_SESSION["birim_id"]    = $user["birimler_id"] ? $user["birimler_id"] : 0; 
        $_SESSION["birim_adi"]   = $user["birim_adi"] ? $user["birim_adi"] : ""; 

        // Ekstra: Gerçek Kullanıcı ID'sini de saklayalım (Belki ilerde lazım olur)
        $_SESSION["login_user_id"] = $user["id"]; 

        header("Location: anasayfa.php");
        exit;
    } else {
        $hata = "❌ T.C. veya şifre hatalı!";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Görev Takip - Giriş</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
    body { font-family: Arial, sans-serif; background: #f5f7fa; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
    .login-container { background:#fff; padding:30px; border-radius:10px; box-shadow:0 0 20px rgba(0,0,0,0.1); width:320px; text-align:center; }
    h2 { color:#333; margin-bottom:20px; font-size: 20px; }
    label { display: block; text-align: left; margin-bottom: 5px; font-weight: bold; font-size: 14px; color: #555; }
    input { width:100%; padding:10px; margin-bottom:15px; border-radius:5px; border:1px solid #ccc; box-sizing: border-box; }
    button { width:100%; padding:10px; background:#0d6efd; border:none; border-radius:5px; color:white; font-weight:bold; cursor:pointer; font-size: 16px; transition: 0.3s; }
    button:hover { background:#0b5ed7; }
    .error { color:#dc3545; margin-top:15px; font-size:14px; background-color: #f8d7da; padding: 10px; border-radius: 5px; border: 1px solid #f5c6cb; }
</style>
</head>
<body>
<div class="login-container">
    <h2>Araç Kayıt ve Görev Takip</h2>
    <form method="post">
        <label>T.C. Kimlik No</label>
        <input type="text" name="tc_no" required placeholder="T.C. No giriniz" autocomplete="off">
        
        <label>Şifre</label>
        <input type="password" name="sifre" required placeholder="Şifreniz">
        
        <button type="submit">Giriş Yap</button>
        
        <?php if (!empty($hata)) echo "<div class='error'>$hata</div>"; ?>
    </form>
</div>
</body>
</html>