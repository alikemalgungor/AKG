<?php
// pages/resmi_arac_gorev.php
include_once '../includes/header.php';
include_once '../config/db.php'; 
include_once '../includes/functions.php'; 

// --- 1. ÖZEL YÖNETİCİ LİSTELERİNİ ÇEKME ---

// A) GÖREVLENDİREN AMİRLER
$sql_birim = "
    SELECT 
        y.personel_id, 
        p.ad_soyad, 
        p.unvan, 
        b.birim_adi, 
        y.varsayilan
    FROM yonetici_listesi y
    JOIN personel_bilgileri p ON y.personel_id = p.id
    LEFT JOIN birimler b ON p.birimler_id = b.id
    WHERE y.rol = 'BIRIM_AMIRI' AND y.aktif = 1
    ORDER BY y.varsayilan DESC, p.ad_soyad ASC
";
$birim_amirleri = $pdo->query($sql_birim)->fetchAll(PDO::FETCH_ASSOC);

// B) ONAYLAYAN AMİRLER
$sql_mudur = "
    SELECT 
        y.personel_id, 
        p.ad_soyad, 
        p.unvan, 
        y.unvan_gorunumu, 
        y.varsayilan
    FROM yonetici_listesi y
    JOIN personel_bilgileri p ON y.personel_id = p.id
    WHERE y.rol = 'KURUM_AMIRI' AND y.aktif = 1
    ORDER BY y.varsayilan DESC, p.ad_soyad ASC
";
$kurum_amirleri = $pdo->query($sql_mudur)->fetchAll(PDO::FETCH_ASSOC);


// --- 2. DİĞER VERİLERİ ÇEKME ---
try {
    
   // Personel Listesi (Sadece Araç Kullanım Oluru Olanlar)
// NOT: arac_kullanim_oluru = 1 şartını buraya ekliyoruz.
$personeller = aktif_personeller("arac_kullanim_oluru = 1");

    // Araçlar
    $stmt_arac = $pdo->query("SELECT id, plaka, marka_model FROM araclar ORDER BY plaka");
    $araclar = $stmt_arac->fetchAll(PDO::FETCH_ASSOC);
    
    // Görev Türleri
    $stmt_gorev_turu = $pdo->query("SELECT id, ad FROM gorev_turleri");
    $gorev_turleri = $stmt_gorev_turu->fetchAll(PDO::FETCH_ASSOC);
    
    // Mahalleler
    $stmt_mahalle = $pdo->query("SELECT id, ad FROM mahalleler ORDER BY ad");
    $mahalleler = $stmt_mahalle->fetchAll(PDO::FETCH_ASSOC);

    // Ana Görev Listesi
    $stmt_gorevler = $pdo->query("
        SELECT 
            ag.id, ag.gorev_no, ag.tarih, ag.baslangic_saati, ag.cikis_km, ag.onay_durumu, ag.donus_km,
            a.plaka, gt.ad as gorev_turu_ad, 
            s.ad_soyad as sofor_ad, 
            ba.ad_soyad as birim_amiri_ad, 
            ka.ad_soyad as kurum_amiri_ad,
            GROUP_CONCAT(DISTINCT p.ad_soyad SEPARATOR ', ') as gorevli_personeller_str,
            GROUP_CONCAT(DISTINCT m.ad SEPARATOR ', ') as gidilen_mahalleler_str
        FROM arac_gorevler ag
        LEFT JOIN araclar a ON ag.arac_id = a.id
        LEFT JOIN gorev_turleri gt ON ag.gorev_turu_id = gt.id
        LEFT JOIN personel_bilgileri s ON ag.sofor_id = s.id 
        LEFT JOIN personel_bilgileri ba ON ag.birim_amiri_id = ba.id
        LEFT JOIN personel_bilgileri ka ON ag.kurum_amiri_id = ka.id
        LEFT JOIN arac_gorev_personel agp ON ag.id = agp.gorev_id AND agp.rol = 'Personel'
        LEFT JOIN personel_bilgileri p ON agp.personel_id = p.id 
        LEFT JOIN arac_gorev_mahalle agm ON ag.id = agm.gorev_id
        LEFT JOIN mahalleler m ON agm.mahalleler_id = m.id
        GROUP BY ag.id
        ORDER BY ag.tarih DESC, ag.baslangic_saati DESC
    ");
    $gorev_listesi = $stmt_gorevler->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Veritabanı hatası: " . $e->getMessage());
}
?>

<style>
    /* Inputların genişliğini ve okunabilirliğini artırma */
    input[type="date"], 
    input[type="time"], 
    input[type="datetime-local"],
    input[type="number"],
    input[type="text"] {
        width: 100%;
        min-width: 100%;
        padding: 0.5rem;
        font-size: 1rem;
    }
    
    /* Select2 kutularının yüksekliğini inputlarla eşitleme */
    .select2-container .select2-selection--single {
        height: 38px !important;
        padding-top: 5px !important;
    }
    
    /* Label'ları kalınlaştırarak belirgin yapma */
    .form-label {
        font-weight: 600;
        margin-bottom: 0.3rem;
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Resmi Araç Görev Kayıtları</h5>
            <button class="btn btn-light" onclick="yeniKayitModal()">
                <i class="fas fa-plus"></i> Yeni Görev Kaydı
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="gorevTablosu" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Görev No</th>
                            <th>Tarih</th>
                            <th>Plaka</th>
                            <th>Görev Türü</th>
                            <th>Şoför</th>
                            <th>Görevli Personel</th> 
                            <th>Gidilen Mahalleler</th> 
                            <th>Çıkış KM</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gorev_listesi as $gorev): ?>
                        <tr class="<?php echo ($gorev['onay_durumu'] == 1) ? 'table-success' : ''; ?>">
                            <td><?php echo htmlspecialchars($gorev['gorev_no']); ?></td>
                            <td><?php echo tarih_formatla($gorev['tarih']); ?></td>
                            <td><?php echo htmlspecialchars($gorev['plaka']); ?></td>
                            <td><?php echo htmlspecialchars($gorev['gorev_turu_ad']); ?></td>
                            <td><?php echo htmlspecialchars($gorev['sofor_ad']); ?></td>
                            <td><?php echo htmlspecialchars($gorev['gorevli_personeller_str'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($gorev['gidilen_mahalleler_str']); ?></td>
                            <td><?php echo htmlspecialchars($gorev['cikis_km']); ?></td>
                            <td>
                                <?php if ($gorev['onay_durumu'] == 1): ?>
    <span class="badge bg-success">Tamamlandı</span>

<?php elseif ($gorev['onay_durumu'] == 3): ?>
    <span class="badge bg-secondary">İptal</span>

<?php else: ?>
    <span class="badge bg-warning text-dark">Görevde</span>
<?php endif; ?>

                            </td>
                            <td class="text-nowrap">
                                <div class="btn-group" role="group">
                                    <a href="yazdir_resmi_gorev.php?id=<?php echo $gorev['id']; ?>" 
                                       target="_blank" class="btn btn-warning btn-sm" title="Yazdır">
                                       <i class="fas fa-print"></i>
                                    </a>
                                    
                                    <?php if($gorev['onay_durumu'] == 0): ?>
                                        <button class="btn btn-success btn-sm gorev-bitir" data-id="<?php echo $gorev['id']; ?>" title="Görevi Bitir / Dönüş Yap">
                                            <i class="fas fa-check-circle"></i>
                                        </button>
                                        
                                        <button class="btn btn-primary btn-sm gorev-duzenle" data-id="<?php echo $gorev['id']; ?>" title="Düzenle">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <button class="btn btn-danger btn-sm gorev-sil" data-id="<?php echo $gorev['id']; ?>" title="Sil">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-info btn-sm gorev-incele" data-id="<?php echo $gorev['id']; ?>" title="İncele">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="gorevKayitModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalBaslik">Yeni Görev Başlat</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="aracGorevForm">
                    <input type="hidden" name="gorev_id" id="gorev_id">
                    <input type="hidden" name="islem_turu" id="islem_turu" value="kaydet"> 

                    <div id="cikis_bilgileri">
                        <h6 class="text-primary border-bottom pb-2">Çıkış Bilgileri</h6>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Görev No</label>
                                <input type="text" class="form-control" name="gorev_no" id="gorev_no" placeholder="Otomatik" readonly>
                            </div>
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Tarih <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="tarih" id="tarih" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Araç <span class="text-danger">*</span></label>
                                <select class="form-select" name="arac_id" id="arac_id" required onchange="getAracSonKm(this.value)">
                                    <option value="">Seçiniz</option>
                                    <?php foreach ($araclar as $arac): ?>
                                        <option value="<?php echo $arac['id']; ?>"><?php echo htmlspecialchars($arac['plaka']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Çıkış KM</label>
                                <input type="number" class="form-control" name="cikis_km" id="cikis_km" required readonly>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3"> 
                                <label class="form-label">Başlangıç Saati <span class="text-danger">*</span></label>
                                <input type="time" class="form-control" name="baslangic_saati" id="baslangic_saati" required>
                            </div>
                            <div class="col-md-4 mb-3"> 
                                <label class="form-label">Şoför <span class="text-danger">*</span></label>
                                <select class="form-select" name="sofor_id" id="sofor_id" required>
                                     <option value="">Seçiniz</option>
                                     <?php foreach ($personeller as $p): ?>
                                        <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option>
                                     <?php endforeach; ?>
                                </select>
                            </div>
                             <div class="col-md-4 mb-3"> 
                                <label class="form-label">Görev Türü <span class="text-danger">*</span></label>
                                <select class="form-select" name="gorev_turu_id" id="gorev_turu_id" required>
                                    <option value="">Seçiniz</option>
                                     <?php foreach ($gorev_turleri as $t): ?>
                                        <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['ad']); ?></option>
                                     <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Diğer Görevli Personeller <span class="text-muted">(Şoför haricindekiler)</span></label>
                                <select name="personel_ids[]" id="personel_ids" class="form-control select2" multiple="multiple" style="width: 100%;">
                                    <?php foreach ($personeller as $p): ?>
                                        <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Gidilecek Yerler / Mahalleler <span class="text-danger">*</span></label>
                                <select name="mahalleler_ids[]" id="mahalleler_ids" class="form-control select2" multiple="multiple" required style="width: 100%;">
                                    <?php foreach ($mahalleler as $m): ?>
                                        <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['ad']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <h6 class="text-secondary border-bottom pb-2 mt-3">Onay ve Görevlendirme</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Görevlendiren Amir <span class="text-danger">*</span></label>
                                    <select name="birim_amiri_id" id="birim_amiri_id" class="form-control select2" required style="width: 100%;">
                                        <option value="">Seçiniz...</option>
                                        <?php foreach ($birim_amirleri as $ba): ?>
                                            <option value="<?php echo $ba['personel_id']; ?>" 
                                                <?php echo ($ba['varsayilan'] == 1) ? 'selected' : ''; ?>>
                                                <?php echo $ba['ad_soyad']; ?> 
                                                <?php 
                                                    if(!empty($ba['birim_adi'])) echo ' ('.$ba['birim_adi'].')';
                                                    elseif(!empty($ba['unvan'])) echo ' ('.$ba['unvan'].')';
                                                ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Onaylayan Kurum Amiri <span class="text-danger">*</span></label>
                                    <select name="kurum_amiri_id" id="kurum_amiri_id" class="form-control select2" required style="width: 100%;">
                                        <option value="">Seçiniz...</option>
                                        <?php foreach ($kurum_amirleri as $ka): ?>
                                            <option value="<?php echo $ka['personel_id']; ?>" 
                                                <?php echo ($ka['varsayilan'] == 1) ? 'selected' : ''; ?>>
                                                <?php echo $ka['ad_soyad']; ?>
                                                <?php 
                                                    $gosterilecek_unvan = !empty($ka['unvan_gorunumu']) ? $ka['unvan_gorunumu'] : $ka['unvan'];
                                                    echo ' ('.$gosterilecek_unvan.')'; 
                                                ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="donus_bilgileri" style="display:none;" class="mt-4 bg-light p-3 border rounded">
                        <h6 class="text-success border-bottom pb-2">Dönüş / Kapatma Bilgileri</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Dönüş Tarihi</label>
                                <input type="datetime-local" class="form-control" name="donus_tarihi" id="donus_tarihi">
                            </div>
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Bitiş Saati</label>
                                <input type="time" class="form-control" name="bitis_saati" id="bitis_saati">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3"> 
                                <label class="form-label">Dönüş KM</label>
                                <input type="number" class="form-control" name="donus_km" id="donus_km">
                            </div>
                             <div class="col-md-6 mb-3"> 
                                <label class="form-label">Alınan Yakıt (TL)</label>
                                <input type="number" step="0.01" class="form-control" name="yakit_alinan" id="yakit_alinan">
                             </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                <button type="button" class="btn btn-success" id="kaydetBtn" onclick="formuGonder()">Kaydet</button>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    console.log("Sayfa Hazır, Script Yüklendi."); 

    // Select2 Kurulumu
    $('.select2').select2({ 
        dropdownParent: $('#gorevKayitModal'), 
        placeholder: "Seçim Yapınız", 
        allowClear: true 
    });
    
    // Tablo Kurulumu
    if ($.fn.DataTable) {
        $('#gorevTablosu').DataTable({
            "language": { "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Turkish.json" },
            "order": [[ 0, "desc" ]] 
        });
    }

    // ============================================================
    // 🔥 BAŞLANGIÇ: ŞOFÖR SEÇİLİNCE GÖREV TÜRÜNÜ FİLTRELEME KODU
    // ============================================================
    $('#sofor_id').on('change', function() {
        var soforID = $(this).val();
        var gorevSelect = $('#gorev_turu_id'); // Görev türü kutusu

        // Eğer şoför seçimi iptal edildiyse veya boşsa işlem yapma
        if (!soforID) {
            return;
        }

        // 1. Görsel Geri Bildirim: Kullanıcıya işlem başladığını göster
        gorevSelect.html('<option value="">Yükleniyor, lütfen bekleyin...</option>');

        // 2. AJAX isteği gönder
        $.ajax({
            url: '../ajax/ajax_arac_gorev_islem.php',
            type: 'POST',
            dataType: 'json',
            data: { 
                action: 'sofor_gorev_turleri_getir', 
                sofor_id: soforID 
            },
            success: function(res) {
                if (res.status === 'success') {
                    var options = '<option value="">Seçiniz</option>';
                    
                    // Eğer liste boş geldiyse
                    if (res.data.length === 0) {
                        options += '<option value="" disabled>⚠️ Bu birim için tanımlı Arazi görevi bulunamadı</option>';
                    } else {
                        // Gelen görevleri listeye ekle
                        $.each(res.data, function(index, item) {
                            options += '<option value="' + item.id + '">' + item.ad + '</option>';
                        });
                    }
                    
                    // Select kutusunun içeriğini güncelle
                    gorevSelect.html(options);
                } else {
                    // PHP tarafından hata mesajı dönerse
                    console.log('Hata Mesajı: ' + res.message);
                    alert('Görev türleri getirilirken hata oluştu: ' + res.message);
                }
            },
            error: function(xhr, status, error) {
                // Sunucu hatası (500, 404 vb.)
                console.error("AJAX Hatası:", error);
                console.log("Sunucu Cevabı:", xhr.responseText);
                gorevSelect.html('<option value="">Bağlantı Hatası!</option>');
                alert("Sunucuyla iletişim kurulamadı. Lütfen F12 Konsol ekranına bakın.");
            }
        });
    });
    // ============================================================
    // 🔥 BİTİŞ: FİLTRELEME KODU SONU
    // ============================================================


    // --- BUTON TIKLAMA OLAYLARI ---
    
    // 1. DÜZENLE BUTONU
    $(document).on('click', '.gorev-duzenle', function(e) {
        e.preventDefault(); 
        console.log("Düzenle butonuna basıldı."); 
        var id = $(this).data('id'); 
        formuDoldur(id, 'guncelle', 'Görevi Düzenle', false);
    });

    // 2. GÖREV BİTİR BUTONU
    $(document).on('click', '.gorev-bitir', function(e) {
        e.preventDefault();
        console.log("Görev Bitir butonuna basıldı.");
        var id = $(this).data('id');
        formuDoldur(id, 'gorev_bitir', 'Görevi Tamamla / Dönüş Yap', false);
    });

    // 3. İNCELE BUTONU
    $(document).on('click', '.gorev-incele', function(e) {
        e.preventDefault();
        console.log("İncele butonuna basıldı.");
        var id = $(this).data('id');
        formuDoldur(id, 'incele', 'Görev Detayı (Kilitli)', true);
    });

    // 4. SİL BUTONU
    $(document).on('click', '.gorev-sil', function(e) {
        e.preventDefault();
        console.log("Sil butonuna basıldı.");
        var id = $(this).data('id');
        
        if(confirm('Bu kaydı silmek istediğinize emin misiniz?')) {
            $.post('../ajax/ajax_arac_gorev_islem.php', { action: 'sil', id: id }, function(res){
                if(res.status === 'success') {
                    alert(res.message);
                    location.reload();
                } else {
                    alert('Hata: ' + res.message);
                }
            }, 'json').fail(function(xhr) {
                console.error("Silme Hatası:", xhr.responseText);
                alert("Silme işlemi sırasında sunucu hatası oluştu.");
            });
        }
    });

}); 

// --- FONKSİYONLAR ---

function getAracSonKm(aracId) { 
    if(!aracId) { $('#cikis_km').val(''); return; }
    if($('#islem_turu').val() !== 'kaydet') return;
    $.post('../ajax/ajax_arac_gorev_islem.php', { action: 'son_km_getir', arac_id: aracId }, function(res){
        if(res.status === 'success') { $('#cikis_km').val(res.son_km); }
    }, 'json');
}

function yeniKayitModal() { 
    console.log("Yeni Kayıt Modalı Açılıyor...");
    $('#aracGorevForm')[0].reset();
    $('#gorev_id').val('');
    $('#islem_turu').val('kaydet');
    $('#modalBaslik').text('Yeni Görev Başlat');
    
    $('#cikis_bilgileri').find('input, select').prop('disabled', false); 
    $('#gorev_no').prop('readonly', true);
    $('#cikis_km').prop('readonly', true);
    $('#donus_bilgileri').hide(); 
    $('#gorev_no').val('Otomatik');
    
    // Select2 Temizliği
    $('.select2').trigger('change'); 
    $('#arac_id').val('').trigger('change');
    $('#sofor_id').val('').trigger('change');
    $('#mahalleler_ids').val(null).trigger('change'); 
    $('#personel_ids').val(null).trigger('change'); 

    $('#kaydetBtn').show().text('Kaydet');
    $('#gorevKayitModal').modal('show');
}

function formuDoldur(id, islemTuru, baslik, kilitliMi) {
    console.log("Form Doldur Çalıştı. ID:", id, "İşlem:", islemTuru);
    
    $.ajax({
        url: '../ajax/ajax_arac_gorev_islem.php',
        type: 'POST',
        data: { action: 'detay_getir', id: id },
        dataType: 'json',
        success: function(res) {
            console.log("Sunucudan Gelen Cevap:", res); 

            if(res.status === 'success') {
                var d = res.data;
                $('#aracGorevForm')[0].reset();
                $('#gorev_id').val(d.id);
                $('#islem_turu').val(islemTuru);
                $('#modalBaslik').text(baslik);
                
                $('#gorev_no').val(d.gorev_no);
                $('#tarih').val(d.tarih);
                $('#arac_id').val(d.arac_id);
                $('#cikis_km').val(d.cikis_km);
                $('#baslangic_saati').val(d.baslangic_saati);
                $('#sofor_id').val(d.sofor_id);
                
                // NOT: Şimdilik mevcut değeri atıyoruz. 
                // İdealde burada da AJAX ile şoförün görev türlerini çekip sonra seçili yapmak gerekir 
                // ama şimdilik veriyi göstermesi yeterli.
                $('#gorev_turu_id').val(d.gorev_turu_id);
                
                if(d.mahalleler_ids) {
                    $('#mahalleler_ids').val(d.mahalleler_ids).trigger('change');
                }

                if(d.personel_ids) {
                    $('#personel_ids').val(d.personel_ids).trigger('change');
                }

                $('#birim_amiri_id').val(d.birim_amiri_id).trigger('change'); 
                $('#kurum_amiri_id').val(d.kurum_amiri_id).trigger('change'); 
                
                $('#donus_tarihi').val(d.donus_tarihi); 
                $('#bitis_saati').val(d.bitis_saati);
                $('#donus_km').val(d.donus_km);
                $('#yakit_alinan').val(d.yakit_alinan);

                var cikisInputs = $('#cikis_bilgileri').find('input, select');
                var donusDiv = $('#donus_bilgileri');
                var donusInputs = donusDiv.find('input, select');
                var kaydetBtn = $('#kaydetBtn');
                
                cikisInputs.prop('disabled', false); 
                donusInputs.prop('disabled', false);
                donusDiv.hide();
                kaydetBtn.show();
                
                $('#gorev_no').prop('readonly', true);
                $('#cikis_km').prop('readonly', true);

                if(islemTuru === 'guncelle') {
                    kaydetBtn.text('Güncelle');
                } else if (islemTuru === 'gorev_bitir') {
                    cikisInputs.prop('disabled', true);
                    donusDiv.show();
                    kaydetBtn.text('Onayla ve Bitir');
                    if(!d.donus_tarihi) {
                        var now = new Date();
                        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
                        $('#donus_tarihi').val(now.toISOString().slice(0,16));
                    }
                } else if (kilitliMi) {
                    cikisInputs.prop('disabled', true);
                    donusDiv.show();
                    donusInputs.prop('disabled', true);
                    kaydetBtn.hide(); 
                }
                $('#gorevKayitModal').modal('show');
            } else { 
                alert('Detay çekilirken hata oluştu: ' + res.message); 
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX Hatası:", textStatus, errorThrown);
            console.log("Sunucu Yanıtı:", jqXHR.responseText);
            alert("Sunucuyla iletişim kurulurken hata oluştu. Lütfen Konsolu (F12) kontrol edin.");
        }
    });
}

function formuGonder() {
    var form = $('#aracGorevForm');
    var action = $('#islem_turu').val(); 
    
    if(form[0].checkValidity() === false) {
        form[0].reportValidity();
        return;
    }

    var disabledInputs = form.find(':input:disabled').removeAttr('disabled');
    var formData = form.serialize();
    disabledInputs.prop('disabled', true); 

    $.ajax({
        url: '../ajax/ajax_arac_gorev_islem.php',
        type: 'POST',
        data: formData + '&action=' + action,
        dataType: 'json',
        success: function(res) {
            if(res.status === 'success') {
                alert(res.message);
                location.reload();
            } else {
                alert('Hata: ' + res.message);
            }
        },
        error: function(e) {
            console.error(e.responseText);
            alert('İletişim hatası oluştu. F12 Konsola bakınız.');
        }
    });
}
</script>