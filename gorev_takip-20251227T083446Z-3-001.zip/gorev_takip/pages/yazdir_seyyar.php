<?php
// pages/yazdir_seyyar.php
session_start();
include_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { exit("Oturum kapalı."); }

$user_id = $_SESSION['user_id'];
$yil     = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$donem   = isset($_GET['donem']) ? intval($_GET['donem']) : 1;

if ($donem == 1) {
    $bas_tarih = "$yil-01-01"; $bit_tarih = "$yil-06-30";
} else {
    $bas_tarih = "$yil-07-01"; $bit_tarih = "$yil-12-31";
}

$sql_user = "SELECT p.*, b.birim_adi FROM personel_bilgileri p LEFT JOIN birimler b ON p.birimler_id = b.id WHERE p.id = ?";
$stmt_user = $pdo->prepare($sql_user);
$stmt_user->execute([$user_id]);
$personel = $stmt_user->fetch(PDO::FETCH_ASSOC);

$stmt_kurum = $pdo->query("SELECT * FROM kurum_ayarlari LIMIT 1");
$kurum = $stmt_kurum->fetch(PDO::FETCH_ASSOC);
$kurum_tam_ad = $kurum['ilce_mudurlugu_adi'] ?? "İLÇE TARIM VE ORMAN MÜDÜRLÜĞÜ";
$ilce_adi     = $kurum['ilce_mudurlugu_adi'] ?? "Çivril"; 
$ilce_kisa    = explode(" ", trim($ilce_adi))[0];

$sql_mudur = "SELECT pb.ad_soyad, COALESCE(NULLIF(yl.unvan_gorunumu,''), pb.unvan) AS unvan FROM yonetici_listesi yl INNER JOIN personel_bilgileri pb ON pb.id = yl.personel_id WHERE yl.aktif = 1 AND yl.rol = 'KURUM_AMIRI' ORDER BY yl.varsayilan DESC LIMIT 1";
$stmt_mudur = $pdo->prepare($sql_mudur);
$stmt_mudur->execute();
$mudur = $stmt_mudur->fetch(PDO::FETCH_ASSOC);

if ($mudur) {
    $mudur_adi   = mb_convert_case($mudur['ad_soyad'], MB_CASE_UPPER, "UTF-8");
    $mudur_unvan = mb_convert_case($mudur['unvan'], MB_CASE_UPPER, "UTF-8");
} else {
    $mudur_adi   = mb_convert_case($kurum['ilce_muduru_adi'] ?? 'Adı Soyadı', MB_CASE_UPPER, "UTF-8");
    $mudur_unvan = "İLÇE MÜDÜRÜ";
}

$birim_adi = $personel['birim_adi'] ?? '';
$gorev_metni = "Büro Dışında Yapılan Çalışmalar işi için";
if (stripos($birim_adi, 'hayvan') !== false) { $gorev_metni = "Hayvan Sağlığı ve Hastalıklar ile Mücadele işi için"; } 
elseif (stripos($birim_adi, 'gıda') !== false) { $gorev_metni = "Gıda Kontrol Hizmetleri işi için"; } 
elseif (stripos($birim_adi, 'su ürün') !== false) { $gorev_metni = "Su Ürünleri Kontrolü işi için"; } 
elseif (stripos($birim_adi, 'ziraat') !== false || stripos($birim_adi, 'bitki') !== false) { $gorev_metni = "Bitki Koruma Eğitim ve Yayım Hizmetleri işi için"; }

$sql_seyyar = "SELECT * FROM seyyar_gorev_detay WHERE personel_id = ? AND tarih BETWEEN ? AND ? ORDER BY tarih ASC";
$stmt_seyyar = $pdo->prepare($sql_seyyar);
$stmt_seyyar->execute([$user_id, $bas_tarih, $bit_tarih]);
$tum_kayitlar = $stmt_seyyar->fetchAll(PDO::FETCH_ASSOC);

$satir_limiti = 30; 
$toplam_kayit = count($tum_kayitlar);
$sayfa_sayisi = ceil($toplam_kayit / $satir_limiti);
if($sayfa_sayisi == 0) $sayfa_sayisi = 1;

function sayiyiYaziyaCevir($sayi) {
    $sayi = number_format($sayi, 2, '.', '');
    list($lira, $kurus) = explode('.', $sayi);
    $birler = ["", "BİR", "İKİ", "ÜÇ", "DÖRT", "BEŞ", "ALTI", "YEDİ", "SEKİZ", "DOKUZ"];
    $onlar  = ["", "ON", "YİRMİ", "OTUZ", "KIRK", "ELLİ", "ALTMIŞ", "YETMİŞ", "SEKSEN", "DOKSAN"];
    function cevir($n, $birler, $onlar) {
        $n = intval($n); if ($n == 0) return "";
        $yuz = floor($n / 100); $on = floor(($n % 100) / 10); $bir = $n % 10;
        $text = ""; if ($yuz == 1) $text .= "YÜZ"; elseif ($yuz > 1) $text .= $birler[$yuz] . "YÜZ";
        $text .= $onlar[$on] . $birler[$bir]; return $text;
    }
    $liraStr = ""; $liraLen = strlen($lira);
    if ($liraLen > 3) {
        $bin = substr($lira, 0, $liraLen - 3); $kalan = substr($lira, $liraLen - 3);
        $binTxt = cevir($bin, $birler, $onlar); if ($binTxt == "") $binTxt = "BİR"; if ($binTxt == "BİR" && intval($bin) == 1) $binTxt = "";
        $liraStr .= $binTxt . "BİN" . cevir($kalan, $birler, $onlar);
    } else { $liraStr .= cevir($lira, $birler, $onlar); }
    $kurusStr = ""; if (intval($kurus) > 0) $kurusStr = cevir($kurus, $birler, $onlar) . " KR";
    return $liraStr . " TL " . $kurusStr;
}

$bugun = date("d/m/Y");
$tam_gundelik = floatval($personel['gundelik']);
$bir_bolu_uc = $tam_gundelik / 3;
$hesaplanan_tutar = round($bir_bolu_uc, 2); 
$nakli_yekun = 0; 
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Seyyar Görev Yolluğu</title>
    <style>
        @page { size: A4 landscape; margin: 5mm; }
        body { font-family: Arial, sans-serif; font-size: 8.5pt; margin: 0; padding: 0; background-color: #555; }
        .page { 
            width: 287mm; 
            min-height: 200mm; 
            background: white; 
            padding: 5mm; 
            margin: 10px auto; 
            box-shadow: 0 0 10px rgba(0,0,0,0.5); 
            box-sizing: border-box; 
            position: relative;
        }
        table { width: 100%; border-collapse: collapse; margin-bottom: 2px; }
        th, td { border: 1px solid #000; padding: 2px; text-align: center; vertical-align: middle; line-height: 1.1; }
        .section-header { background-color: #f2f2f2; font-weight: bold; }
        .left-align { text-align: left !important; padding-left: 3px; }
        .right-align { text-align: right !important; padding-right: 3px; }
        .signature-section { margin-top: 10px; display: flex; justify-content: space-between; align-items: flex-start; }
        .sig-box { text-align: center; width: 280px; }
        .editable-field:hover { background-color: #fff3cd; cursor: text; }
        .no-print { position: fixed; top: 10px; right: 10px; z-index: 9999; display: flex; gap: 10px; }
        .btn { padding: 5px 10px; color: white; border: none; cursor: pointer; border-radius: 4px; font-weight: bold; text-decoration: none; }
        .btn-yazdir { background-color: #007bff; }
        .btn-kapat { background-color: #dc3545; }

        @media print {
            body { background: white; margin: 0; }
            .page { margin: 0; box-shadow: none; border: none; page-break-after: always; width: 100%; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<div class="no-print">
    <button onclick="window.print()" class="btn btn-yazdir">🖨️ YAZDIR</button>
    <button onclick="window.close()" class="btn btn-kapat">❌ KAPAT</button>
</div>

<?php 
for ($sayfa = 1; $sayfa <= $sayfa_sayisi; $sayfa++): 
    $baslangic_index = ($sayfa - 1) * $satir_limiti;
    $sayfa_verileri = array_slice($tum_kayitlar, $baslangic_index, $satir_limiti);
?>

<div class="page">
    
    <div style="text-align: center; border: 1px solid #000; padding: 4px; background-color: #eee; margin-bottom: 3px;">
        <strong style="font-size: 11pt;">SEYYAR GÖREV YOLLUĞU BİLDİRİMİ</strong>
    </div>

    <div style="display: flex; margin-bottom: 3px;">
        <div style="width: 45%; margin-right: 5px;">
            <table style="margin: 0;">
                <tr>
                    <td class="left-align section-header" style="width: 120px;">Adı Soyadı</td>
                    <td class="left-align"><?php echo mb_convert_case($personel['ad_soyad'], MB_CASE_UPPER, "UTF-8"); ?></td>
                </tr>
                <tr>
                    <td class="left-align section-header">Ünvanı</td>
                    <td class="left-align"><?php echo mb_convert_case($personel['unvan'], MB_CASE_UPPER, "UTF-8"); ?></td>
                </tr>
                <tr>
                    <td class="left-align section-header">Aylık Kad./Der.</td>
                    <td class="left-align"><?php echo $personel['derece'] . '-' . $personel['kademe']; ?></td>
                </tr>
                <tr>
                    <td class="left-align section-header">Ek Göstergesi</td>
                    <td class="left-align"><?php echo $personel['ek_gosterge']; ?></td>
                </tr>
                <tr>
                    <td class="left-align section-header">Gündeliği</td>
                    <td class="left-align"><?php echo number_format($personel['gundelik'], 2, ',', '.'); ?></td>
                </tr>
            </table>
        </div>

        <div style="flex: 1;">
            <table style="margin: 0; height: 100%;">
                <tr>
                    <td class="left-align section-header" style="width: 100px;">Dairesi :</td>
                    <td class="left-align"><?php echo mb_convert_case($kurum_tam_ad, MB_CASE_UPPER, "UTF-8"); ?></td>
                </tr>
                <tr>
                    <td class="left-align section-header">Bütçe Yılı:</td>
                    <td class="left-align"><?php echo $yil; ?></td>
                </tr>
            </table>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th rowspan="2" style="width: 80px;">Yolculuk Tarihleri</th>
                <th rowspan="2">Nereden Nereye Yolculuk Ettiği</th>
                <th colspan="3">YOLCULUK GÜNDELİKLERİ</th>
                <th colspan="3">YOL GİDERLERİ</th>
                <th rowspan="2" style="width: 70px;">GENEL<br>TOPLAM</th>
                <th colspan="2">HAREKET SAATLERİ</th>
            </tr>
            <tr>
                <th style="width: 50px;">Gün S.</th>
                <th style="width: 60px;">Bir Günlüğü</th>
                <th style="width: 65px;">TUTARI</th>
                <th style="width: 50px;">ÇEŞİDİ</th>
                <th style="width: 50px;">MEVKİİ</th>
                <th style="width: 60px;">TUTARI</th>
                <th style="width: 45px;">GİDİŞ</th>
                <th style="width: 45px;">DÖNÜŞ</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($sayfa > 1): ?>
            <tr style="background-color: #f9f9f9; height:18px;">
                <td>---</td>
                <td class="right-align" style="font-weight:bold;">GEÇEN SAYFADAN NAKLİ YEKÜN:</td>
                <td>---</td>
                <td>---</td>
                <td class="right-align" style="font-weight:bold;"><?php echo number_format($nakli_yekun, 2, ',', '.'); ?></td>
                <td></td><td></td>
                <td class="right-align" style="font-weight:bold;"><?php echo number_format($nakli_yekun, 2, ',', '.'); ?></td>
                <td class="right-align" style="font-weight:bold;"><?php echo number_format($nakli_yekun, 2, ',', '.'); ?></td>
                <td>---</td><td>---</td>
            </tr>
            <?php endif; ?>

            <?php 
            foreach($sayfa_verileri as $k): 
                $tarih_format = date("d.m.Y", strtotime($k['tarih']));
                $guzergah = $ilce_kisa . "-" . mb_convert_case($k['mahalle'], MB_CASE_TITLE, "UTF-8") . "-" . $ilce_kisa;
                $satir_toplam = $hesaplanan_tutar; 
                $nakli_yekun += $satir_toplam; 
            ?>
            <tr style="height:18px;">
                <td><?php echo $tarih_format; ?></td>
                <td class="left-align"><?php echo $guzergah; ?></td>
                <td>1/3</td>
                <td><?php echo number_format($tam_gundelik, 2, ',', '.'); ?></td>
                <td class="right-align"><?php echo number_format($hesaplanan_tutar, 2, ',', '.'); ?></td>
                <td></td><td></td>
                <td class="right-align"><?php echo number_format($hesaplanan_tutar, 2, ',', '.'); ?></td>
                <td class="right-align"><strong><?php echo number_format($satir_toplam, 2, ',', '.'); ?></strong></td>
                <td>08:30</td>
                <td>16:30</td>
            </tr>
            <?php endforeach; ?>
            
            <tr style="background-color: #f2f2f2; font-weight: bold; height:20px;">
                <td colspan="5" class="right-align">
                    <?php echo ($sayfa < $sayfa_sayisi) ? "GELECEK SAYFAYA NAKLİ YEKÜN" : "GENEL TOPLAM"; ?>
                </td>
                <td></td><td></td>
                <td class="right-align"><?php echo number_format($nakli_yekun, 2, ',', '.'); ?></td>
                <td class="right-align"><?php echo number_format($nakli_yekun, 2, ',', '.'); ?></td>
                <td colspan="2"></td>
            </tr>
        </tbody>
    </table>

    <?php if ($sayfa == $sayfa_sayisi): ?>
    <div style="font-weight: bold; margin-top: 3px; font-size: 9pt; line-height: 1.2;">
        <span class="editable-field" contenteditable="true"><?php echo $gorev_metni; ?></span> 
        <?php echo date("d.m.Y", strtotime($bas_tarih)); ?> - <?php echo date("d.m.Y", strtotime($bit_tarih)); ?> tarihleri arası görev sırasında tahakkuk eden
        <span style="text-decoration: underline;"><?php echo sayiyiYaziyaCevir($nakli_yekun); ?></span> ÖDENMESİNİ ARZ EDERİM.
    </div>

    <div class="signature-section">
        <div style="width: 250px; font-size: 7.5pt;">
            (1) Bu kısım amir tarafından imzalanır.
        </div>
        
        <div class="sig-box">
            <table style="border: none; width: 100%; font-size: 8.5pt;">
                <tr><td style="border:none; text-align:left; width: 60px;">ADI SOYADI</td><td style="border:none; text-align:left;">: <?php echo mb_convert_case($personel['ad_soyad'], MB_CASE_UPPER, "UTF-8"); ?></td></tr>
                <tr><td style="border:none; text-align:left;">UNVANI</td><td style="border:none; text-align:left;">: <?php echo mb_convert_case($personel['unvan'], MB_CASE_UPPER, "UTF-8"); ?></td></tr>
                <tr><td style="border:none; text-align:left;">İMZASI</td><td style="border:none; text-align:left;">: ...................</td></tr>
            </table>
        </div>

        <div class="sig-box">
            <div style="font-size: 8.5pt;"><?php echo $bugun; ?></div>
            <div style="font-size: 8.5pt;">BİRİM YETKİLİSİ(1)</div>
            <strong class="editable-field" style="font-size: 8.5pt;" contenteditable="true"><?php echo $mudur_adi; ?></strong><br>
            <span class="editable-field" style="font-size: 8.5pt;" contenteditable="true"><?php echo $mudur_unvan; ?></span>
        </div>
    </div>
    <?php endif; ?>

</div> <?php endfor; ?>

</body>
</html>