<?php
// pages/raporlar/rapor_izin.php

// 1. AYARLAR
$derinlik = true;
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Yetki Kontrolü (Sadece Admin ve Müdür)
if (!isset($_SESSION['rol_id']) || !in_array($_SESSION['rol_id'], [1, 2])) {
    die("Yetkisiz erişim. <a href='../../index.php'>Anasayfa</a>");
}

include_once '../../config/db.php';
require_once '../../includes/functions.php';

// 2. FİLTRELER
$bas_tarih = isset($_GET['bas_tarih']) ? $_GET['bas_tarih'] : date('Y-m-01');
$bit_tarih = isset($_GET['bit_tarih']) ? $_GET['bit_tarih'] : date('Y-m-t');
$secilen_personel = isset($_GET['personel_id']) ? $_GET['personel_id'] : '';

// --- PERSONEL LİSTESİNİ ÇEK (Dropdown İçin) ---
try {
    $personel_listesi = aktif_personeller();
   
} catch (PDOException $e) {
    die("Personel listesi hatası: " . $e->getMessage());
}

// 3. VERİ ÇEKME
try {
    $sql = "SELECT i.*, 
                   p.ad_soyad, p.tc_no, p.sicil_no, p.toplam_izin,
                   s.sebep_adi,
                   a.aciklama_adi
            FROM personel_izin i
            JOIN personel_bilgileri p ON i.personel_id = p.id
            LEFT JOIN izin_sebepleri s ON i.sebep_id = s.id
            LEFT JOIN izin_aciklamalari a ON i.aciklama_id = a.id
            WHERE (i.izin_baslangic >= ? AND i.izin_baslangic <= ?)";

    $params = [$bas_tarih, $bit_tarih];

    // Personel filtresi seçilmişse sorguya ekle
    if (!empty($secilen_personel)) {
        $sql .= " AND i.personel_id = ?";
        $params[] = $secilen_personel;
    }

    $sql .= " ORDER BY i.izin_baslangic ASC, p.ad_soyad ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $sonuclar = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Veritabanı Hatası: " . $e->getMessage());
}

// 4. EXCEL İNDİRME MODU
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    error_reporting(0);
    $filename = "Personel_Izin_Raporu_" . date("d-m-Y") . ".xls";
    
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo "\xEF\xBB\xBF"; 

    echo '<table border="1">';
    echo '<thead><tr style="background-color:#EEE;">
            <th>SIRA NO</th>
            <th>TC KİMLİK NO</th>
            <th>SİCİL NO</th>
            <th>PERSONEL ADI SOYADI</th>
            <th>KALAN İZİN (GÜN)</th>
            <th>İZİN SEBEBİ</th>
            <th>AÇIKLAMA</th>
            <th>BAŞLANGIÇ TARİHİ</th>
            <th>BİTİŞ TARİHİ</th>
            <th>GÜN SAYISI</th>
            <th>AİT OLDUĞU YIL</th>
          </tr></thead><tbody>';
    
    foreach ($sonuclar as $s) {
        echo '<tr>';
        echo '<td>' . ($s['sira_no'] ?? '-') . '</td>';
        echo '<td style="mso-number-format:\'@\';">' . $s['tc_no'] . '</td>';
        echo '<td>' . $s['sicil_no'] . '</td>';
        echo '<td>' . $s['ad_soyad'] . '</td>';
        echo '<td style="background-color:#FFFFA5; font-weight:bold;">' . $s['toplam_izin'] . '</td>';
        echo '<td>' . $s['sebep_adi'] . '</td>';
        echo '<td>' . ($s['aciklama_adi'] ?? '') . '</td>';
        echo '<td>' . date('d.m.Y', strtotime($s['izin_baslangic'])) . '</td>';
        echo '<td>' . date('d.m.Y', strtotime($s['izin_bitis'])) . '</td>';
        echo '<td>' . $s['gun_sayisi'] . '</td>';
        echo '<td>' . $s['yil'] . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    exit;
}

// 5. HTML GÖRÜNÜM
include_once '../../includes/header.php';
?>

<div class="container-fluid mt-4">
    <div class="card shadow">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-calendar-alt"></i> Personel İzin Raporu</h5>
        </div>
        <div class="card-body">
            
            <form method="GET" class="row g-3 align-items-end mb-4 border p-3 rounded bg-light">
                <div class="col-md-3">
                    <label class="form-label fw-bold">Başlangıç Tarihi</label>
                    <input type="date" name="bas_tarih" class="form-control" value="<?php echo $bas_tarih; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Bitiş Tarihi</label>
                    <input type="date" name="bit_tarih" class="form-control" value="<?php echo $bit_tarih; ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-bold">Personel Seçiniz</label>
                    <select name="personel_id" class="form-select">
                        <option value="">Tüm Personeller</option>
                        <?php foreach ($personel_listesi as $p): ?>
                            <option value="<?php echo $p['id']; ?>" <?php echo ($secilen_personel == $p['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($p['ad_soyad']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Listele</button>
                </div>
                <div class="col-md-2">
                    <a href="?bas_tarih=<?php echo $bas_tarih; ?>&bit_tarih=<?php echo $bit_tarih; ?>&personel_id=<?php echo $secilen_personel; ?>&export=excel" target="_blank" class="btn btn-success w-100">
                        <i class="fas fa-file-excel"></i> Excel'e Aktar
                    </a>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>Sıra</th>
                            <th>TC No</th>
                            <th>Personel Adı</th>
                            <th class="bg-warning text-dark text-center">Kalan İzin</th>
                            <th>İzin Sebebi</th>
                            <th>Açıklama</th>
                            <th>Başlangıç</th>
                            <th>Bitiş</th>
                            <th>Gün</th>
                            <th>Yıl/Ay</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($sonuclar)): ?>
                            <tr><td colspan="10" class="text-center text-danger fw-bold">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($sonuclar as $s): ?>
                            <tr>
                                <td><?php echo $s['sira_no'] ?? '-'; ?></td>
                                <td><?php echo $s['tc_no']; ?></td>
                                <td><?php echo htmlspecialchars($s['ad_soyad']); ?></td>
                                
                                <td class="fw-bold text-center text-danger bg-light">
                                    <?php echo $s['toplam_izin']; ?>
                                </td>
                                
                                <td><?php echo htmlspecialchars($s['sebep_adi']); ?></td>
                                <td><?php echo htmlspecialchars($s['aciklama_adi'] ?? '-'); ?></td>
                                <td><?php echo date('d.m.Y', strtotime($s['izin_baslangic'])); ?></td>
                                <td><?php echo date('d.m.Y', strtotime($s['izin_bitis'])); ?></td>
                                <td class="fw-bold text-center"><?php echo $s['gun_sayisi']; ?></td>
                                <td><?php echo $s['yil'] . ' / ' . $s['ay']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-2 text-muted small">* Toplam <strong><?php echo count($sonuclar); ?></strong> kayıt listelendi.</div>

        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>