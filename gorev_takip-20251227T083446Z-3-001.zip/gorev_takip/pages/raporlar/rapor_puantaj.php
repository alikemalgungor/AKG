<?php
// pages/raporlar/rapor_puantaj.php

// 1. AYARLAR VE OTURUM
session_start();
require_once '../../config/db.php'; 

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../index.php");
    exit;
}

// PARAMETRELER
$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$ay  = isset($_GET['ay'])  ? intval($_GET['ay'])  : date('m');

// AY İSİMLERİ
$aylar = ["OCAK","ŞUBAT","MART","NİSAN","MAYIS","HAZİRAN","TEMMUZ","AĞUSTOS","EYLÜL","EKİM","KASIM","ARALIK"];
$ay_adi = $aylar[$ay-1];

// 2. KURUM ADINI VERİTABANINDAN ÇEK
$kurum_adi = "ÇİVRİL İLÇE TARIM VE ORMAN MÜDÜRLÜĞÜ"; 
try {
    $stmt_kurum = $pdo->query("SELECT ilce_mudurlugu_adi FROM kurum_ayarlari LIMIT 1");
    $kurum_row = $stmt_kurum->fetch(PDO::FETCH_ASSOC);
    if ($kurum_row && !empty($kurum_row['ilce_mudurlugu_adi'])) {
        $kurum_adi = mb_strtoupper($kurum_row['ilce_mudurlugu_adi'], 'UTF-8');
    }
} catch (Exception $e) { }

// 3. PUANTAJ VERİLERİNİ ÇEK (SADECE KİLİTLİ OLANLAR)
$sql = "SELECT 
            p.tc_no, p.ad_soyad, p.unvan,
            pa.* FROM puantaj_aylik pa
        INNER JOIN personel_bilgileri p ON pa.personel_id = p.id
        WHERE pa.yil = ? 
          AND pa.ay = ? 
          AND pa.kilit_durumu = 'Kilitli'  -- BURAYI EKLEDİM: Sadece onaylılar
        ORDER BY p.ad_soyad ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$yil, $ay]);
$liste = $stmt->fetchAll(PDO::FETCH_ASSOC);

// =================================================================================
// MOD 1: EXCEL ÇIKTISI
// =================================================================================
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    $dosya_adi = "Puantaj_Raporu_{$yil}_{$ay_adi}.xls";
    
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=$dosya_adi");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo "\xEF\xBB\xBF"; 

    ?>
    <html xmlns:x="urn:schemas-microsoft-com:office:excel">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        @page {
            mso-page-orientation: landscape;
            margin: 0.5cm 0.5cm 0.5cm 0.5cm;
        }
        body { font-family: 'Calibri', sans-serif; font-size: 10pt; }
        table { border-collapse: collapse; table-layout: fixed; width: 100%; }
        
        /* HÜCRE STİLLERİ */
        .title-main { font-size: 14pt; font-weight: bold; text-align: left; border: none; }
        .title-sub { font-size: 12pt; font-weight: bold; text-align: left; border: none; }
        
        .data-cell { 
            border: 0.5pt solid #000000; 
            text-align: center; 
            vertical-align: middle; 
            padding: 3px;
        }
        .data-cell-left {
            border: 0.5pt solid #000000;
            text-align: left;
            vertical-align: middle;
            padding-left: 5px;
            white-space: nowrap;
        }
        .table-head {
            background-color: #d9d9d9;
            font-weight: bold;
            font-size: 9pt;
            border: 0.5pt solid #000000;
            text-align: center;
            vertical-align: middle;
        }
    </style>
    </head>
    <body>

    <table>
        <col style='width:30px;'> <col style='width:90px;'> <col style='width:150px;'> <col style='width:100px;'> <?php for($i=1;$i<=31;$i++) echo "<col style='width:25px;'>"; ?> <col style='width:50px;'> <col style='width:40px;'> <col style='width:50px;'> <col style='width:50px;'> <col style='width:50px;'> 
        <tr>
            <td colspan="40" class="title-main">KURUM ADI: <?php echo $kurum_adi; ?></td>
        </tr>
        <tr>
            <td colspan="40" class="title-sub">AİT OLDUĞU AY: <?php echo $ay_adi; ?></td>
        </tr>
        <tr><td colspan="40" style="border:none;"></td></tr>

        <tr>
            <td colspan="40" class="data-cell" style="font-weight:bold; font-size:12pt; background-color:#f2f2f2;">PUANTAJ TABLOSU</td>
        </tr>

        <tr>
            <td class="table-head" rowspan="2">Sıra</td>
            <td class="table-head" rowspan="2">T.C. KİMLİK NO</td>
            <td class="table-head" rowspan="2">AD SOYAD</td>
            <td class="table-head" rowspan="2">GÖREV/UNVAN</td>
            <?php for($i=1; $i<=31; $i++) echo "<td class='table-head'>$i</td>"; ?>
            <td class="table-head" rowspan="2">ARAÇ<br>KULLA</td>
            <td class="table-head" rowspan="2">TOPLA<br>M</td>
            <td class="table-head" rowspan="2">KON.G<br>ÖR</td>
            <td class="table-head" rowspan="2">ŞOFÖ<br>R</td>
            <td class="table-head" rowspan="2">TOPLA<br>M</td>
        </tr>
        <tr>
             <?php for($i=1; $i<=31; $i++) echo "<td class='table-head' style='height:5px; border-top:none;'></td>"; ?>
        </tr>

        <?php foreach($liste as $k => $row): 
            $arac_kullanim = ($row['toplam_sofor_puani'] > 0) ? 'EVET' : 'HAYIR';
            $dolu_gun_sayisi = 0;
            for($j=1; $j<=31; $j++) {
                if(!empty($row['gun'.$j]) && !in_array($row['gun'.$j], ['RT', 'IZ'])) {
                    $dolu_gun_sayisi++;
                }
            }
        ?>
        <tr>
            <td class="data-cell"><?=$k+1?></td>
            <td class="data-cell" style="mso-number-format:'@'"><?=$row['tc_no']?></td>
            <td class="data-cell-left"><?=$row['ad_soyad']?></td> <td class="data-cell-left"><?=$row['unvan']?></td>   <?php for($i=1; $i<=31; $i++): ?>
                <td class="data-cell" style="font-size: 8pt;"><?=$row['gun'.$i]?></td>
            <?php endfor; ?>
            <td class="data-cell"><?=$arac_kullanim?></td>
            <td class="data-cell"><?=$dolu_gun_sayisi?></td>
            <td class="data-cell"><?=$row['toplam_kon_gor_puani']?></td>
            <td class="data-cell"><?=$row['toplam_sofor_puani']?></td>
            <td class="data-cell" style="font-weight:bold; background-color:#f9f9f9;"><?=$row['toplam_aylik_puan']?></td>
        </tr>
        <?php endforeach; ?>

        <tr>
            <td colspan="40" style="border:0.5pt solid #000; text-align:left; font-size:8pt; padding:5px;">
                *K:Kontrol Görevi *K+S:Kontrol Görevi+Seyyar Görev *A:Arazi Tazminat Görevi *A+S:Arazi Tazminat Görevi+Seyyar Görev *S:Seyyar Görev *İ:İzinli Gün *RT:Resmi Tatil Günü
            </td>
        </tr>

        <tr><td colspan="40" style="border:none;"></td></tr>
        <tr><td colspan="40" style="border:none;"></td></tr>
        <tr>
            <td colspan="35" style="border:none;"></td>
            <td colspan="5" style="border:none; text-align: center; font-weight:bold;">
                ..../..../....<br>
                Onaylayan:<br>
                Adı Soyadı:<br>
                İmza:
            </td>
        </tr>
    </table>
    </body>
    </html>
    <?php
    exit();
}

// =================================================================================
// MOD 2: WEB GÖRÜNÜMÜ
// =================================================================================
$derinlik = true;
include_once '../../includes/header.php';

// --- EKSİK VEYA ONAYLANMAMIŞ PERSONEL KONTROLÜ ---
// Mantık: Puantaj takibi 1 olan ama (ya hiç kaydı olmayan YA DA kaydı olup kilitli olmayan) personeller
$sql_eksik = "SELECT p.ad_soyad 
              FROM personel_bilgileri p 
              WHERE p.puantaj_takip = 1 
              AND p.id NOT IN (
                  SELECT personel_id FROM puantaj_aylik 
                  WHERE yil = ? AND ay = ? AND kilit_durumu = 'Kilitli'
              ) 
              ORDER BY p.ad_soyad ASC";
$stmt_eksik = $pdo->prepare($sql_eksik);
$stmt_eksik->execute([$yil, $ay]);
$eksik_personeller = $stmt_eksik->fetchAll(PDO::FETCH_ASSOC);
// --------------------------------------
?>

<div class="container-fluid py-4">

    <?php if(!empty($eksik_personeller)): ?>
    <div class="alert alert-warning border-start border-warning border-5 shadow-sm d-flex align-items-center mb-4" role="alert">
        <i class="fas fa-exclamation-triangle fa-2x text-warning me-3"></i>
        <div class="w-100">
            <h6 class="fw-bold mb-1">Dikkat: Aşağıdaki personellerin <?=$ay_adi?>/<?=$yil?> dönemi puantajı eksik veya henüz onaylanmamış!</h6>
            <div class="small text-muted">
                <?php 
                $isimler = array_map(function($p){ return $p['ad_soyad']; }, $eksik_personeller);
                echo implode(", ", $isimler);
                ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 text-primary fw-bold">
                <i class="fas fa-file-invoice me-2"></i>Aylık Puantaj Raporu
            </h5>
            
            <form class="d-flex gap-2 align-items-center" method="GET">
                <select name="yil" class="form-select form-select-sm fw-bold" style="width: 100px;">
                    <?php for($y=2024; $y<=2026; $y++): ?>
                        <option value="<?=$y?>" <?=$y==$yil?'selected':''?>><?=$y?></option>
                    <?php endfor; ?>
                </select>
                <select name="ay" class="form-select form-select-sm fw-bold" style="width: 120px;">
                    <?php foreach($aylar as $k => $v): ?>
                        <option value="<?=$k+1?>" <?=$k+1==$ay?'selected':''?>><?=$v?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-primary">
                    <i class="fas fa-filter"></i> Getir
                </button>
                <a href="?yil=<?=$yil?>&ay=<?=$ay?>&export=excel" target="_blank" class="btn btn-sm btn-success fw-bold text-white">
                    <i class="fas fa-file-excel me-1"></i> EXCEL
                </a>
            </form>
        </div>

        <div class="card-body p-2">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm text-center align-middle" style="font-size: 11px; white-space: nowrap;">
                    <thead class="table-dark">
                        <tr>
                            <th rowspan="2" style="width: 30px;">Sıra</th>
                            <th rowspan="2">T.C. Kimlik No</th>
                            <th rowspan="2">Ad Soyad</th>
                            <th rowspan="2">Görev/Unvan</th>
                            <th colspan="31">GÜNLER</th>
                            <th rowspan="2">Araç<br>Kul.</th>
                            <th rowspan="2">Gün<br>Top.</th>
                            <th rowspan="2">Kon.G<br>Ör.</th>
                            <th rowspan="2">Şoför<br>Puan</th>
                            <th rowspan="2">Toplam<br>Puan</th>
                        </tr>
                        <tr>
                            <?php for($i=1; $i<=31; $i++) echo "<th style='width:20px;'>$i</th>"; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($liste)): ?>
                            <tr><td colspan="40" class="p-4 text-center text-muted">Onaylı puantaj kaydı bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach($liste as $k => $row): 
                                $arac_kullanim = ($row['toplam_sofor_puani'] > 0) ? 'EVET' : 'HAYIR';
                                $dolu_gun_sayisi = 0;
                                for($j=1; $j<=31; $j++) {
                                    if(!empty($row['gun'.$j]) && !in_array($row['gun'.$j], ['RT', 'IZ'])) {
                                        $dolu_gun_sayisi++;
                                    }
                                }
                            ?>
                            <tr>
                                <td><?=$k+1?></td>
                                <td><?=$row['tc_no']?></td>
                                <td class="text-start px-2"><?=$row['ad_soyad']?></td>
                                <td class="text-start px-2"><?=$row['unvan']?></td>
                                <?php for($i=1; $i<=31; $i++): 
                                    $val = $row['gun'.$i];
                                    $bg = ($val == 'RT') ? 'bg-danger text-white' : (($val == 'IZ') ? 'bg-warning' : '');
                                ?>
                                    <td class="<?=$bg?>"><?=$val?></td>
                                <?php endfor; ?>
                                <td class="fw-bold"><?=$arac_kullanim?></td>
                                <td class="fw-bold"><?=$dolu_gun_sayisi?></td>
                                <td><?=$row['toplam_kon_gor_puani']?></td>
                                <td><?=$row['toplam_sofor_puani']?></td>
                                <td class="fw-bold bg-light"><?=$row['toplam_aylik_puan']?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3 small text-muted border-top pt-2">
                <strong>LEJANT:</strong> *KG:Kontrol Görevi *KS:Kontrol Görevi + Seyyar Görev *A:Arazi Tazminatı *AS:Arazi Tazminatı + Seyyar Görev *AKS:Arazi Tazminat + Kontrol Görevi + Seyyar Görev *S:Seyyar Görev *İ:İzinli Gün *RT:Resmi Tatil Günü
            </div>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>