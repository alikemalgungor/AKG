<?php
// pages/raporlar/rapor_ozel_arac.php

// 1. AYARLAR
$derinlik = true; // pages/raporlar/ klasöründe olduğu için
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user_id'])) { 
    header("Location: ../../index.php"); exit; 
}

// 2. YETKİ KONTROLÜ (Admin ve Müdür)
include_once '../../includes/functions.php';
// Fonksiyon yoksa manuel kontrol (Garanti olsun)
if (!isset($_SESSION['rol_id']) || !in_array($_SESSION['rol_id'], [1, 2])) {
    die("Yetkisiz erişim.");
}

// 3. VERİTABANI
include_once '../../config/db.php';

// 4. FİLTRELER
$bas_tarih = isset($_GET['bas_tarih']) ? $_GET['bas_tarih'] : date('Y-m-01');
$bit_tarih = isset($_GET['bit_tarih']) ? $_GET['bit_tarih'] : date('Y-m-t');

// 5. VERİ ÇEKME
try {
    $sql = "SELECT o.*, 
                   p.ad_soyad, p.tc_no,
                   gt.ad as gorev_turu_ad,
                   m.ad as mahalle_ad,
                   ka.ad_soyad as amir_ad
            FROM ozel_arac_gorevler o
            JOIN personel_bilgileri p ON o.gorevli_personel_id = p.id
            LEFT JOIN gorev_turleri gt ON o.gorev_turu_id = gt.id
            LEFT JOIN mahalleler m ON o.mahalle_id = m.id
            LEFT JOIN personel_bilgileri ka ON o.kurum_amiri_id = ka.id
            WHERE o.gorev_tarihi BETWEEN ? AND ?
            ORDER BY o.gorev_tarihi ASC, o.cikis_saat ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$bas_tarih, $bit_tarih]);
    $sonuclar = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Veritabanı Hatası: " . $e->getMessage());
}

// 6. EXCEL İNDİRME MODU (Eğer butona basıldıysa burası çalışır)
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    error_reporting(0);
    $filename = "Ozel_Arac_Raporu_" . date('d-m-Y') . ".xls";

    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo "\xEF\xBB\xBF"; // Türkçe Karakter Desteği

    echo '<table border="1">';
    echo '<thead><tr style="background-color:#CCC;">
            <th>GÖREV NO</th>
            <th>TARİH</th>
            <th>PERSONEL ADI</th>
            <th>TC KİMLİK NO</th>
            <th>ARAÇ PLAKA</th>
            <th>ARAÇ SAHİBİ</th>
            <th>GİDİLEN YER</th>
            <th>GÖREV TÜRÜ</th>
            <th>ÇIKIŞ SAATİ</th>
            <th>DÖNÜŞ SAATİ</th>
            <th>DÖNÜŞ TARİHİ</th>
            <th>ONAYLAYAN</th>
            <th>DURUM</th>
          </tr></thead><tbody>';

    foreach ($sonuclar as $s) {
        $durum = ($s['gorev_onayli'] == 1) ? 'ONAYLANDI' : (($s['gorev_onayli'] == 2) ? 'REDDEDİLDİ' : 'BEKLİYOR');
        echo '<tr>';
        echo '<td>' . $s['gorev_no'] . '</td>';
        echo '<td>' . date('d.m.Y', strtotime($s['gorev_tarihi'])) . '</td>';
        echo '<td>' . $s['ad_soyad'] . '</td>';
        echo '<td style="mso-number-format:\'@\';">' . $s['tc_no'] . '</td>';
        echo '<td>' . $s['arac_plaka'] . '</td>';
        echo '<td>' . $s['arac_sahibi'] . '</td>';
        echo '<td>' . $s['mahalle_ad'] . '</td>';
        echo '<td>' . $s['gorev_turu_ad'] . '</td>';
        echo '<td>' . substr($s['cikis_saat'], 0, 5) . '</td>';
        echo '<td>' . ($s['donus_saat'] ? substr($s['donus_saat'], 0, 5) : '') . '</td>';
        echo '<td>' . ($s['donus_tarihi'] ? date('d.m.Y', strtotime($s['donus_tarihi'])) : '') . '</td>';
        echo '<td>' . $s['amir_ad'] . '</td>';
        echo '<td>' . $durum . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    exit; // Kod burada biter, HTML basılmaz.
}

// 7. HTML GÖRÜNÜM (Sayfa açılınca burası çalışır)
include_once '../../includes/header.php';
?>

<div class="container-fluid mt-4">
    <div class="card shadow">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="fas fa-file-excel"></i> Özel Araç Görev Raporu</h5>
        </div>
        <div class="card-body">
            
            <form method="GET" class="row g-3 align-items-end mb-4 border p-3 rounded bg-light">
                <div class="col-md-3">
                    <label class="form-label fw-bold">Başlangıç Tarihi</label>
                    <input type="date" name="bas_tarih" class="form-control" value="<?php echo $bas_tarih; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Bitiş Tarihi</label>
                    <input type="date" name="bit_tarih" class="form-control" value="<?php echo $bit_tarih; ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Listele
                    </button>
                </div>
                <div class="col-md-3">
                    <a href="?bas_tarih=<?php echo $bas_tarih; ?>&bit_tarih=<?php echo $bit_tarih; ?>&export=excel" target="_blank" class="btn btn-success w-100">
                        <i class="fas fa-file-excel"></i> Excel'e Aktar
                    </a>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Tarih</th>
                            <th>Personel</th>
                            <th>Plaka</th>
                            <th>Gidilen Yer</th>
                            <th>Görev Türü</th>
                            <th>Çıkış</th>
                            <th>Dönüş</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($sonuclar)): ?>
                            <tr><td colspan="9" class="text-center text-danger fw-bold">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($sonuclar as $s): ?>
                            <tr>
                                <td><?php echo $s['gorev_no']; ?></td>
                                <td><?php echo date('d.m.Y', strtotime($s['gorev_tarihi'])); ?></td>
                                <td><?php echo $s['ad_soyad']; ?></td>
                                <td><?php echo $s['arac_plaka']; ?></td>
                                <td><?php echo $s['mahalle_ad']; ?></td>
                                <td><?php echo $s['gorev_turu_ad']; ?></td>
                                <td><?php echo substr($s['cikis_saat'], 0, 5); ?></td>
                                <td><?php echo $s['donus_saat'] ? substr($s['donus_saat'], 0, 5) : '-'; ?></td>
                                <td>
                                    <?php if($s['gorev_onayli'] == 1): ?>
                                        <span class="badge bg-success">Onaylı</span>
                                    <?php elseif($s['gorev_onayli'] == 2): ?>
                                        <span class="badge bg-danger">Red</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Bekliyor</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-2 text-muted small">* Toplam <strong><?php echo count($sonuclar); ?></strong> kayıt listelendi.</div>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>