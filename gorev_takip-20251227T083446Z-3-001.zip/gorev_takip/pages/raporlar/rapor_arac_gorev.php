<?php
// pages/raporlar/rapor_arac_gorev.php

$derinlik = true; 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../index.php"); 
    exit;
}

include_once '../../includes/functions.php';
yetki_kontrol([1, 2, 3]);

include_once '../../config/db.php';

// --- FİLTRELERİ AL ---
$bas_tarih = isset($_GET['bas_tarih']) ? $_GET['bas_tarih'] : date('Y-m-01');
$bit_tarih = isset($_GET['bit_tarih']) ? $_GET['bit_tarih'] : date('Y-m-d');
$secilen_arac_id = isset($_GET['arac_id']) ? $_GET['arac_id'] : '';

// --- ARAÇ LİSTESİNİ ÇEK ---
try {
    $stmt_araclar = $pdo->query("SELECT id, plaka, marka_model FROM araclar ORDER BY plaka ASC");
    $arac_listesi = $stmt_araclar->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Araç listesi hatası: " . $e->getMessage());
}

// --- ANA VERİLERİ ÇEK ---
try {
    $sql = "
        SELECT 
            ag.id as ana_id, ag.gorev_no, ag.sira_no, ag.tarih, ag.baslangic_saati, ag.bitis_saati, 
            ag.cikis_km, ag.donus_km, ag.yakit_alinan,
            a.plaka, a.marka_model,
            gt.ad as gorev_turu,
            s.ad_soyad as sofor_ad,
            ba.ad_soyad as birim_amiri,
            ka.ad_soyad as kurum_amiri,
            (SELECT GROUP_CONCAT(m.ad SEPARATOR ', ') FROM arac_gorev_mahalle agm JOIN mahalleler m ON agm.mahalleler_id = m.id WHERE agm.gorev_id = ag.id) as mahalleler,
            (SELECT GROUP_CONCAT(p.ad_soyad SEPARATOR ', ') FROM arac_gorev_personel agp JOIN personel_bilgileri p ON agp.personel_id = p.id WHERE agp.gorev_id = ag.id AND agp.rol = 'Personel') as personeller
        FROM arac_gorevler ag
        LEFT JOIN araclar a ON ag.arac_id = a.id
        LEFT JOIN gorev_turleri gt ON ag.gorev_turu_id = gt.id
        LEFT JOIN personel_bilgileri s ON ag.sofor_id = s.id
        LEFT JOIN personel_bilgileri ba ON ag.birim_amiri_id = ba.id
        LEFT JOIN personel_bilgileri ka ON ag.kurum_amiri_id = ka.id
        WHERE (ag.tarih BETWEEN ? AND ?)
    ";

    $params = [$bas_tarih, $bit_tarih];

    if (!empty($secilen_arac_id)) {
        $sql .= " AND ag.arac_id = ? ";
        $params[] = $secilen_arac_id;
    }

    $sql .= " ORDER BY ag.tarih DESC, ag.gorev_no DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $sonuclar = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Hata: " . $e->getMessage());
}

// --- EXCEL ÇIKTISI ---
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    error_reporting(0); 
    $filename = "arac_gorev_listesi_" . date('Ymd') . ".xls";
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo "\xEF\xBB\xBF"; 

    echo '<table border="1">';
    echo '<thead><tr style="background-color:#CCC;">
            <th>Sıra No</th>
            <th>Görev No</th>
            <th>Tarih</th>
            <th>Plaka</th>
            <th>Görev Türü</th>
            <th>Gidilen Yerler</th>
            <th>Şoför</th>
            <th>Diğer Personeller</th>
            <th>Çıkış KM</th>
            <th>Dönüş KM</th>
            <th>Yapılan KM</th>
            <th>Alınan Yakıt</th>
          </tr></thead>';
    echo '<tbody>';
    
    foreach ($sonuclar as $row) {
        $c_km = (float)($row['cikis_km'] ?? 0);
        $d_km = (float)($row['donus_km'] ?? 0);
        $yapilan_km = ($d_km > 0) ? ($d_km - $c_km) : 0;
        
        echo '<tr>';
        echo '<td>' . ($row['sira_no'] ?? '') . '</td>';
        echo '<td>' . ($row['gorev_no'] ?? '') . '</td>';
        echo '<td>' . date('d.m.Y', strtotime($row['tarih'])) . '</td>';
        echo '<td>' . htmlspecialchars($row['plaka'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($row['gorev_turu'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($row['mahalleler'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($row['sofor_ad'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($row['personeller'] ?? '') . '</td>';
        echo '<td>' . $c_km . '</td>';
        echo '<td>' . $d_km . '</td>';
        echo '<td>' . $yapilan_km . '</td>';
        echo '<td>' . str_replace('.', ',', $row['yakit_alinan'] ?? '0') . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    exit;
}

include_once '../../includes/header.php';
?>

<div class="container-fluid mt-4">
    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-file-excel"></i> Araç Görev Raporu</h5>
        </div>
        <div class="card-body">
            
            <form method="GET" action="" class="row g-3 align-items-end mb-4 border p-3 rounded bg-light">
                <div class="col-md-3">
                    <label class="form-label fw-bold">Başlangıç Tarihi</label>
                    <input type="date" name="bas_tarih" class="form-control" value="<?php echo $bas_tarih; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Bitiş Tarihi</label>
                    <input type="date" name="bit_tarih" class="form-control" value="<?php echo $bit_tarih; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Araç / Plaka</label>
                    <select name="arac_id" class="form-select">
                        <option value="">Tüm Araçlar</option>
                        <?php foreach ($arac_listesi as $arac): ?>
                            <option value="<?php echo $arac['id']; ?>" <?php echo ($secilen_arac_id == $arac['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($arac['plaka']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1"><i class="fas fa-filter"></i> Listele</button>
                    <a href="?bas_tarih=<?php echo $bas_tarih; ?>&bit_tarih=<?php echo $bit_tarih; ?>&arac_id=<?php echo $secilen_arac_id; ?>&export=excel" class="btn btn-success flex-grow-1"><i class="fas fa-file-excel"></i> Excel</a>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Sıra No</th>
                            <th>Görev No</th>
                            <th>Tarih</th>
                            <th>Plaka</th>
                            <th>Gidilen Yer</th>
                            <th>Şoför</th>
                            <th>Personeller</th>
                            <th>Çıkış KM</th>
                            <th>Dönüş KM</th>
                            <th>Fark KM</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($sonuclar)): ?>
                            <tr><td colspan="10" class="text-center text-muted">Kayıt bulunamadı.</td></tr>
                        <?php else: ?>
                            <?php foreach ($sonuclar as $row): 
                                $c_km = (float)($row['cikis_km'] ?? 0);
                                $d_km = (float)($row['donus_km'] ?? 0);
                                $fark = ($d_km > 0) ? ($d_km - $c_km) : 0;
                            ?>
                            <tr>
                                <td class="fw-bold text-primary"><?php echo htmlspecialchars($row['sira_no'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($row['gorev_no'] ?? '-'); ?></td>
                                <td><?php echo date('d.m.Y', strtotime($row['tarih'])); ?></td>
                                <td><?php echo htmlspecialchars($row['plaka'] ?? ''); ?></td>
                                <td><small><?php echo htmlspecialchars($row['mahalleler'] ?? ''); ?></small></td>
                                <td><?php echo htmlspecialchars($row['sofor_ad'] ?? ''); ?></td>
                                <td><small><?php echo htmlspecialchars($row['personeller'] ?? ''); ?></small></td>
                                <td><?php echo number_format($c_km, 0, ',', '.'); ?></td>
                                <td><?php echo number_format($d_km, 0, ',', '.'); ?></td>
                                <td class="fw-bold"><?php echo number_format($fark, 0, ',', '.'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
             <div class="mt-2 text-muted small">* Toplam <strong><?php echo count($sonuclar); ?></strong> kayıt listelendi.</div>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>