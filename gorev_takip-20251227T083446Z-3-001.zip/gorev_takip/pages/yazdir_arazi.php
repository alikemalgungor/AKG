<?php
// pages/yazdir_arazi.php
session_start();
include_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { exit("Oturum kapalı."); }

$user_id = $_SESSION['user_id'];
$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$secili_ay  = isset($_GET['ay']) ? intval($_GET['ay']) : date('m');

// 1. DÖNEM HESAPLAMA
if ($secili_ay <= 3) { $bas_ay = 1; $bit_ay = 3; $donem_ad = "1. ÇEYREK (OCAK - ŞUBAT - MART)"; }
elseif ($secili_ay <= 6) { $bas_ay = 4; $bit_ay = 6; $donem_ad = "2. ÇEYREK (NİSAN - MAYIS - HAZİRAN)"; }
elseif ($secili_ay <= 9) { $bas_ay = 7; $bit_ay = 9; $donem_ad = "3. ÇEYREK (TEMMUZ - AĞUSTOS - EYLÜL)"; }
else { $bas_ay = 10; $bit_ay = 12; $donem_ad = "4. ÇEYREK (EKİM - KASIM - ARALIK)"; }

$ay_isimleri = ["", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK"];

// 2. KURUM VE PERSONEL BİLGİLERİ
$stmt_kurum = $pdo->query("SELECT * FROM kurum_ayarlari LIMIT 1");
$kurum = $stmt_kurum->fetch(PDO::FETCH_ASSOC);

$sql_user = "SELECT p.ad_soyad, p.unvan, b.* FROM personel_bilgileri p 
             LEFT JOIN birimler b ON p.birimler_id = b.id 
             WHERE p.id = ?";
$stmt_user = $pdo->prepare($sql_user);
$stmt_user->execute([$user_id]);
$personel = $stmt_user->fetch(PDO::FETCH_ASSOC);

$kurum_adi = $kurum['ilce_mudurlugu_adi'] ?? $kurum['kurum_adi'] ?? "KURUM ADI YOK";

// 3. VERİLERİ ÇEKME
$sql_p = "SELECT * FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ? ORDER BY ay ASC";
$stmt_p = $pdo->prepare($sql_p);
$stmt_p->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$puantaj_data = [];
foreach($stmt_p->fetchAll(PDO::FETCH_ASSOC) as $p) { $puantaj_data[$p['ay']] = $p; }

$sql_m = "SELECT * FROM puantaj_mahalleler WHERE personel_id = ? AND yil = ? AND ay BETWEEN ? AND ? ORDER BY ay ASC";
$stmt_m = $pdo->prepare($sql_m);
$stmt_m->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$mahalle_data = [];
foreach($stmt_m->fetchAll(PDO::FETCH_ASSOC) as $m) { $mahalle_data[$m['ay']] = $m; }

// Sadece açıklamayı çekiyoruz (Görev türü iptal edildi)
$sql_detay = "SELECT d.* FROM arazi_tazminati_detay d WHERE d.personel_id = ? AND d.yil = ? AND d.ay BETWEEN ? AND ?";
$stmt_detay = $pdo->prepare($sql_detay);
$stmt_detay->execute([$user_id, $yil, $bas_ay, $bit_ay]);
$detaylar = [];
foreach($stmt_detay->fetchAll(PDO::FETCH_ASSOC) as $d) {
    $detaylar[$d['ay']][$d['gun']] = $d['aciklama']; // Sadece açıklama
}

$arazi_kodlari = ["AT", "AK", "AS", "AKS", "Arazi Tazminatı", "Arazi + Kontrol", "Arazi + Seyyar", "Arazi + Kontrol + Seyyar"];
$bugun = date("d.m.Y"); 
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Arazi Tazminatı Cetveli</title>
    <style>
        /* GENEL SAYFA AYARLARI (PDF GÖRÜNÜMÜ İÇİN) */
        body {
            background-color: #525659; /* PDF Okuyucu Grisi */
            font-family: "Times New Roman", Times, serif;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
        }

        /* A4 KAĞIT SİMÜLASYONU */
        .page {
            background-color: white;
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 15mm; /* Kağıt kenar boşlukları */
            box-shadow: 0 0 10px rgba(0,0,0,0.5); /* Gölge efekti */
            box-sizing: border-box;
            position: relative;
        }

        /* BUTONLAR (EKRANIN SAĞ ÜSTÜNE SABİT) */
        .kontrol-paneli {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            cursor: pointer;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            font-family: Arial, sans-serif;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }
        .btn-yazdir { background-color: #28a745; }
        .btn-kapat { background-color: #dc3545; }

        /* TABLO STİLLERİ */
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
        .header h3 { margin: 4px 0; font-size: 16pt; font-weight: bold; }
        .header h4 { margin: 4px 0; font-size: 12pt; font-weight: normal; }

        .info-table { width: 100%; margin-bottom: 15px; }
        .info-table td { padding: 3px; font-size: 11pt; }

        .main-table { width: 100%; border-collapse: collapse; font-size: 10pt; }
        .main-table th, .main-table td { border: 1px solid #000; padding: 5px; vertical-align: top; }
        .main-table th { background-color: #eee; text-align: center; font-weight: bold; }
        
        .ay-ayirac { background-color: #f0f0f0; font-weight: bold; text-align: center; }

        .imza-container { margin-top: 50px; display: flex; justify-content: space-between; page-break-inside: avoid; }
        .imza-box { width: 45%; text-align: center; }

        /* --- YAZICI AYARLARI (CTRL+P YAPINCA BURASI ÇALIŞIR) --- */
        @media print {
            body { 
                background-color: white; /* Arka planı beyaz yap */
                margin: 0; padding: 0; display: block; 
            }
            .page {
                width: 100%; margin: 0; padding: 0; 
                box-shadow: none; /* Gölgeyi kaldır */
                border: none;
            }
            .kontrol-paneli { display: none; } /* Butonları gizle */
            @page { margin: 15mm 15mm 15mm 15mm; size: A4; }
        }
    </style>
</head>
<body>

    <div class="kontrol-paneli">
        <button onclick="window.print()" class="btn btn-yazdir">🖨️ YAZDIR</button>
        <button onclick="window.close()" class="btn btn-kapat">❌ KAPAT</button>
    </div>

    <div class="page">
        
        <div class="header">
            <h3>T.C.</h3>
            <h3><?php echo mb_convert_case($kurum_adi, MB_CASE_UPPER, "UTF-8"); ?></h3>
            <h4><?php echo $yil; ?> YILI <?php echo $donem_ad; ?> ARAZİ TAZMİNATI BİLDİRİM CETVELİ</h4>
        </div>

        <table class="info-table">
            <tr>
                <td style="width: 120px;"><strong>Adı Soyadı</strong></td>
                <td>: <?php echo mb_convert_case($personel['ad_soyad'], MB_CASE_UPPER, "UTF-8"); ?></td>
            </tr>
            <tr>
                <td><strong>Unvanı</strong></td>
                <td>: <?php echo mb_convert_case($personel['unvan'], MB_CASE_UPPER, "UTF-8"); ?></td>
            </tr>
        </table>

        <table class="main-table">
            <thead>
                <tr>
                    <th style="width: 100px;">TARİH</th>
                    <th style="width: 180px;">GİDİLEN YER (MAHALLE)</th>
                    <th>YAPILAN HİZMETİN KONUSU VE AÇIKLAMASI</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $toplam_gun = 0;
                for ($ay_dongu = $bas_ay; $ay_dongu <= $bit_ay; $ay_dongu++): 
                    if(!isset($puantaj_data[$ay_dongu])) continue;
                    
                    $bu_ayin_verisi = $puantaj_data[$ay_dongu];
                    $ayda_kayit_varmi = false;
                    
                    // Bu ayda kayıt var mı kontrolü
                    for($k=1; $k<=31; $k++) {
                        if(in_array(trim($bu_ayin_verisi['gun'.$k] ?? ''), $arazi_kodlari)) { $ayda_kayit_varmi = true; break; }
                    }
                    if(!$ayda_kayit_varmi) continue;

                    echo '<tr><td colspan="3" class="ay-ayirac">' . $ay_isimleri[$ay_dongu] . '</td></tr>';
                    
                    for ($i = 1; $i <= 31; $i++): 
                        $kod = trim($bu_ayin_verisi['gun'.$i] ?? '');
                        if (in_array($kod, $arazi_kodlari)):
                            $toplam_gun++;
                            $tarih_str = sprintf("%02d.%02d.%04d", $i, $ay_dongu, $yil);
                            
                            $ham_mahalle = $mahalle_data[$ay_dongu]['gun'.$i] ?? '';
                            $mahalle = mb_convert_case($ham_mahalle, MB_CASE_TITLE, "UTF-8");
                            
                            // *** SADECE AÇIKLAMAYI ALIYORUZ ***
                            $aciklama = $detaylar[$ay_dongu][$i] ?? ''; 
                            if(empty($aciklama)) $aciklama = "-";
                ?>
                <tr>
                    <td style="text-align:center;"><?php echo $tarih_str; ?></td>
                    <td><?php echo $mahalle; ?></td>
                    <td><?php echo $aciklama; ?></td> </tr>
                <?php 
                        endif; 
                    endfor; 
                endfor; 
                ?>
            </tbody>
        </table>
        
        <div style="margin-top:15px; font-weight:bold;">
            Toplam Arazi Günü: <?php echo $toplam_gun; ?> Gün
        </div>

        <div class="imza-container">
            <div class="imza-box">
                <p>BİLDİRİMDE BULUNAN</p><br><br>
                <strong><?php echo mb_convert_case($personel['ad_soyad'], MB_CASE_UPPER, "UTF-8"); ?></strong><br>
                <?php echo $personel['unvan']; ?><br>
                Tarih: <?php echo $bugun; ?>
            </div>
            <div class="imza-box">
                <p>ONAYLAYAN</p><br><br>
                <strong>Hamit ÇAKAL</strong><br>
                İlçe Müdürü<br>
                İmza
            </div>
        </div>
    </div> </body>
</html>