<?php
// pages/ozel_arac_gorev.php
include_once '../includes/header.php';
include_once '../config/db.php'; 

$user_id = $_SESSION['user_id'];
$rol_id  = isset($_SESSION['rol_id']) ? $_SESSION['rol_id'] : 0;
$ad_soyad = $_SESSION['ad_soyad']; 

// Rol tabanlı yöneticilik
$yonetici_mi = in_array($rol_id, [1, 2]);

// --- YENİ EKLENEN KISIM: VEKİL KONTROLÜ ---
// Rolü ne olursa olsun, bu kişiye atanmış bekleyen görev var mı?
$stmt_vekil = $pdo->prepare("SELECT COUNT(*) FROM ozel_arac_gorevler WHERE gorev_kapali = 1 AND onay_durumu = 0 AND kurum_amiri_id = ?");
$stmt_vekil->execute([$user_id]);
$bana_atanan_gorev_var = ($stmt_vekil->fetchColumn() > 0);

// Onay sekmesini görme şartı: Ya Yönetici olacak YA DA adına görev atanmış olacak
$onay_sekmesi_goster = ($yonetici_mi || $bana_atanan_gorev_var);
// ------------------------------------------

// Ortak Veriler
$mahalleler = $pdo->query("SELECT id, ad FROM mahalleler ORDER BY ad")->fetchAll(PDO::FETCH_ASSOC);

// Kurum Amirleri
$kurum_amirleri = $pdo->query("SELECT y.personel_id, p.ad_soyad, y.unvan_gorunumu FROM yonetici_listesi y JOIN personel_bilgileri p ON y.personel_id = p.id WHERE y.rol = 'KURUM_AMIRI' AND y.aktif = 1")->fetchAll(PDO::FETCH_ASSOC);

// Varsayılan Amir ID
$varsayilan_amir_id = !empty($kurum_amirleri) ? $kurum_amirleri[0]['personel_id'] : "";

// 1. Personelin Kendi Görevleri
$sql_benim = "SELECT o.*, gt.ad as gorev_turu_ad, m.ad as mahalle_ad
              FROM ozel_arac_gorevler o
              LEFT JOIN gorev_turleri gt ON o.gorev_turu_id = gt.id
              LEFT JOIN mahalleler m ON o.mahalle_id = m.id
              WHERE o.gorevli_personel_id = ?
              ORDER BY o.gorev_tarihi DESC, o.cikis_saat DESC";
$stmt = $pdo->prepare($sql_benim);
$stmt->execute([$user_id]);
$benim_gorevlerim = $stmt->fetchAll(PDO::FETCH_ASSOC);


// 2. Onay Bekleyenler (GÜNCELLENDİ)
$onay_bekleyenler = [];

// Eğer görme yetkisi varsa sorguyu çalıştır
if ($onay_sekmesi_goster) {
    
    $sql_onay = "SELECT o.*, p.ad_soyad as personel_ad, gt.ad as gorev_turu_ad, m.ad as mahalle_ad
                 FROM ozel_arac_gorevler o
                 JOIN personel_bilgileri p ON o.gorevli_personel_id = p.id
                 LEFT JOIN gorev_turleri gt ON o.gorev_turu_id = gt.id
                 LEFT JOIN mahalleler m ON o.mahalle_id = m.id
                 WHERE o.gorev_kapali = 1 
                   AND o.onay_durumu = 0";
    
    // GÜNCELLEME: Admin (1) herkesi görsün, Müdür(2) ve Vekil(5) sadece kendini görsün
    if ($rol_id == 1) {
        // Admin hepsini görür, ek şart yok
        $sql_onay .= " ORDER BY o.gorev_tarihi ASC";
        $stmt_onay = $pdo->query($sql_onay);
    } else {
        // Diğerleri (Müdür ve Vekil) sadece kendine atananı görür
        $sql_onay .= " AND o.kurum_amiri_id = ? ORDER BY o.gorev_tarihi ASC";
        $stmt_onay = $pdo->prepare($sql_onay);
        $stmt_onay->execute([$user_id]);
    }
    
    $onay_bekleyenler = $stmt_onay->fetchAll(PDO::FETCH_ASSOC);
}
?>

<style>
    input, select, .form-select, .select2-container { width: 100% !important; }
    .nav-tabs .nav-link { color: #555; font-weight: bold; }
    .nav-tabs .nav-link.active { color: #198754; border-top: 3px solid #198754; background-color: #fff; }
    .badge-bildirim { position: absolute; top: -5px; right: -5px; font-size: 0.7em; }
    /* İptal edilen satır stili */
    .row-cancelled { background-color: #f8f9fa !important; color: #adb5bd !important; }
    .row-cancelled .badge { opacity: 0.6; }
</style>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="text-success"><i class="fas fa-car-side"></i> Özel Araç Görev İşlemleri</h4>
        <button class="btn btn-success" onclick="yeniKayitModal()">
            <i class="fas fa-plus"></i> Yeni Görev Yaz
        </button>
    </div>

    <ul class="nav nav-tabs" id="gorevTablar" role="tablist">
        <li class="nav-item">
            <button class="nav-link active" id="benim-tab" data-bs-toggle="tab" data-bs-target="#benim-pane" type="button">
                <i class="fas fa-user"></i> Görevlerim
            </button>
        </li>
        
        <?php if ($onay_sekmesi_goster): ?>
        <li class="nav-item position-relative">
            <button class="nav-link" id="onay-tab" data-bs-toggle="tab" data-bs-target="#onay-pane" type="button">
                <i class="fas fa-clipboard-check"></i> Onay İşlemleri
                <?php if(count($onay_bekleyenler) > 0): ?>
                    <span id="onaySayisi" class="badge bg-danger rounded-pill badge-bildirim"><?php echo count($onay_bekleyenler); ?></span>
                <?php endif; ?>
            </button>
        </li>
        <?php endif; ?>
    </ul>

    <div class="tab-content bg-white border border-top-0 p-3 shadow-sm" id="gorevTabIcerik">
        
        <div class="tab-pane fade show active" id="benim-pane">
            <div class="table-responsive">
                <table id="tabloBenim" class="table table-bordered table-hover mt-2">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tarih</th>
                            <th>Plaka / Sahibi</th>
                            <th>Gidilen Yer</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($benim_gorevlerim as $k): 
                            $is_cancelled = ($k['onay_durumu'] == 3);
                        ?>
                        <tr class="<?php echo $is_cancelled ? 'row-cancelled' : ''; ?>">
                            <td class="fw-bold text-center"><?php echo $k['gorev_no']; ?></td>
                            <td><?php echo date('d.m.Y', strtotime($k['gorev_tarihi'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($k['arac_plaka']); ?></strong><br>
                                <small><?php echo htmlspecialchars($k['arac_sahibi']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($k['mahalle_ad']); ?></td>
                            <td>
                                <?php if($k['onay_durumu'] == 1): ?>
                                    <span class="badge bg-success">Onaylandı</span>
                                <?php elseif($k['onay_durumu'] == 2): ?>
                                    <span class="badge bg-danger">Reddedildi</span>
                                <?php elseif($k['onay_durumu'] == 3): ?>
                                    <span class="badge bg-secondary">İptal Edildi</span>
                                <?php elseif($k['gorev_kapali'] == 1): ?>
                                    <span class="badge bg-info text-dark">Onay Bekliyor</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Görevde</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-nowrap">
                                <?php if (!$is_cancelled): ?>
                                    <a href="yazdir_ozel_gorev.php?id=<?php echo $k['id']; ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i></a>
                                    
                                    <?php if($k['onay_durumu'] == 2): ?>
                                        <button class="btn btn-dark btn-sm btn-islem" data-tur="incele" data-id="<?php echo $k['id']; ?>"><i class="fas fa-eye"></i></button>
                                    <?php elseif($k['gorev_kapali'] == 0): ?>
                                        <button class="btn btn-warning btn-sm btn-islem" data-tur="bitir" data-id="<?php echo $k['id']; ?>"><i class="fas fa-flag-checkered"></i></button>
                                        <button class="btn btn-primary btn-sm btn-islem" data-tur="duzenle" data-id="<?php echo $k['id']; ?>"><i class="fas fa-edit"></i></button>
                                        <button class="btn btn-danger btn-sm btn-islem" data-tur="sil" data-id="<?php echo $k['id']; ?>"><i class="fas fa-trash"></i></button>
                                    <?php else: ?>
                                        <button class="btn btn-info btn-sm btn-islem" data-tur="incele" data-id="<?php echo $k['id']; ?>"><i class="fas fa-eye"></i></button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <small class="text-muted">İşlem Yapılamaz</small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <?php if ($onay_sekmesi_goster): ?>
        <div class="tab-pane fade" id="onay-pane">
            <?php if (empty($onay_bekleyenler)): ?>
                <div class="alert alert-success mt-3"><i class="fas fa-check-circle"></i> Onay bekleyen yok.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table id="tabloOnay" class="table table-bordered table-hover mt-2 align-middle">
                        <thead class="table-warning">
                            <tr>
                                <th>No</th>
                                <th>Personel</th>
                                <th>Tarih</th>
                                <th>Plaka / Sahibi</th>
                                <th>Gidilen Yer</th>
                                <th>Saatler</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($onay_bekleyenler as $b): ?>
                            <tr>
                                <td class="fw-bold text-center"><?php echo $b['gorev_no']; ?></td>
                                <td class="fw-bold"><?php echo htmlspecialchars($b['personel_ad']); ?></td>
                                <td><?php echo date('d.m.Y', strtotime($b['gorev_tarihi'])); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($b['arac_plaka']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($b['arac_sahibi']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($b['mahalle_ad']); ?></td>
                                <td>
                                    Ç: <?php echo substr($b['cikis_saat'], 0, 5); ?><br>
                                    D: <?php echo substr($b['donus_saat'], 0, 5); ?>
                                </td>
                                <td>
                                    <div class="btn-group w-100">
                                        <a href="yazdir_ozel_gorev.php?id=<?php echo $b['id']; ?>" target="_blank" class="btn btn-sm btn-secondary"><i class="fas fa-file-alt"></i></a>
                                        <button class="btn btn-sm btn-success btn-yonetici" data-action="onayla" data-id="<?php echo $b['id']; ?>"><i class="fas fa-check"></i> Onayla</button>
                                        <button class="btn btn-sm btn-danger btn-yonetici" data-action="reddet" data-id="<?php echo $b['id']; ?>"><i class="fas fa-ban"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="ozelModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="modalBaslik">Özel Araç Görev Formu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="ozelForm">
                    <input type="hidden" name="gorev_id" id="gorev_id">
                    <input type="hidden" name="action" id="action" value="kaydet">

                    <div id="cikis_alani">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Araç Sahibi <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="arac_sahibi" id="arac_sahibi" placeholder="Ad Soyad" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Plaka <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="arac_plaka" id="arac_plaka" placeholder="35 ABC 123" required onkeyup="this.value = this.value.toUpperCase();">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Tarih <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="gorev_tarihi" id="gorev_tarihi" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Gidilecek Yer <span class="text-danger">*</span></label>
                                <select class="form-select select2" name="mahalle_id" id="mahalle_id" required>
                                    <option value="">Seçiniz</option>
                                    <?php foreach ($mahalleler as $m): ?>
                                        <option value="<?php echo $m['id']; ?>"><?php echo htmlspecialchars($m['ad']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Görev Türü (Birime Özel) <span class="text-danger">*</span></label>
                                <select class="form-select" name="gorev_turu_id" id="gorev_turu_id" required>
                                    <option value="">Yükleniyor...</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Çıkış Saati <span class="text-danger">*</span></label>
                                <input type="time" class="form-control" name="cikis_saat" id="cikis_saat" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="form-label fw-bold">Onaylayacak Kurum Amiri <span class="text-danger">*</span></label>
                                <select class="form-select select2" name="kurum_amiri_id" id="kurum_amiri_id" required>
                                    <option value="">Seçiniz</option>
                                    <?php foreach ($kurum_amirleri as $ka): ?>
                                        <option value="<?php echo $ka['personel_id']; ?>">
                                            <?php echo $ka['ad_soyad']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div id="donus_alani" style="display:none;" class="bg-light p-3 border rounded mt-3">
                        <h6 class="text-success border-bottom pb-2">Dönüş Bilgileri</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Dönüş Tarihi</label>
                                <input type="date" class="form-control" name="donus_tarihi" id="donus_tarihi">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Dönüş Saati</label>
                                <input type="time" class="form-control" name="donus_saat" id="donus_saat">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                <button type="button" class="btn btn-success" id="kaydetBtn" onclick="formuGonder()">Kaydet</button>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    $('.select2').select2({ dropdownParent: $('#ozelModal'), placeholder: "Seçiniz" });
    if ($.fn.DataTable) {
        $('#tabloBenim').DataTable({ 
            "language": { "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Turkish.json" },
            "order": [[0, "desc"]] 
        });
        $('#tabloOnay').DataTable({ "language": { "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Turkish.json" } });
    }

    gorevTurleriniGetir();

    $(document).on('click', '.btn-islem', function() {
        var tur = $(this).data('tur');
        var id = $(this).data('id');

        if (tur === 'sil') {
            if(confirm('Görevi iptal etmek istediğinize emin misiniz?')) 
                ajaxIslem({ action: 'sil', id: id });
        } else if (tur === 'duzenle') {
            veriCekVeDoldur(id, 'kaydet', false);
            $('#modalBaslik').text('Görevi Düzenle');
            $('#kaydetBtn').show().text('Güncelle');
        } else if (tur === 'incele') {
            veriCekVeDoldur(id, '', true);
            $('#modalBaslik').text('Görev Detayı');
            $('#kaydetBtn').hide();
        } else if (tur === 'bitir') {
            veriCekVeDoldur(id, 'gorev_bitir', false);
            $('#donus_alani').show();
            $('#cikis_alani input, #cikis_alani select').prop('disabled', true);
            var today = new Date().toISOString().split('T')[0];
            $('#donus_tarihi').val(today);
            $('#kaydetBtn').show().text('Görevi Kapat');
            $('#modalBaslik').text('Dönüş İşlemleri');
        }
    });

    $(document).on('click', '.btn-yonetici', function() {
        var btn = $(this);
        var action = btn.data('action');
        var id = btn.data('id');
        var msg = (action == 'onayla') ? 'Onaylıyor musunuz?' : 'Bu görevi REDDEDİYOR musunuz?';
        if(confirm(msg)) {
            $.post('../ajax/ajax_ozel_arac_islem.php', { action: action, id: id }, function(res) {
                if(res.status == 'success') {
                   btn.closest('tr').fadeOut(500, function () {
                        $(this).remove();
                        var badge = $('#onaySayisi');
                        if (badge.length) {
                            var sayi = parseInt(badge.text()) || 0;
                            sayi--;
                            if (sayi <= 0) badge.remove(); else badge.text(sayi);
                        }
                        if ($('#tabloOnay tbody tr').length === 0) {
                            $('#onay-pane').html('<div class="alert alert-success mt-3"><i class="fas fa-check-circle"></i> Onay bekleyen yok.</div>');
                        }
                    });
                } else { alert(res.message); }
            }, 'json');
        }
    });
});

function gorevTurleriniGetir(seciliID = null) {
    $.post('../ajax/ajax_ozel_arac_islem.php', { action: 'turleri_getir' }, function(res) {
        if(res.status === 'success') {
            var options = '<option value="">Seçiniz</option>';
            $.each(res.data, function(index, item) {
                options += '<option value="' + item.id + '">' + item.ad + '</option>';
            });
            $('#gorev_turu_id').html(options);
            if(seciliID) $('#gorev_turu_id').val(seciliID);
        }
    }, 'json');
}

function ajaxIslem(data) {
    $.post('../ajax/ajax_ozel_arac_islem.php', data, function(res) {
        alert(res.message); if(res.status=='success') location.reload();
    }, 'json');
}

function veriCekVeDoldur(id, actionTuru, saltOkunur) {
    $.post('../ajax/ajax_ozel_arac_islem.php', { action: 'detay_getir', id: id }, function(res) {
        if(res.status == 'success') {
            var d = res.data;
            $('#ozelForm')[0].reset();
            $('#gorev_id').val(d.id);
            $('#action').val(actionTuru);
            $('#arac_sahibi').val(d.arac_sahibi);
            $('#arac_plaka').val(d.arac_plaka);
            $('#gorev_tarihi').val(d.gorev_tarihi);
            $('#gorev_turu_id').val(d.gorev_turu_id); 
            $('#mahalle_id').val(d.mahalle_id).trigger('change');
            $('#kurum_amiri_id').val(d.kurum_amiri_id).trigger('change');
            $('#cikis_saat').val(d.cikis_saat);
            if(d.donus_saat) $('#donus_saat').val(d.donus_saat);
            if(d.donus_tarihi) $('#donus_tarihi').val(d.donus_tarihi);

            if(saltOkunur) {
                $('#ozelForm input, #ozelForm select').prop('disabled', true);
                $('#donus_alani').show();
            } else {
                if(actionTuru !== 'gorev_bitir') {
                    $('#cikis_alani input, #cikis_alani select').prop('disabled', false);
                    $('#donus_alani').hide();
                }
            }
            $('#ozelModal').modal('show');
        }
    }, 'json');
}

function yeniKayitModal() {
    $('#ozelForm')[0].reset();
    $('#action').val('kaydet');
    $('#gorev_id').val('');
    $('#cikis_alani input, #cikis_alani select').prop('disabled', false);
    var defaultAmir = '<?php echo $varsayilan_amir_id; ?>';
    $('.select2').val(null).trigger('change');
    if(defaultAmir) $('#kurum_amiri_id').val(defaultAmir).trigger('change');
    gorevTurleriniGetir();
    $('#donus_alani').hide();
    $('#kaydetBtn').show().text('Kaydet');
    $('#modalBaslik').text('Yeni Özel Araç Görevi');
    $('#ozelModal').modal('show');
}

function formuGonder() {
    var disabled = $('#ozelForm').find(':input:disabled').removeAttr('disabled');
    var data = $('#ozelForm').serialize();
    disabled.prop('disabled', true);
    ajaxIslem(data);
}
</script>