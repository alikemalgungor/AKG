<?php
// pages/puantaj.php
session_start();
include_once '../config/db.php';
include_once '../includes/header.php'; 

$user_id  = $_SESSION['user_id'];
$birim_id = $_SESSION['birim_id'] ?? 0; 
$rol_id   = $_SESSION['rol_id'] ?? 0;   

$yonetici_mi      = in_array($rol_id, [1, 2, 3]); 
$arazi_gorebilir  = [2]; //
$seyyar_gorebilir = [1, 2, 3, 4]; 

$mahalle_bilgileri = [];
try {
    $stmt = $pdo->query("SELECT ad, gorev_turu FROM mahalleler WHERE aktif = 1");
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $mahalle_bilgileri[$row['ad']] = $row['gorev_turu'];
    }
} catch (Exception $e) { $mahalle_bilgileri = []; }

$yil = isset($_GET['yil']) ? intval($_GET['yil']) : date('Y');
$ay  = isset($_GET['ay'])  ? intval($_GET['ay'])  : date('m');

$sql_ist = "SELECT 
    SUM(CASE WHEN ay BETWEEN 1 AND 3 THEN toplam_arazi_gorev ELSE 0 END) as arazi_q1,
    SUM(CASE WHEN ay BETWEEN 4 AND 6 THEN toplam_arazi_gorev ELSE 0 END) as arazi_q2,
    SUM(CASE WHEN ay BETWEEN 7 AND 9 THEN toplam_arazi_gorev ELSE 0 END) as arazi_q3,
    SUM(CASE WHEN ay BETWEEN 10 AND 12 THEN toplam_arazi_gorev ELSE 0 END) as arazi_q4,
    SUM(CASE WHEN ay BETWEEN 1 AND 6 THEN toplam_seyyar_gorev ELSE 0 END) as seyyar_d1,
    SUM(CASE WHEN ay BETWEEN 7 AND 12 THEN toplam_seyyar_gorev ELSE 0 END) as seyyar_d2,
    ".implode(',', array_map(fn($m) => "SUM(CASE WHEN ay = $m THEN toplam_kon_gor_gunu ELSE 0 END) as k_$m", range(1,12)))."
    FROM puantaj_aylik WHERE personel_id = ? AND yil = ?";
$stmt_ist = $pdo->prepare($sql_ist);
$stmt_ist->execute([$user_id, $yil]); 
$ist = $stmt_ist->fetch(PDO::FETCH_ASSOC);

$arazi_q = [$ist['arazi_q1']??0, $ist['arazi_q2']??0, $ist['arazi_q3']??0, $ist['arazi_q4']??0];
$kalan_hak_arazi = 20 - ($arazi_q[ceil($ay/3)-1] ?? 0);
?>

<style>
    .takvim-baslik { background: #e7f1ff; color: #0d6efd; text-align: center; padding: 10px; font-weight: bold; font-size: 0.8rem; border: 1px solid #dee2e6; }
    .takvim { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; background: #f8f9fa; padding: 5px; border-radius: 8px; border: 1px solid #dee2e6; }
    .gun-kutu { background: #fff; min-height: 140px; padding: 5px; border-radius: 4px; display: flex; flex-direction: column; border: 1px solid #dee2e6; }
    .haftasonu { background: #fff5f5; }
    .gun-numara { font-weight: bold; border-bottom: 1px solid #f1f1f1; margin-bottom: 5px; color: #495057; }
    .mahalle-onay-alani { display: flex; flex-wrap: wrap; gap: 5px; font-size: 0.65rem; margin-top: 5px; border-top: 1px dashed #eee; padding-top: 5px; }
    .mahalle-item { display: flex; align-items: center; gap: 3px; background: #f0f7ff; padding: 2px 5px; border-radius: 3px; border: 1px solid #d0e3ff; }
    .mahalle-item.disabled { background: #f8f9fa; border-color: #eee; opacity: 0.6; }
    .form-check-input { cursor: pointer; width: 13px; height: 13px; margin: 0; }
    .form-check-input:disabled { cursor: not-allowed; }
    .puan-select { font-size: 0.72rem !important; height: 28px !important; border-color: #ced4da; font-weight: bold; }
    .badge-month { font-size: 0.65rem; width: 42px; padding: 5px 0; }
    
    .ust-istatistik-container { background: #fff; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; display: flex; align-items: center; gap: 20px; overflow-x: auto; }
    .ist-bolum { display: flex; flex-direction: column; align-items: center; border-right: 1px solid #eee; padding: 0 15px; white-space: nowrap; }
    .ist-bolum:last-child { border-right: none; }
    .ist-baslik { font-size: 0.75rem; font-weight: bold; color: #6c757d; margin-bottom: 8px; text-transform: uppercase; }
    /* İzinli günler için sarı tonu */
    .izinli-gun { background-color: #fff3cd !important; border: 1px solid #ffeeba !important; }
    /* Resmi tatiller için yeşil tonu */
    .tatil-gun { background-color: #d1e7dd !important; border: 1px solid #badbcc !important; }
    /* Yazı renklerini belirginleştir */
    .izinli-gun .gun-numara { color: #856404; }
    .tatil-gun .gun-numara { color: #0f5132; }
</style>

<div class="container-fluid py-3">
    <input type="hidden" id="aktifBirimID" value="<?= $birim_id ?>">
    
    <ul class="nav nav-tabs mb-3 shadow-sm bg-white" id="puantajTab">
        <li class="nav-item"><button class="nav-link active fw-bold" data-bs-toggle="tab" data-bs-target="#home-tab-pane">PUANTAJ GİRİŞİ</button></li>
        <li class="nav-item"><button class="nav-link fw-bold" onclick="loadTabContent('kontrol')" data-bs-toggle="tab" data-bs-target="#kontrol-tab-pane">KONTROL G.</button></li>
        <?php if ($yonetici_mi || in_array($birim_id, $arazi_gorebilir)): ?>
        <li class="nav-item"><button class="nav-link fw-bold" onclick="loadTabContent('arazi')" data-bs-toggle="tab" data-bs-target="#arazi-tab-pane">ARAZİ T.</button></li>
        <?php endif; ?>
        <?php if ($yonetici_mi || in_array($birim_id, $seyyar_gorebilir)): ?>
        <li class="nav-item"><button class="nav-link fw-bold" onclick="loadTabContent('seyyar')" data-bs-toggle="tab" data-bs-target="#seyyar-tab-pane">SEYYAR G.</button></li>
        <?php endif; ?>
    </ul>

    <div class="tab-content" id="puantajTabContent">
        <div class="tab-pane fade show active" id="home-tab-pane">
            <div class="ust-istatistik-container shadow-sm mb-3">
                <div class="ist-bolum">
                    <span class="ist-baslik">DÖNEM</span>
                    <div class="d-flex gap-1">
                        <select id="yilSec" class="form-select form-select-sm" style="width:85px;"></select>
                        <select id="aySec" class="form-select form-select-sm" style="width:100px;"></select>
                    </div>
                </div>

                <div class="ist-bolum">
                    <span class="ist-baslik">KONTROL GÖREVİ (YILLIK)</span>
                    <div class="d-flex gap-1">
                        <?php 
                        $aylar = ["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"];
                        for($i=1; $i<=12; $i++): 
                            $v = $ist['k_'.$i] ?? 0;
                            $cls = ($v > 0) ? 'bg-primary' : 'bg-light text-muted border';
                        ?>
                            <span class="badge badge-month <?=$cls?>" id="stat_month_<?=$i?>"><?= $aylar[$i-1] ?><br><?= $v > 0 ? intval($v) : '-' ?></span>
                        <?php endfor; ?>
                    </div>
                </div>

                <?php if(in_array($birim_id, $arazi_gorebilir)): ?>
                <div class="ist-bolum">
                    <span class="ist-baslik text-danger">ARAZİ (ÇEYREK)</span>
                    <div class="d-flex gap-1">
                        <?php for($q=1; $q<=4; $q++): ?>
                            <span class="badge <?= ceil($ay/3)==$q ? 'bg-danger' : 'bg-light text-muted border' ?>">Q<?=$q?>: <?= $arazi_q[$q-1] ?></span>
                        <?php endfor; ?>
                    </div>
                    <div class="text-danger fw-bold mt-1" style="font-size:0.7rem;">Kalan Hak: <?= $kalan_hak_arazi ?></div>
                </div>
                <?php endif; ?>

                <div class="ist-bolum">
                    <span class="ist-baslik text-success">SEYYAR (DÖNEM)</span>
                    <div class="d-flex gap-1">
                        <span class="badge <?= $ay<=6 ? 'bg-success' : 'bg-light text-muted border' ?>">1.D: <?= $ist['seyyar_d1']??0 ?></span>
                        <span class="badge <?= $ay>6 ? 'bg-success' : 'bg-light text-muted border' ?>">2.D: <?= $ist['seyyar_d2']??0 ?></span>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white py-2 d-flex justify-content-between align-items-center">
                    <h5 id="baslik" class="m-0 text-primary fw-bold" style="font-size:1.1rem;"></h5>
                    <div class="btn-group">
                        <button id="bulBtn" class="btn btn-sm btn-info text-white px-3"><i class="fas fa-search me-1"></i> BUL</button>
                        <button id="silBtn" class="btn btn-sm btn-danger px-3"><i class="fas fa-trash-alt me-1"></i> SİL</button>
                        <button id="kaydetBtn" class="btn btn-sm btn-success fw-bold px-4" onclick="kaydet()"><i class="fas fa-save me-1"></i> KAYDET</button>
                    </div>
                </div>
                <div class="card-body p-2">
                    <div id="takvimAlani" class="takvim"></div>
                </div>
            </div>

            <div class="row g-2 shadow-sm p-3 bg-white mb-4 rounded border text-center">
                <div class="col-md-1"><label class="small fw-bold">Şoförlük</label><input type="text" id="arac_kullanim" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-2"><label class="small fw-bold text-info">Şoför Puan</label><input type="number" id="sofor_puani_ekran" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-2"><label class="small fw-bold text-primary">Kontrol Puan</label><input type="number" id="kongor_puani" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-1"><label class="small fw-bold text-danger">Arazi G.</label><input type="number" id="arazi_toplam" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-1"><label class="small fw-bold text-success">Seyyar G.</label><input type="number" id="seyyar_toplam" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-1"><label class="small fw-bold">Çal. Gün</label><input type="number" id="toplam_gun" class="form-control form-control-sm text-center fw-bold" disabled></div>
                <div class="col-md-2"><label class="small fw-bold text-dark border-bottom">TOPLAM PUAN</label><input type="number" id="aylik_toplam_puan_ekran" class="form-control form-control-sm text-center fw-bold bg-light" style="font-size: 1.1rem; color: #000;" disabled></div>
                <input type="hidden" id="kontrol_gorev_gunu" value="0">
            </div>
        </div>
        <div class="tab-pane fade" id="kontrol-tab-pane"></div>
        <div class="tab-pane fade" id="arazi-tab-pane"></div>
        <div class="tab-pane fade" id="seyyar-tab-pane"></div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>

<script>
/* Türkçe karakterleri bozmadan aktarmak için */
const MAHALLE_SOZLUK = <?php echo json_encode($mahalle_bilgileri, JSON_UNESCAPED_UNICODE); ?>;
const TERS_SOZLUK = { "Arazi Tazminatı": "AT", "Kontrol Görevi": "KG", "Arazi + Kontrol": "AK", "Arazi + Kontrol + Seyyar": "AKS", "Kontrol G + Seyyar G": "KS", "Resmî Tatil": "RT", "İzin": "IZ", "Seyyar Görev": "SG" };
const birimID = parseInt(document.getElementById("aktifBirimID").value);

document.addEventListener("DOMContentLoaded", () => { yilAyDoldur(); takvimOlustur(); });

function yilAyDoldur(){
    const yilSec = document.getElementById("yilSec"), aySec = document.getElementById("aySec");
    const y = <?=$yil?>, a = <?=$ay?>;
    for(let i=2024; i<=2026; i++) yilSec.add(new Option(i, i, i==y, i==y));
    ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"].forEach((n,i)=>aySec.add(new Option(n, i+1, (i+1)==a, (i+1)==a)));
}

document.getElementById("yilSec").addEventListener("change", takvimOlustur);
document.getElementById("aySec").addEventListener("change", takvimOlustur);

function takvimOlustur(){
    const yil = document.getElementById("yilSec").value, ay = document.getElementById("aySec").value;
    document.getElementById("baslik").innerText = `${yil} Yılı / ${document.getElementById("aySec").options[ay-1].text}`;
    let html = "";
    ["Pzt","Sal","Çar","Per","Cum","Cmt","Paz"].forEach(g => html += `<div class="takvim-baslik">${g}</div>`);
    const lastDay = new Date(yil, ay, 0).getDate();
    let start = new Date(yil, ay-1, 1).getDay(); if(start===0) start=7;
    for(let b=1; b<start; b++) html += `<div class="bos-kutu"></div>`;
    for(let g=1; g<=lastDay; g++){
        const isHaftaSonu = ([0,6].includes(new Date(yil, ay-1, g).getDay()));
        html += `<div class="gun-kutu ${isHaftaSonu?'haftasonu':''}">
            <div class="gun-numara">${g}</div>
            <select id="sec_${g}" class="form-select form-select-sm puan-select" ${isHaftaSonu?'disabled':''} onchange="guncelleEkVeriler()"></select>
            <div id="mah_liste_${g}" class="mahalle-onay-alani"></div>
        </div>`;
    }
    document.getElementById("takvimAlani").innerHTML = html;
    if([1,2,3,4].includes(birimID)) aracGorevleriGetir(yil, ay);
    kilitKontroluSorgula();
}

function mahalleTiklandi(checkbox, gun) {
    // Checkbox tekillik kontrolü
    if(checkbox && checkbox.checked) {
        document.querySelectorAll(`#mah_liste_${gun} input[type="checkbox"]`).forEach(el => {
            if(el !== checkbox) el.checked = false;
        });
    }

    const sel = document.getElementById("sec_" + gun);
    const checkedInput = document.querySelector(`#mah_liste_${gun} input:checked`);
    const seciliMahalle = (checkedInput) ? checkedInput.value : null;
    const eskiDeger = sel.value; 
    
    // Select kutusunu sıfırla
    sel.innerHTML = '<option value="">Seçiniz...</option><option value="KG">Kontrol Görevi</option>';

    if (seciliMahalle) {
        // Mahalleyi sözlükten bul
        const mahalleTuru = MAHALLE_SOZLUK[seciliMahalle];

        // EĞER MAHALLE 'A' (ARAZİ) veya 'AS' (ARAZİ+SEYYAR) İSE
        if (mahalleTuru === 'A' || mahalleTuru === 'AS') {
            if (birimID === 2) { // Hayvan Sağlığı vb. (Araziye Çıkanlar)
                sel.add(new Option("Arazi Tazminatı", "AT"));
                sel.add(new Option("Arazi + Kontrol", "AK"));
                if (mahalleTuru === 'AS') sel.add(new Option("Arazi + Kontrol + Seyyar", "AKS"));
                
                if(!eskiDeger) sel.value = (mahalleTuru === 'AS') ? "AKS" : "AT"; 
            } else { // Diğer Birimler
                if (mahalleTuru === 'AS') {
                    sel.add(new Option("Kontrol G + Seyyar G", "KS"));
                    if(!eskiDeger) sel.value = "KS";
                } else {
                    if(!eskiDeger) sel.value = "KG";
                }
            }
        } 
        // EĞER MAHALLE TANIMLI DEĞİLSE VEYA ÖZEL ARAÇ İLE GİDİLEN BİR YERSE
        else {
            // Burası kritik: Özel araç görevleri genelde "Seyyar" (S) olarak geçer.
            sel.add(new Option("Seyyar Görev", "SG"));
            sel.add(new Option("Kontrol G + Seyyar G", "KS"));
            
            if (birimID === 2) { 
                 sel.add(new Option("Arazi + Kontrol + Seyyar", "AKS"));
            }

            // Varsayılan olarak Seyyar Görev (SG) seçilsin
            if(!eskiDeger) sel.value = "SG";
        }
    } 
    else {
        // Görev yoksa hafta içi kontrol yap
        const date = new Date(document.getElementById("yilSec").value, document.getElementById("aySec").value-1, gun);
        const day = date.getDay();
        if(![0,6].includes(day)) {
            if(!eskiDeger) sel.value = "KG";
        }
    }

    if(eskiDeger && [...sel.options].some(o => o.value === eskiDeger)) {
        sel.value = eskiDeger;
    }
    
    guncelleEkVeriler();
}

function aracGorevleriGetir(yil, ay){
    console.log("Araç görevleri ve izinler işleniyor...", yil, ay);
    
    fetch(`../ajax/ajax_arac_gorev.php?yil=${yil}&ay=${ay}`)
    .then(r => r.json())
    .then(veri => {
        if(document.getElementById("arac_kullanim")) {
            document.getElementById("arac_kullanim").value = (veri.soforluk) ? "Evet" : "Hayır";
        }

        const sonGun = new Date(yil, ay, 0).getDate();
        
        for(let g = 1; g <= sonGun; g++){
            const mahDiv = document.getElementById("mah_liste_" + g);
            const sel = document.getElementById("sec_" + g);
            const gunKutusu = sel ? sel.parentElement : null; // Günün ana kutusu (gun-kutu)

            if(!sel) continue;

            // --- İZİN VE TATİL KONTROLÜ ---
            const isIzin = veri.gun_izin && (veri.gun_izin[g] === true || veri.gun_izin[g] === "true" || parseInt(veri.gun_izin[g]) > 0);
            const isTatil = veri.gun_rtatil && (veri.gun_rtatil[g] === true || veri.gun_rtatil[g] === "true");

            if(isIzin || isTatil){
                const val = isIzin ? 'IZ' : 'RT';
               const text = isIzin ? 'İzinli Gün' : 'Resmî Tatil'; // İstediğin isimlerle güncellendi
                const renkSinifi = isIzin ? 'izinli-gun' : 'tatil-gun';
                
                sel.innerHTML = `<option value="${val}">${text}</option>`;
                sel.value = val;
                sel.disabled = true;
                
                // Renk sınıfını kutuya ekle
                if(gunKutusu) {
                    gunKutusu.classList.remove('haftasonu'); // Çakışmayı önlemek için hafta sonu rengini çıkar
                    gunKutusu.classList.add(renkSinifi);
                }

                if(mahDiv) mahDiv.innerHTML = "";
                continue; 
            }

            // --- NORMAL GÜNLER (MAHALLE İŞLEMLERİ) ---
            let rawMahalleler = veri.gun_arac ? veri.gun_arac[g] : null;
            const mahalleler = rawMahalleler ? (Array.isArray(rawMahalleler) ? rawMahalleler : Object.values(rawMahalleler)) : [];

            if(mahalleler.length > 0) {
                let h = "";
                mahalleler.forEach((m, idx) => {
                    const isChecked = (idx === 0); 
                    h += `<div class="mahalle-item" title="${m}">
                            <input class="form-check-input" type="checkbox" value="${m}" 
                            ${isChecked ? 'checked' : ''} 
                            onchange="mahalleTiklandi(this, ${g})">
                            <label class="form-check-label">${m.substring(0,12)}</label>
                          </div>`;
                });
                
                if(mahDiv) {
                    mahDiv.innerHTML = h;
                    const checkedBox = mahDiv.querySelector('input:checked');
                    if(checkedBox) mahalleTiklandi(checkedBox, g);
                }
            } else {
                mahalleTiklandi(null, g); 
            }
        }
        guncelleEkVeriler();
    })
    .catch(err => console.error("Veri hatası:", err));
}
function kilitKontroluSorgula() {
    const yil = document.getElementById("yilSec").value;
    const ay = document.getElementById("aySec").value;
    fetch(`../ajax/ajax_puantaj_islem.php`, {
        method: "POST",
        body: JSON.stringify({ yil, ay, action: 'bul' })
    })
    .then(r => r.json())
    .then(res => {
        const kaydetBtn = document.getElementById("kaydetBtn");
        const silBtn = document.getElementById("silBtn");
        if (res.status === "success" && res.data && res.data.kilit_durumu === "Kilitli") {
            kaydetBtn.disabled = true;
            silBtn.disabled = true;
            kaydetBtn.innerHTML = '<i class="fas fa-lock me-1"></i> KİLİTLİ';
            document.querySelectorAll('.puan-select, .form-check-input').forEach(el => el.disabled = true);
        } else {
            kaydetBtn.disabled = false;
            silBtn.disabled = false;
            kaydetBtn.innerHTML = '<i class="fas fa-save me-1"></i> KAYDET';
        }
    });
}

function kaydet() {
    const yil = document.getElementById("yilSec").value;
    const ay = document.getElementById("aySec").value;
    const bosGunler = [];
    for(let g=1; g<=31; g++){
        const sel = document.getElementById("sec_"+g);
        if(sel && !sel.disabled && !sel.value) bosGunler.push(g);
    }
    if(bosGunler.length > 0){
        if(!confirm(`⚠️ ${bosGunler.join(", ")} numaralı günler boş bırakıldı. Devam edilsin mi?`)) return;
    }

    const konPuan = parseInt(document.getElementById("kongor_puani").value) || 0;
    const soforPuan = (document.getElementById("arac_kullanim").value === "Evet" ? 500 : 0);
    const toplamAylikPuan = konPuan + soforPuan;

    const postBody = {
        action: 'kaydet', yil: yil, ay: ay,
        gunler: Array.from({length:31}, (_,i) => document.getElementById("sec_"+(i+1))?.value || ""),
        mahalleler: Array.from({length:31}, (_,i) => document.querySelector(`#mah_liste_${i+1} input:checked`)?.value || ""),
        toplam_kon_gor_puani: konPuan,
        toplam_kon_gor_gunu: document.getElementById("kontrol_gorev_gunu").value,
        toplam_arazi_gorev: document.getElementById("arazi_toplam").value,
        toplam_seyyar_gorev: document.getElementById("seyyar_toplam").value,
        toplam_sofor_puani: soforPuan,
        toplam_aylik_puan: toplamAylikPuan
    };
    fetch("../ajax/ajax_puantaj_islem.php", {method:"POST", body:JSON.stringify(postBody)})
    .then(r => r.json()).then(res => { 
        alert(res.message); 
        if(res.status==="success") {
            window.location.href = `puantaj.php?yil=${yil}&ay=${ay}`;
        }
    });
}

document.getElementById("silBtn").addEventListener("click", function() {
    const yil = document.getElementById("yilSec").value;
    const ay = document.getElementById("aySec").value;
    if(!confirm(`${yil} / ${ay} dönemine ait puantajınız silinecektir. Emin misiniz?`)) return;
    fetch("../ajax/ajax_puantaj_islem.php", {
        method: "POST",
        body: JSON.stringify({ yil, ay, action: 'sil' })
    })
    .then(r => r.json())
    .then(res => {
        alert(res.message);
        if(res.status === "success") {
            window.location.href = `puantaj.php?yil=${yil}&ay=${ay}`;
        }
    });
});

document.getElementById("bulBtn").addEventListener("click", () => {
    const yil = document.getElementById("yilSec").value, ay = document.getElementById("aySec").value;
    fetch("../ajax/ajax_puantaj_islem.php", {method:"POST", body:JSON.stringify({yil, ay, action:'bul'})}).then(r=>r.json()).then(res=>{
        if(res.status === "success" && res.data){
            const dbM = res.data.mahalleler || {}, dbK = res.data.gunler || {};
            for (let g = 1; g <= 31; g++) {
                const mahDiv = document.getElementById("mah_liste_"+g), sel = document.getElementById("sec_"+g);
                if(!sel) continue;
                if(dbM[g]) {
                    const tur = MAHALLE_SOZLUK[dbM[g]];
                    const isEligible = (tur === 'A' || tur === 'AS');
                    mahDiv.innerHTML = `<div class="mahalle-item ${!isEligible ? 'disabled' : ''}">
                                        <input class="form-check-input" type="checkbox" value="${dbM[g]}" 
                                        ${isEligible ? 'checked' : 'disabled'} onchange="mahalleTiklandi(this, ${g})">
                                        <label class="form-check-label ${!isEligible ? 'text-muted' : ''}">${dbM[g]}</label>
                                        </div>`;
                }
                let k = dbK[g] || "";
                if(k.length > 2) k = TERS_SOZLUK[k] || k;
                mahalleTiklandi(document.querySelector(`#mah_liste_${g} input:checked`), g);
                sel.value = k;
            }
            guncelleEkVeriler(); alert("✅ Veriler yüklendi.");
        } else alert("Kayıt bulunamadı.");
    });
});

function guncelleEkVeriler(){
    let tg=0, kp=0, st=0, at=0, kg_gun=0;
    document.querySelectorAll('.puan-select').forEach(s => {
        const v = s.value; if(v && !["IZ","RT"].includes(v)){
            tg++; if(["KG","KS","AK","AKS"].includes(v)) { kp += 200; kg_gun++; }
            if(["AT","AK","AKS"].includes(v)) at++; if(["KS","AKS","SG"].includes(v)) st++;
        }
    });

    const sPuan = (document.getElementById("arac_kullanim").value === "Evet" ? 500 : 0);
    
    document.getElementById("toplam_gun").value = tg; 
    document.getElementById("kongor_puani").value = kp;
    document.getElementById("arazi_toplam").value = at; 
    document.getElementById("seyyar_toplam").value = st;
    document.getElementById("kontrol_gorev_gunu").value = kg_gun;
    document.getElementById("sofor_puani_ekran").value = sPuan;
    document.getElementById("aylik_toplam_puan_ekran").value = kp + sPuan;
    
    const aktifAy = document.getElementById("aySec").value;
    const statBadge = document.getElementById("stat_month_" + aktifAy);
    if(statBadge) {
        const aylar_kisa = ["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"];
        statBadge.innerHTML = aylar_kisa[aktifAy-1] + "<br>" + (kg_gun > 0 ? kg_gun : "-");
        statBadge.className = "badge badge-month " + (kg_gun > 0 ? "bg-primary" : "bg-light text-muted border");
    }
}

function loadTabContent(t) {
    const y = document.getElementById("yilSec").value, a = document.getElementById("aySec").value;
    const d = "#" + t + "-tab-pane", f = t === 'kontrol' ? 'kontrol_gorevi' : t;
    $(d).html('<div class="text-center p-5"><i class="fas fa-sync fa-spin fa-2x"></i></div>');
    $.get(`../ajax/tab_${f}.php`, { yil: y, ay: a }, function(data) { $(d).html(data); });
}
</script>