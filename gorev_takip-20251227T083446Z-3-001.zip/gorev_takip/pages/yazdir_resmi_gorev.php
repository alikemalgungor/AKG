<?php
// pages/yazdir_resmi_gorev.php
session_start();
if (!isset($_SESSION['user_id'])) {
    die("Yetkisiz giriş.");
}

include_once '../config/db.php';
include_once '../includes/functions.php';

if (!isset($_GET['id'])) {
    die("Görev ID belirtilmedi.");
}

$gorev_id = (int)$_GET['id'];

// --- 1. KURUM AYARLARINI ÇEK (GÜNCELLENEN KISIM) ---
$kurum_adi = "KURUM TANIMSIZ"; // Varsayılan güvenlik değeri
try {
    $stmt_kurum = $pdo->query("SELECT * FROM kurum_ayarlari LIMIT 1");
    $k = $stmt_kurum->fetch(PDO::FETCH_ASSOC);

    if ($k) {
        // Bakanlık adı ve (varsa ilçe, yoksa il) müdürlüğü adını alıp birleştiriyoruz.
        // Aralarına "\n" (yeni satır) koyuyoruz ki fonksiyonda nl2br ile alt alta yazdırabilelim.
        $bakanlik = $k['bakanlik_adi'];
        
        // Eğer ilçe müdürlüğü adı doluysa onu, boşsa il müdürlüğü adını kullan
        $mudurluk = !empty($k['ilce_mudurlugu_adi']) ? $k['ilce_mudurlugu_adi'] : $k['il_mudurlugu_adi'];
        
        $kurum_adi = $bakanlik . "\n" . $mudurluk;
    }
} catch (PDOException $e) {
    $kurum_adi = "VERİTABANI HATASI";
}

// --- 2. Görev Verilerini Çek ---
try {
    $sql = "
        SELECT 
            ag.*,
            a.plaka, a.marka_model,
            gt.ad as gorev_turu,
            s.ad_soyad as sofor_ad,
            s.unvan as sofor_unvan,
            ba.ad_soyad as birim_amiri_ad, 
            ba.unvan as birim_amiri_unvan,
            ka.ad_soyad as kurum_amiri_ad,
            ka.unvan as kurum_amiri_unvan,
            
            (SELECT GROUP_CONCAT(CONCAT(p.ad_soyad, '###', IFNULL(p.unvan, '')) SEPARATOR '|||') 
             FROM arac_gorev_personel agp 
             JOIN personel_bilgileri p ON agp.personel_id = p.id 
             WHERE agp.gorev_id = ag.id AND agp.rol = 'Personel') as personeller_raw,
            
            (SELECT GROUP_CONCAT(m.ad SEPARATOR ', ') 
             FROM arac_gorev_mahalle agm 
             JOIN mahalleler m ON agm.mahalleler_id = m.id 
             WHERE agm.gorev_id = ag.id) as mahalleler
            
        FROM arac_gorevler ag
        LEFT JOIN araclar a ON ag.arac_id = a.id
        LEFT JOIN gorev_turleri gt ON ag.gorev_turu_id = gt.id
        LEFT JOIN personel_bilgileri s ON ag.sofor_id = s.id 
        LEFT JOIN personel_bilgileri ba ON ag.birim_amiri_id = ba.id
        LEFT JOIN personel_bilgileri ka ON ag.kurum_amiri_id = ka.id
        WHERE ag.id = ?
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$gorev_id]);
    $g = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$g) { die("Görev bulunamadı."); }

} catch (PDOException $e) {
    die("Hata: " . $e->getMessage());
}

// Tarih Formatları
$tarih_tr = date("d.m.Y", strtotime($g['tarih']));
$cikis_saati = date("H:i", strtotime($g['baslangic_saati']));
$donus_saati = $g['bitis_saati'] ? date("H:i", strtotime($g['bitis_saati'])) : '';
$cikis_tarihi = date("d.m.Y", strtotime($g['tarih']));
$donus_tarihi_sadece_gun = ($g['donus_tarihi'] && $g['donus_tarihi'] != '0000-00-00 00:00:00') ? date("d.m.Y", strtotime($g['donus_tarihi'])) : '';

// Personel Listesini İşle
$adlar = [];
$unvanlar = [];
$adlar[] = $g['sofor_ad'];
$unvanlar[] = $g['sofor_unvan'] ?? 'Şoför';

if (!empty($g['personeller_raw'])) {
    $list = explode('|||', $g['personeller_raw']);
    foreach($list as $item) {
        $parts = explode('###', $item);
        $adlar[] = $parts[0];
        $unvanlar[] = isset($parts[1]) ? $parts[1] : '';
    }
}
$personel_adlari = implode('<br>', $adlar);
$personel_unvanlari = implode('<br>', $unvanlar);


// --- ŞABLON FONKSİYONU ---
function gorevFormuCiz($g, $tarih_tr, $cikis_saati, $donus_saati, $cikis_tarihi, $donus_tarihi_sadece_gun, $personel_adlari, $personel_unvanlari, $kurum_adi) {
?>
    <div class="form-wrapper">
        <div class="header">
            <strong><?php echo nl2br(htmlspecialchars($kurum_adi)); ?></strong><br>
            <span style="text-decoration: underline;">TAŞIT GÖREV EMRİ</span>
        </div>

        <table class="main-table">
            <tr>
                <th colspan="3">GÖREVLENDİREN BİRİM AMİRİNİN</th>
                <th colspan="2">Tarih</th>
                <td><?php echo $tarih_tr; ?></td>
            </tr>
            <tr>
                <td class="lbl">Adı ve Soyadı</td>
                <td class="lbl">Ünvanı</td>
                <td class="lbl">İmzası</td>
                <td class="lbl" colspan="2">Sıra No</td>
                <td><?php echo $g['id']; ?></td>
            </tr>
            <tr>
                <td style="height: 30px;"><?php echo htmlspecialchars($g['birim_amiri_ad']); ?></td>
                <td><?php echo htmlspecialchars($g['birim_amiri_unvan'] ?? ''); ?></td>
                <td></td>
                <td class="lbl" colspan="2">Görev No</td>
                <td><strong><?php echo $g['gorev_no']; ?></strong></td>
            </tr>

            <tr>
                <th colspan="2">GÖREVLİ PERSONELİN</th>
                <th colspan="4">A R A C I N</th>
            </tr>
            <tr>
                <td class="lbl">Adı ve Soyadı</td>
                <td class="lbl">Ünvanı</td>
                <td class="lbl" colspan="2">Sürücüsünün<br>Adı ve Soyadı</td>
                <td colspan="2"><?php echo htmlspecialchars($g['sofor_ad']); ?></td>
            </tr>
            <tr>
                <td rowspan="3" style="vertical-align: top; text-align: left; padding: 4px;"><?php echo $personel_adlari; ?></td>
                <td rowspan="3" style="vertical-align: top; text-align: center; padding: 4px;"><?php echo $personel_unvanlari; ?></td>
                <td class="lbl" colspan="2">İmzası</td>
                <td colspan="2" style="height: 30px;"></td>
            </tr>
            <tr>
                <td class="lbl" colspan="2">Plaka No</td>
                <td colspan="2" style="font-weight: bold;"><?php echo htmlspecialchars($g['plaka']); ?></td>
            </tr>
            <tr>
                <td class="lbl" colspan="2">Ait Olduğu Kuruluş</td>
                <td colspan="2" style="font-size: 7pt; font-weight: bold; white-space: normal; line-height: 1.1; vertical-align: middle;">
                    <?php echo nl2br(htmlspecialchars($kurum_adi)); ?>
                </td>
            </tr>

            <tr>
                <td class="lbl">Görevin Türü</td>
                <td style="text-align: left;"><?php echo htmlspecialchars($g['gorev_turu']); ?></td>
                <td></td> 
                
                <td class="lbl">Çıkış Tarihi</td>
                <td class="lbl">Çıkış Km.si</td>
                <td class="lbl">Dönüş Km.si</td>
            </tr>
            <tr>
                <td class="lbl">Gidilecek Yer</td>
                <td colspan="2" style="text-align: left;"><?php echo htmlspecialchars($g['mahalleler']); ?></td>
                
                <td><?php echo $cikis_tarihi; ?></td>
                <td style="font-weight: bold; font-size: 11pt;"><?php echo $g['cikis_km']; ?></td>
                <td style="font-weight: bold; font-size: 11pt;"><?php echo $g['donus_km']; ?></td>
            </tr>

            <tr>
                <th colspan="3">ONAYLAYAN AMİRİN</th>
                <td class="lbl">Dönüş Tarihi</td>
                <td colspan="2"></td>
            </tr>
            
            <tr>
                <td class="lbl">Adı Soyadı</td>
                <td class="lbl">Ünvanı</td>
                <td class="lbl">İmzası</td>
                <td><?php echo $donus_tarihi_sadece_gun; ?></td>
                <td colspan="2"></td>
            </tr>

            <tr>
                <td rowspan="2" style="vertical-align: middle; height: 40px;"><?php echo htmlspecialchars($g['kurum_amiri_ad']); ?></td>
                <td rowspan="2" style="vertical-align: middle;"><?php echo htmlspecialchars($g['kurum_amiri_unvan'] ?? ''); ?></td>
                <td rowspan="2"></td>
                <td class="lbl">Alınan Yakıt</td>
                <td class="lbl">Çıkış Saati</td>
                <td class="lbl">Dönüş Saati</td>
            </tr>

            <tr>
                <td><?php echo $g['yakit_alinan'] > 0 ? $g['yakit_alinan'].' Lt' : ''; ?></td>
                <td><?php echo $cikis_saati; ?></td>
                <td><?php echo $donus_saati; ?></td>
            </tr>
            
            <tr>
                <td colspan="6" style="text-align: left; font-size: 8pt; vertical-align: top; padding: 5px; border-top: 2px solid #000;">
                    1. Taşıt Görev emri her görevlendirmede iki nüsha doldurulacak bir nüshası ilgili kurumda kalacak, ikinci nüshası araçta bulundurulacaktır.<br>
                    2. Taşıt Görev emri yetkililerin istemesi halinde gösterilecektir.<br>
                    <strong>NOT:</strong> Araç sürücüleri ve araçta bulunan görevliler resmi sıfatın gerektirdiği kılık kıyafet ve uygun davranışlarda bulunacak, araç içinde sigara içmeyecektir.
                </td>
            </tr>
        </table>
    </div>
<?php } ?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Taşıt Görev Emri</title>
    <style>
        /* CSS RESET */
        * { box-sizing: border-box; }
        body { 
            margin: 0; padding: 0; 
            background-color: #555; 
            font-family: "Times New Roman", Times, serif; 
        }

        .page {
            width: 210mm;
            height: 297mm;
            background: white;
            margin: 20px auto;
            padding: 10mm;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
            position: relative;
        }

        .form-wrapper {
            width: 100%;
            height: 48%; 
            border-bottom: 2px dashed #000;
            margin-bottom: 15px;
            padding-bottom: 15px;
        }
        .form-wrapper:last-child { border-bottom: none; margin-bottom: 0; }

        .header { text-align: center; margin-bottom: 5px; font-size: 11pt; }
        
        .main-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9pt;
            table-layout: fixed; 
        }

        /* GÜNCELLENMİŞ SÜTUN GENİŞLİKLERİ */
        .main-table col:nth-child(1) { width: 29%; }
        .main-table col:nth-child(2) { width: 29%; }
        .main-table col:nth-child(3) { width: 9%; }
        .main-table col:nth-child(4) { width: 13%; }
        .main-table col:nth-child(5) { width: 10%; }
        .main-table col:nth-child(6) { width: 14%; }

        .main-table th {
            background-color: #fff; 
            border: 1px solid #000;
            padding: 2px;
            font-weight: bold;
            font-size: 9pt;
            text-align: center;
        }
        .main-table td {
            border: 1px solid #000;
            padding: 2px;
            text-align: center;
            vertical-align: middle;
            overflow: hidden;
            white-space: nowrap; 
        }
        .main-table td[style*="text-align: left"] { white-space: normal; }
        .lbl { font-weight: bold; }

        @media print {
            body { background: white; }
            .page { margin: 0; padding: 5mm; box-shadow: none; width: 100%; height: 100%; }
            .no-print { display: none !important; }
            @page { size: A4 portrait; margin: 0; }
        }
        .no-print { position: fixed; top: 10px; right: 10px; background: #fff; padding: 10px; border: 1px solid #000; z-index: 999; }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" style="cursor: pointer; padding: 5px 10px; font-weight: bold;">🖨️ YAZDIR</button>
        <button onclick="window.close()" style="cursor: pointer; padding: 5px 10px; font-weight: bold;">KAPAT</button>
    </div>

    <div class="page">
        <colgroup>
            <col style="width: 23%;">
            <col style="width: 23%;">
            <col style="width: 11%;">
            <col style="width: 15%;">
            <col style="width: 12%;">
            <col style="width: 16%;">
        </colgroup>
        
        <?php gorevFormuCiz($g, $tarih_tr, $cikis_saati, $donus_saati, $cikis_tarihi, $donus_tarihi_sadece_gun, $personel_adlari, $personel_unvanlari, $kurum_adi); ?>
        
        <div style="height: 10mm;"></div>

        <colgroup>
            <col style="width: 23%;">
            <col style="width: 23%;">
            <col style="width: 11%;">
            <col style="width: 15%;">
            <col style="width: 12%;">
            <col style="width: 16%;">
        </colgroup>
        <?php gorevFormuCiz($g, $tarih_tr, $cikis_saati, $donus_saati, $cikis_tarihi, $donus_tarihi_sadece_gun, $personel_adlari, $personel_unvanlari, $kurum_adi); ?>
    </div>
</body>
</html>