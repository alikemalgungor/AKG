<?php
// pages/yazdir_kontrol.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { die("Oturum açmalısınız."); }

$user_id = $_SESSION['user_id'];
$yil = $_GET['yil'] ?? date('Y');
$ay  = $_GET['ay'] ?? date('m');

// --- FONKSİYONLAR ---
function tr_yazim_duzeni($metin) {
    if (empty($metin)) return "";
    $buyuk = ['I', 'İ', 'Ğ', 'Ü', 'Ş', 'Ö', 'Ç'];
    $kucuk = ['ı', 'i', 'ğ', 'ü', 'ş', 'ö', 'ç'];
    $metin = str_replace($buyuk, $kucuk, $metin);
    $metin = mb_strtolower($metin, 'UTF-8');
    return mb_convert_case($metin, MB_CASE_TITLE, "UTF-8");
}

// 1. VERİLERİ ÇEKME
$stmt_pers = $pdo->prepare("SELECT * FROM personel_bilgileri WHERE id = ?");
$stmt_pers->execute([$user_id]);
$personel = $stmt_pers->fetch(PDO::FETCH_ASSOC);

$stmt_puan = $pdo->prepare("SELECT * FROM puantaj_aylik WHERE personel_id = ? AND yil = ? AND ay = ?");
$stmt_puan->execute([$user_id, $yil, $ay]);
$puantaj = $stmt_puan->fetch(PDO::FETCH_ASSOC);

$dijital_onayli_mi = ($puantaj['onay_durumu'] ?? 0) == 1;

$sql_detay = "SELECT k.*, g.ad as gorev_adi, y.icerik as yasal_icerik 
              FROM kontrol_gorevi_detay k
              LEFT JOIN gorev_turleri g ON k.gorev_turu_id = g.id
              LEFT JOIN tanim_kontrol_yasal_dayanak y ON k.yasal_dayanak_id = y.id
              WHERE k.personel_id = ? AND k.yil = ? AND k.ay = ?
              ORDER BY k.gun ASC";
$stmt_detay = $pdo->prepare($sql_detay);
$stmt_detay->execute([$user_id, $yil, $ay]);
$detaylar = $stmt_detay->fetchAll(PDO::FETCH_ASSOC);

$aylar = ["", "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK"];
$ay_yazi = $aylar[(int)$ay];

// 2. MÜDÜR BİLGİSİ
$sql_yonetici = "SELECT p.ad_soyad FROM yonetici_listesi y 
                 JOIN personel_bilgileri p ON y.personel_id = p.id 
                 WHERE y.aktif = 1 ORDER BY y.varsayilan DESC LIMIT 1";
$amir = $pdo->query($sql_yonetici)->fetch(PDO::FETCH_ASSOC);

$varsayilan_mudur_adi = $amir ? tr_yazim_duzeni($amir['ad_soyad']) : "Hamit ÇAKAL"; 
$varsayilan_unvan = "İlçe Müdürü";
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Puantaj Raporu</title>
    <style>
        /* GENEL SAYFA AYARLARI */
        body { 
            font-family: "Times New Roman", serif; 
            font-size: 10pt; 
            background: #555; 
            margin: 0; 
            padding: 20px; 
            padding-top: 50px; 
            display: flex; 
            justify-content: center; 
        }
        
        /* KAĞIT GÖRÜNÜMÜ */
        .page { 
            width: 210mm; 
            min-height: 297mm; 
            background: white; 
            padding: 10mm; 
            box-shadow: 0 0 15px rgba(0,0,0,0.5); 
            box-sizing: border-box; 
            position: relative; 
        }
        
        /* TABLO AYARLARI (GÜNCELLENDİ) */
        table { width: 100%; border-collapse: collapse; margin-bottom: 2px; }
        th, td { border: 1px solid black; padding: 2px; vertical-align: middle; line-height: 1.1; }
        
        /* SATIR YÜKSEKLİĞİNİ SABİTLEME (Sorunu Çözen Kısım) */
        tbody tr { 
            height: 32px; /* Tüm satırlar eşit ve tok durur */
        }
        
        /* RENKLER */
        .bg-yellow { background-color: #ffff00 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .bg-pink { background-color: #fce4d6 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }   
        
        /* YAZI HİZALAMALARI */
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        .kucuk-yazi { font-size: 9pt; }
        
        /* İMZA ALANI */
        .imza-table, .imza-table td { border: none; text-align: center; height: auto; } /* İmza satır yüksekliği serbest kalsın */
        .dijital-muhur { font-size: 7pt; color: #555; font-style: italic; border: 1px dashed #ccc; padding: 2px; display: inline-block; }

        /* DEĞİŞTİRİLEBİLİR ALAN */
        .editable-field { padding: 2px 5px; border-radius: 3px; transition: background 0.3s; }
        .editable-field:hover { background-color: #fff3cd; cursor: text; outline: 1px dashed #999; }

        /* BUTONLAR */
        .no-print { position: fixed; top: 20px; right: 20px; z-index: 9999; display: flex; gap: 10px; align-items: center; background: rgba(0,0,0,0.8); padding: 10px 15px; border-radius: 8px; color: white; }
        .btn { padding: 8px 15px; cursor: pointer; font-weight: bold; border: none; border-radius: 4px; color:white; }
        .btn-print { background: #198754; }
        .btn-close { background: #dc3545; }

        /* YAZDIRMA AYARLARI */
        @media print {
            @page { margin: 10mm; size: A4 portrait; }
            body { background: white; margin: 0; padding: 0; display: block; }
            .page { width: 100%; height: auto; margin: 0; padding: 0; box-shadow: none; border: none; }
            .no-print { display: none; }
            .editable-field:hover { background-color: transparent; outline: none; }
            
            /* Tablonun bölünmesini önle */
            tr { page-break-inside: avoid; }
        }
    </style>
</head>
<body>

    <div class="no-print">
        <span style="font-size: 11px; color: #ccc; margin-right:10px;">İsimleri değiştirmek için üzerine tıklayın ➜</span>
        <button class="btn btn-print" onclick="window.print()">YAZDIR</button>
        <button class="btn btn-close" onclick="window.close()">KAPAT</button>
    </div>

    <div class="page">
        <table style="border:none;">
            <tr style="border:none;"><td colspan="3" class="text-center font-bold" style="border:none; font-size:12pt; padding-bottom:5px;">EK.1 KONTROL HİZMETİNDE İLAVE ÖDEME PUANTAJ TABLOSU</td></tr>
            <tr style="border:none;">
                <td style="border:none;"><b>Ait Olduğu Yıl:</b> <?php echo $yil; ?></td>
                <td style="border:none;"></td>
                <td style="border:none; text-align:right;"><b>Ay:</b> <?php echo $ay_yazi; ?></td>
            </tr>
        </table>

        <table>
            <thead>
                <tr class="bg-yellow">
                    <th width="5%">Sıra</th>
                    <th width="12%">Tarih</th>
                    <th width="20%">Kontrol Türü</th>
                    <th width="15%">Yasal Dayanak</th>
                    <th>Açıklama</th>
                    <th width="12%">Saat</th>
                </tr>
            </thead>
            <tbody>
                <?php $sira = 1; foreach ($detaylar as $row): ?>
                <tr>
                    <td class="text-center"><?php echo $sira++; ?></td>
                    <td class="text-center"><?php echo date("d.m.Y", strtotime("$yil-$ay-" . $row['gun'])); ?></td>
                    <td><?php echo tr_yazim_duzeni($row['gorev_adi']); ?></td>
                    <td class="text-center kucuk-yazi"><?php echo tr_yazim_duzeni($row['yasal_icerik']); ?></td>
                    <td class="kucuk-yazi"><?php echo tr_yazim_duzeni($row['aciklama']); ?></td>
                    <td class="text-center"><?php echo substr($row['baslangic_saati'], 0, 5) . "-" . substr($row['bitis_saati'], 0, 5); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <?php if (!empty($puantaj['toplam_sofor_puani']) && $puantaj['toplam_sofor_puani'] > 0): ?>
                <tr class="bg-pink" style="height: auto;">
                    <td colspan="6" class="font-bold" style="padding: 4px; font-size: 9pt;">
                        *Görevimi Araç Kullanarak Yerine Getirdiğim için 500 Gösterge Puanı Eklenmesi Talep Ediyorum
                    </td>
                </tr>
                <?php endif; ?>
                
                <tr class="bg-pink" style="height: auto;">
                    <td colspan="5" class="font-bold" style="text-align:right; padding-right:15px;">
                        *Yukarıda Yapılan Çalışmalar Kapsamında Hesaplanan Toplam Gösterge Puanı
                    </td>
                    <td class="text-center font-bold"><?php echo $puantaj['toplam_aylik_puan'] ?? 0; ?></td>
                </tr>
            </tfoot>
        </table>

        <br>
        <table class="imza-table">
            <tr>
                <td width="50%"></td> 
                <td width="50%">
                    <b><?php echo tr_yazim_duzeni($personel['ad_soyad']); ?></b><br>
                    <?php echo tr_yazim_duzeni($personel['unvan']); ?><br>
                    <?php if($dijital_onayli_mi): ?>
                        <div class="dijital-muhur">Sistem Üzerinden Şifre ile Onaylanmıştır.<br>Tarih: <?php echo date('d.m.Y H:i', strtotime($puantaj['onay_tarihi'])); ?></div>
                    <?php else: ?>
                        İmza
                    <?php endif; ?>
                </td>
            </tr>
            
            <tr><td colspan="2" style="height: 40px;"></td></tr>

            <tr>
                <td colspan="2">
                    <b class="editable-field" contenteditable="true"><?php echo $varsayilan_mudur_adi; ?></b><br>
                    <span class="editable-field" contenteditable="true"><?php echo $varsayilan_unvan; ?></span><br>
                    İmza
                </td>
            </tr>
            
            <tr>
                <td colspan="2" style="text-align: right; font-size: 9pt; padding-top: 20px;">
                    Rapor Tarihi: <?php echo date('d/m/Y'); ?>
                </td>
            </tr>
        </table>
    </div>

</body>
</html>