<?php
// pages/yazdir_ozel_gorev.php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) { die("Yetkisiz erişim."); }

include_once '../config/db.php';

$id = (int)$_GET['id'];

// --- VERİLERİ ÇEK ---
$sql = "SELECT o.*, 
               p.ad_soyad, p.unvan,
               gt.ad as gorev_turu,
               ka.ad_soyad as kurum_amiri_ad, ka.unvan as kurum_amiri_unvan,
               m.ad as mahalle_ad
        FROM ozel_arac_gorevler o
        JOIN personel_bilgileri p ON o.gorevli_personel_id = p.id
        LEFT JOIN personel_bilgileri ka ON o.kurum_amiri_id = ka.id
        JOIN gorev_turleri gt ON o.gorev_turu_id = gt.id
        JOIN mahalleler m ON o.mahalle_id = m.id
        WHERE o.id = ?";
$g = $pdo->prepare($sql);
$g->execute([$id]);
$kayit = $g->fetch(PDO::FETCH_ASSOC);

if (!$kayit) die("Kayıt bulunamadı.");

// Formatlar
$tarih_tr = ($kayit['gorev_tarihi'] && $kayit['gorev_tarihi'] != '0000-00-00') ? date("d/m/Y", strtotime($kayit['gorev_tarihi'])) : '00/00/0000';
$cikis_saat = substr($kayit['cikis_saat'], 0, 5);
$donus_saat = ($kayit['donus_saat'] && $kayit['donus_saat'] != '00:00:00') ? substr($kayit['donus_saat'], 0, 5) : '';
$tarih_tr = ($kayit['gorev_tarihi'] && $kayit['gorev_tarihi'] != '0000-00-00') ? date("d/m/Y", strtotime($kayit['gorev_tarihi'])) : '';
$cikis_saat = substr($kayit['cikis_saat'], 0, 5);
$donus_saat = ($kayit['donus_saat'] && $kayit['donus_saat'] != '00:00:00') ? substr($kayit['donus_saat'], 0, 5) : '';
$donus_tarihi = ($kayit['donus_tarihi'] && $kayit['donus_tarihi'] != '0000-00-00') ? date("d/m/Y", strtotime($kayit['donus_tarihi'])) : '';
$gorev_no = !empty($kayit['gorev_no']) ? $kayit['gorev_no'] : 0;
$gorev_no = !empty($kayit['gorev_no']) ? $kayit['gorev_no'] : 0;
$baslik = "ÇİVRİL İLÇE TARIM ve ORMAN MÜDÜRLÜĞÜ";

// --- FORM ÇİZME FONKSİYONU ---
function formCiz($d, $baslik, $tarih, $c_saat, $d_saat, $d_tarih, $g_no, $db_id) {
?>
    <div class="form-wrapper">
        <div class="main-header"><?php echo $baslik; ?></div>
        
        <table class="gorev-tablosu">
            <colgroup>
                <col style="width: 20%;">
                <col style="width: 20%;">
                <col style="width: 20%;">
                <col style="width: 15%;">
                <col style="width: 25%;">
            </colgroup>

            <tr>
                <td colspan="3" class="header-cell">ARAÇ SAHİBİNİN</td>
                <td class="bold-label">Tarih</td>
                <td class="center-data bold-data"><?php echo $tarih; ?></td>
            </tr>
            <tr>
                <td class="bold-label">Adı ve Soyadı</td>
                <td class="bold-label">Mahallesi</td>
                <td class="bold-label">İmzası</td>
                <td class="bold-label">Sıra No</td>
                <td class="center-data"><?php echo $db_id; ?></td>
            </tr>
            <tr>
                <td class="center-data" style="height: 30px;"><?php echo !empty($d['arac_sahibi']) ? $d['arac_sahibi'] : '0'; ?></td>
                <td class="center-data"><?php echo !empty($d['mahalle_ad']) ? $d['mahalle_ad'] : '0'; ?></td>
                <td></td> 
                <td class="bold-label">Görev No</td>
                <td class="center-data"><?php echo $g_no; ?></td>
            </tr>

            <tr>
                <td colspan="3" class="header-cell" style="text-align: left; padding-left: 5px;">GÖREVLİ PERSONELİN</td>
                <td colspan="2" style="border-bottom: none;"></td>
            </tr>
            <tr>
                <td class="bold-label">Adı ve Soyadı</td>
                <td colspan="2" class="center-data" style="text-align: left; padding-left: 5px;"><?php echo !empty($d['ad_soyad']) ? $d['ad_soyad'] : '0'; ?></td>
                <td colspan="2" class="header-cell">TAŞITIN</td>
            </tr>
            <tr>
                <td class="bold-label">Ünvanı</td>
                <td colspan="2" class="center-data" style="text-align: left; padding-left: 5px;"><?php echo !empty($d['unvan']) ? $d['unvan'] : ''; ?></td>
                <td class="bold-label" style="text-align: left; padding-left: 5px;">Plakası</td>
                <td class="center-data bold-data"><?php echo !empty($d['arac_plaka']) ? $d['arac_plaka'] : '0'; ?></td>
            </tr>
            <tr>
                <td class="bold-label">Görevin Türü</td>
                <td colspan="2" class="center-data" style="text-align: left; padding-left: 5px;"><?php echo !empty($d['gorev_turu']) ? $d['gorev_turu'] : '0'; ?></td>
                <td class="bold-label" style="text-align: left; padding-left: 5px;">Kime Ait Olduğu</td>
                <td class="center-data"><?php echo !empty($d['arac_sahibi']) ? $d['arac_sahibi'] : '0'; ?></td>
            </tr>
             <tr>
                <td class="bold-label">İmzası</td>
                <td colspan="2"></td>
                <td colspan="2" style="border-top: 1px solid #000; border-bottom: 1px solid #000;"></td>
            </tr>
            <tr>
                <td class="bold-label">Gideceği Yer</td>
                <td colspan="4" class="center-data bold-data" style="text-align: left; padding-left: 5px;"><?php echo !empty($d['mahalle_ad']) ? $d['mahalle_ad'] : '0'; ?></td>
            </tr>

            <tr>
                <td colspan="3" class="header-cell">ONAYLAYAN KURUM AMİRİNİN</td>
                <td colspan="2" class="header-cell">GÖREVE</td>
            </tr>
            <tr>
                <td class="bold-label">Adı ve Soyadı</td>
                <td class="bold-label">Ünvanı</td>
                <td class="bold-label">İmzası</td>
                <td class="bold-label">Çıkış Tarihi</td>
                <td class="center-data"><?php echo $tarih; ?></td>
            </tr>
            <tr>
                <td rowspan="3" class="center-data" style="vertical-align: bottom;"><?php echo !empty($d['kurum_amiri_ad']) ? $d['kurum_amiri_ad'] : '0'; ?></td>
                <td rowspan="3" class="center-data" style="vertical-align: bottom;"><?php echo !empty($d['kurum_amiri_unvan']) ? $d['kurum_amiri_unvan'] : '0'; ?></td>
                <td rowspan="3"></td>
                <td class="bold-label">Çıkış Saati</td>
                <td class="center-data"><?php echo $c_saat; ?></td>
            </tr>
            <tr>
                <td class="bold-label">Dönüş Tarihi</td>
                <td class="center-data"><?php echo $d_tarih; ?></td>
            </tr>
            <tr>
                <td class="bold-label">Dönüş Saati</td>
                <td class="center-data"><?php echo !empty($d_saat) ? $d_saat : '&nbsp;'; ?></td>
            </tr>
        </table>
        
        <div class="footer-note">
            1- Görev dönüşü dönüş saat bilgisi ve tarihi yazılarak onay için birim amirine teslim edilecektir.<br>
            2- Bir nüshası görevli personel tarafından muhafaza edilecektir.
        </div>
    </div>
<?php } ?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Görev Formu</title>
    <style>
        body { margin: 0; padding: 0; background: #555; font-family: "Times New Roman", Times, serif; }
        .page {
            width: 210mm; height: 297mm; background: white; margin: 10mm auto; padding: 10mm;
            box-sizing: border-box; box-shadow: 0 0 5px rgba(0,0,0,0.3);
        }
        .form-wrapper { margin-bottom: 50px; border-bottom: 1px dashed #ccc; padding-bottom: 10px; }
        .form-wrapper:last-child { border-bottom: none; margin-bottom: 0; }
        
        .main-header {
            text-align: center; font-weight: bold; font-size: 14pt; margin-bottom: 5px; text-transform: uppercase;
        }
        
        .gorev-tablosu {
            width: 100%; border-collapse: collapse; font-size: 10pt; table-layout: fixed;
            border: 2px solid #000;
        }
        .gorev-tablosu td {
            border: 1px solid #000; padding: 2px; vertical-align: middle;
        }
        
        .header-cell { font-weight: bold; text-align: center; background-color: #fff; }
        .bold-label { font-weight: bold; text-align: center; background-color: #fff; }
        .center-data { text-align: center; }
        .bold-data { font-weight: bold; }
        
        /* Notlar Kısmının Stili - Tablonun DIŞINDA */
        .footer-note {
            font-size: 9pt; 
            font-style: italic; 
            font-weight: bold; 
            text-align: left; 
            margin-top: 2px; /* Tablo ile arasında az boşluk */
        }

        @media print {
            body { background: white; margin: 0; }
            .page { width: 100%; margin: 0; padding: 5mm; box-shadow: none; height: auto; }
            .btn-group { display: none; }
        }
        .btn-group { position: fixed; top: 10px; right: 10px; }
        .btn { padding: 8px 15px; margin-left: 5px; cursor: pointer; border: 1px solid #333; color: white; border-radius: 4px; }
        .btn-print { background: #28a745; }
        .btn-close { background: #dc3545; }
    </style>
</head>
<body>
    <div class="btn-group">
        <button class="btn btn-print" onclick="window.print()">YAZDIR</button>
        <button class="btn btn-close" onclick="window.close()">KAPAT</button>
    </div>

    <div class="page">
        <?php 
            formCiz($kayit, $baslik, $tarih_tr, $cikis_saat, $donus_saat, $donus_tarihi, $gorev_no, $id); 
        ?>
        <br>
        <?php 
            formCiz($kayit, $baslik, $tarih_tr, $cikis_saat, $donus_saat, $donus_tarihi, $gorev_no, $id); 
        ?>
    </div>
</body>
</html>
