<?php
// pages/izin_takip.php
include_once '../includes/header.php';
include_once '../config/db.php'; 
include_once '../includes/functions.php'; // 1. Fonksiyon dosyasını buraya ekledik

$user_id = $_SESSION['user_id'];
$rol_id  = isset($_SESSION['rol_id']) ? $_SESSION['rol_id'] : 0;
$yonetici_mi = in_array($rol_id, [1, 2]);

// Verileri Çek
$sebepler = $pdo->query("SELECT * FROM izin_sebepleri ORDER BY sebep_adi")->fetchAll(PDO::FETCH_ASSOC);
$aciklamalar = $pdo->query("SELECT * FROM izin_aciklamalari ORDER BY aciklama_adi")->fetchAll(PDO::FETCH_ASSOC);

// Personelleri Çek (Fonksiyon Kullanımı)
$personeller = [];
if ($yonetici_mi) {
    // ESKİ KOD: $personeller = $pdo->query("SELECT id...
    
    // YENİ KOD: Fonksiyonu çağırıyoruz
    $personeller = aktif_personeller(); 
}

// Liste Sorgusu (Burada değişiklik yok)
if ($yonetici_mi) {
    $sql = "SELECT i.*, p.ad_soyad, s.sebep_adi, a.aciklama_adi 
            FROM personel_izin i
            JOIN personel_bilgileri p ON i.personel_id = p.id
            LEFT JOIN izin_sebepleri s ON i.sebep_id = s.id
            LEFT JOIN izin_aciklamalari a ON i.aciklama_id = a.id
            ORDER BY i.yil DESC, i.sira_no DESC";
    $stmt = $pdo->query($sql);
} else {
    $sql = "SELECT i.*, p.ad_soyad, s.sebep_adi, a.aciklama_adi 
            FROM personel_izin i
            JOIN personel_bilgileri p ON i.personel_id = p.id
            LEFT JOIN izin_sebepleri s ON i.sebep_id = s.id
            LEFT JOIN izin_aciklamalari a ON i.aciklama_id = a.id
            WHERE i.personel_id = ?
            ORDER BY i.yil DESC, i.sira_no DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
}
$izinler = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<style>
    /* Select2 kutusunun içinde uzun yazı varsa alt satıra geçsin */
    .select2-selection__rendered {
        white-space: normal !important;
        line-height: 1.5 !important;
        padding-bottom: 4px;
    }
    .select2-container .select2-selection--single {
        height: auto !important; 
        min-height: 38px;
    }
    .select2-selection__arrow {
        height: 100% !important;
    }
    
    /* Inputları tam genişlik yap */
    .form-control, .form-select { width: 100%; }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-calendar-check"></i> İzin Takip Sistemi</h5>
            <?php if ($yonetici_mi): ?>
            <button class="btn btn-light text-primary fw-bold" onclick="yeniKayitModal()">
                <i class="fas fa-plus"></i> Yeni İzin Girişi
            </button>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="izinTablo" class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Sıra</th>
                            <th>Personel</th>
                            <th>Yıl</th>
                            <th>İzin Sebebi</th>
                            <th>Açıklama</th>
                            <th style="min-width: 150px;">Tarihler</th>
                            <th>Gün</th>
                            <?php if ($yonetici_mi): ?><th>İşlemler</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($izinler as $iz): ?>
                        <tr>
                            <td class="text-center fw-bold"><?php echo $iz['sira_no']; ?></td>
                            <td><?php echo htmlspecialchars($iz['ad_soyad']); ?></td>
                            <td><?php echo $iz['yil']; ?></td>
                            <td><?php echo htmlspecialchars($iz['sebep_adi'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($iz['aciklama_adi'] ?? '-'); ?></td>
                            <td>
                                <?php echo date('d.m.Y', strtotime($iz['izin_baslangic'])); ?> - 
                                <?php echo date('d.m.Y', strtotime($iz['izin_bitis'])); ?>
                            </td>
                            <td class="text-center fw-bold text-danger"><?php echo $iz['gun_sayisi']; ?></td>
                            <?php if ($yonetici_mi): ?>
                            <td class="text-nowrap">
                                <button class="btn btn-primary btn-sm btn-islem" data-tur="duzenle" data-id="<?php echo $iz['id']; ?>"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger btn-sm btn-islem" data-tur="sil" data-id="<?php echo $iz['id']; ?>"><i class="fas fa-trash"></i></button>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="izinModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalBaslik">İzin Formu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4"> <form id="izinForm">
                    <input type="hidden" name="izin_id" id="izin_id">
                    <input type="hidden" name="action" id="action" value="kaydet">

                    <div class="row mb-3">
                        <div class="col-12">
                            <label class="form-label fw-bold fs-5">Personel Seçimi <span class="text-danger">*</span></label>
                            <select class="form-select select2" name="personel_id" id="personel_id" style="width: 100%;" required>
                                <option value="">Seçiniz</option>
                                <?php foreach ($personeller as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['ad_soyad']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div id="bakiye_alani" class="mt-2 text-danger fw-bold fs-5" style="display:none;">
                                <i class="fas fa-info-circle"></i> Kalan Yıllık İzin: <span id="kalan_izin_sayisi">...</span> Gün
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="row mb-3">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">İzin Sebebi <span class="text-danger">*</span></label>
                            <select class="form-select select2" name="sebep_id" id="sebep_id" style="width: 100%;" required>
                                <option value="">Seçiniz</option>
                                <?php foreach ($sebepler as $s): ?>
                                    <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['sebep_adi']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Açıklama <span id="aciklama_zorunlu" class="text-danger">*</span> <small id="aciklama_not" class="text-muted fw-normal">(Zorunlu)</small></label>
                            <select class="form-select select2" name="aciklama_id" id="aciklama_id" style="width: 100%;">
                                <option value="">Seçiniz</option>
                                <?php foreach ($aciklamalar as $a): ?>
                                    <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['aciklama_adi']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-5">
                            <label class="form-label fw-bold">Başlangıç Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control form-control-lg tarih-hesapla" name="izin_baslangic" id="izin_baslangic" required>
                        </div>
                        
                        <div class="col-md-5">
                            <label class="form-label fw-bold">Bitiş Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control form-control-lg tarih-hesapla" name="izin_bitis" id="izin_bitis" required>
                        </div>

                        <div class="col-md-2 d-flex align-items-end">
                            <div class="alert alert-info text-center w-100 mb-0 p-2" id="gun_bilgisi" style="display:none;">
                                <strong><span id="hesaplanan_gun" class="fs-4">0</span></strong> GÜN
                            </div>
                        </div>
                    </div>

                </form>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary btn-lg" data-bs-dismiss="modal">İptal</button>
                <button type="button" class="btn btn-primary btn-lg px-5" onclick="formuGonder()">KAYDET</button>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>

<script>
$(document).ready(function() {
    // Select2'yi modal içinde çalışacak şekilde ve genişliği 100% olacak şekilde ayarla
    $('.select2').select2({ 
        dropdownParent: $('#izinModal'), 
        placeholder: "Seçiniz",
        width: '100%' 
    });
    
    if ($.fn.DataTable) { $('#izinTablo').DataTable({ "language": { "url": "//cdn.datatables.net/plug-ins/1.10.22/i18n/Turkish.json" } }); }

    // 1. PERSONEL SEÇİLİNCE BAKİYE GETİR
    $('#personel_id').change(function() {
        var pid = $(this).val();
        if(pid) {
            $.post('../ajax/ajax_izin_islem.php', { action: 'bakiye_getir', personel_id: pid }, function(res) {
                if(res.status === 'success') {
                    $('#kalan_izin_sayisi').text(res.bakiye);
                    $('#bakiye_alani').fadeIn();
                }
            }, 'json');
        } else {
            $('#bakiye_alani').hide();
        }
    });

    // 2. SEBEP KONTROLÜ
    $('#sebep_id').change(function() {
        var text = $("#sebep_id option:selected").text().toLowerCase();
        if (text.indexOf("yıllık") >= 0 || text.indexOf("yillik") >= 0) {
            $('#aciklama_zorunlu').hide();
            $('#aciklama_id').prop('required', false);
            $('#aciklama_not').text('(Opsiyonel)');
        } else {
            $('#aciklama_zorunlu').show();
            $('#aciklama_id').prop('required', true);
            $('#aciklama_not').text('(Zorunlu)');
        }
    });

    // 3. TARİH HESAPLAMA
    $('.tarih-hesapla').change(function() {
        var bas = new Date($('#izin_baslangic').val());
        var bit = new Date($('#izin_bitis').val());

        if (bas && bit && !isNaN(bas) && !isNaN(bit)) {
            if (bit >= bas) {
                var diffDays = Math.ceil(Math.abs(bit - bas) / (1000 * 60 * 60 * 24)) + 1;
                $('#hesaplanan_gun').text(diffDays);
                $('#gun_bilgisi').removeClass('alert-danger').addClass('alert-info').show();
            } else {
                $('#hesaplanan_gun').text('!');
                $('#gun_bilgisi').removeClass('alert-info').addClass('alert-danger').show();
            }
        } else {
            $('#gun_bilgisi').hide();
        }
    });

    // 4. İŞLEMLER
    $(document).on('click', '.btn-islem', function() {
        var tur = $(this).data('tur');
        var id = $(this).data('id');

        if (tur === 'sil') {
            if(confirm('İzin kaydını silmek istediğinize emin misiniz?')) {
                $.post('../ajax/ajax_izin_islem.php', { action: 'sil', id: id }, function(res) {
                    alert(res.message); if(res.status=='success') location.reload();
                }, 'json');
            }
        } else if (tur === 'duzenle') {
            $.post('../ajax/ajax_izin_islem.php', { action: 'detay_getir', id: id }, function(res) {
                if(res.status == 'success') {
                    $('#izinForm')[0].reset();
                    $('#izin_id').val(res.data.id);
                    $('#action').val('kaydet');
                    
                    $('#personel_id').val(res.data.personel_id).trigger('change');
                    $('#sebep_id').val(res.data.sebep_id).trigger('change');
                    $('#aciklama_id').val(res.data.aciklama_id).trigger('change');
                    $('#izin_baslangic').val(res.data.izin_baslangic);
                    $('#izin_bitis').val(res.data.izin_bitis);

                    $('#izin_baslangic').trigger('change');
                    
                    $('#modalBaslik').text('İzin Düzenle');
                    $('#izinModal').modal('show');
                }
            }, 'json');
        }
    });
});

function yeniKayitModal() {
    $('#izinForm')[0].reset();
    $('#izin_id').val('');
    $('#action').val('kaydet');
    $('.select2').val(null).trigger('change');
    $('#gun_bilgisi').hide();
    $('#bakiye_alani').hide();
    $('#modalBaslik').text('Yeni İzin Girişi');
    $('#izinModal').modal('show');
}

function formuGonder() {
    if(!$('#personel_id').val() || !$('#sebep_id').val() || !$('#izin_baslangic').val() || !$('#izin_bitis').val()) {
        alert("Zorunlu alanları doldurunuz."); return;
    }
    if($('#aciklama_id').prop('required') && !$('#aciklama_id').val()) {
        alert("Açıklama seçmelisiniz."); return;
    }
    
    $.post('../ajax/ajax_izin_islem.php', $('#izinForm').serialize(), function(res) {
        if(res.status === 'error') {
            alert(res.message);
        } else {
            alert(res.message); location.reload();
        }
    }, 'json');
}
</script>