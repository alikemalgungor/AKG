<?php
$host = "localhost";
$dbname = "gorev_takip";
$username = "root";
$password = "";

// Değişken adını $pdo olarak değiştiriyoruz.
$pdo = null; 

try {
    // Bağlantı nesnesini $pdo'ya atıyoruz.
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Bağlantı başarılıysa $pdo doldurulur.
    
} catch (PDOException $e) {
    // Bağlantı hatası olursa $pdo null kalır.
    // error_log("Veritabanı bağlantı hatası: " . $e->getMessage()); 
    $pdo = null; 
    
    // UYARI: Eğer bağlantı başarısızsa, sayfaların çalışmasını engellemek için
    // burada bir 'die' veya 'exit' komutu kullanmak en güvenli yoldur.
    // die("Veritabanı bağlantısı kurulamadı: " . $e->getMessage());
}
?>