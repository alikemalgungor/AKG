<?php 
// includes/navbar.php

// Sayfa başlıkları ve ilgili sayfaların dosya adları
// 'submenu' anahtarı varsa o bir Dropdown (Açılır) menüdür.
$menu_items = [
    'Ana Sayfa'       => ['link' => 'anasayfa.php', 'icon' => 'fas fa-home'],
    
    // İşlem Menüleri
    'Arazi Görev'     => ['link' => 'arazi_gorev.php', 'icon' => 'fas fa-tree'],
    'Resmî Araç'      => ['link' => 'resmi_arac_gorev.php', 'icon' => 'fas fa-car'],
    'Özel Araç'       => ['link' => 'ozel_arac_gorev.php', 'icon' => 'fas fa-car-side'],
    
    // Dropdown: RAPORLAR
    'Raporlar' => [
        'icon' => 'fas fa-chart-bar',
        'submenu' => [
            'Araç Görev Listesi (Excel)' => 'rapor_arac_gorev.php',
            // İleride eklenecekler:
            // 'Personel Performans' => 'rapor_personel.php',
        ]
    ],

    // Dropdown: TANIMLAMALAR (Ayarlar)
    'Tanımlamalar' => [
        'icon' => 'fas fa-cogs',
        'submenu' => [
            'Araç Listesi & Ekle'    => 'tanim_araclar.php',
            'Personel Listesi'       => 'tanim_personel.php',
            'Görev Türleri'          => 'tanim_gorev_turleri.php',
            'Kurum Ayarları'         => 'tanim_kurum.php',
        ]
    ],
];

// O anki sayfanın adını alıyoruz
$current_page = basename($_SERVER['PHP_SELF']); 
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="../pages/anasayfa.php">
            <i class="fas fa-tasks me-2"></i>Görev Takip
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <?php foreach ($menu_items as $title => $item): ?>
                    
                    <?php if (isset($item['submenu'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown_<?php echo md5($title); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php if(isset($item['icon'])): ?><i class="<?php echo $item['icon']; ?> me-1"></i><?php endif; ?>
                                <?php echo $title; ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown_<?php echo md5($title); ?>">
                                <?php foreach ($item['submenu'] as $subTitle => $subLink): ?>
                                    <?php 
                                        $isActive = ($current_page == $subLink) ? 'active' : ''; 
                                        // Eğer link boşsa veya # ise tıklanmasın
                                        $href = ($subLink == '#' || empty($subLink)) ? '#' : "../pages/$subLink";
                                    ?>
                                    <li>
                                        <a class="dropdown-item <?php echo $isActive; ?>" href="<?php echo $href; ?>">
                                            <?php echo $subTitle; ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>

                    <?php else: ?>
                        <?php 
                            $active_class = ($current_page == $item['link']) ? 'active' : '';
                        ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $active_class; ?>" href="../pages/<?php echo $item['link']; ?>">
                                <?php if(isset($item['icon'])): ?><i class="<?php echo $item['icon']; ?> me-1"></i><?php endif; ?>
                                <?php echo $title; ?>
                            </a>
                        </li>
                    <?php endif; ?>

                <?php endforeach; ?>
                
            </ul>
            
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link btn btn-danger text-white btn-sm px-3 ms-2" href="../logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i> Çıkış
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>