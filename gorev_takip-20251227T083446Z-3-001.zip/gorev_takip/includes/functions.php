<?php

/**
 * Veritabanından gelen tarih değerini DD.MM.YYYY formatına dönüştürür.
 * Tarih boş veya geçersiz ise kısa çizgi (-) döndürür.
 * * @param string $tarih YYYY-MM-DD formatındaki tarih dizesi.
 * @return string Biçimlendirilmiş tarih veya '-'.
 */
function tarih_formatla($tarih) {
    // Tarihin boş, NULL veya geçersiz (0000-00-00) olup olmadığını kontrol et
    if (empty($tarih) || $tarih === '0000-00-00' || $tarih === NULL) {
        return '-';
    }
    
    // Geçerli bir tarih dizesi ise istenen formata dönüştür
    $timestamp = strtotime($tarih);
    if ($timestamp === false) {
        // Tarih dizesi geçersizse
        return '-';
    }
    
    return date('d.m.Y', $timestamp);
}
$current_page = $_SERVER['REQUEST_URI']; 
$current_file = basename($current_page); 

// Menü öğeleri için aktif sınıf kontrolü fonksiyonu
// (Eğer fonksiyon isminiz çakışıyorsa bu ismi değiştirebiliriz)
if (!function_exists('is_active')) {
    function is_active($file_name, $current_file) {
        return ($file_name === $current_file) ? 'active' : '';
    }
}

/* * YETKİ KONTROL FONKSİYONU
 * Kullanımı: yetki_kontrol([1, 2]); // Sadece Admin ve Müdür girebilir.
 */
function yetki_kontrol($izin_verilen_roller) {
    // 1. Kullanıcı giriş yapmış mı?
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['rol_id'])) {
        header("Location: ../index.php");
        exit;
    }

    // 2. Kullanıcının rolü, izin verilenler listesinde var mı?
    // Session'daki rol_id string gelebilir, (int) ile sayıya çeviriyoruz.
    $kullanici_rolu = (int)$_SESSION['rol_id'];

    if (!in_array($kullanici_rolu, $izin_verilen_roller)) {
        // YETKİSİZ GİRİŞ!
        // Şık bir hata sayfası veya mesajı gösterip kodu durduruyoruz.
        echo '<!DOCTYPE html>
        <html lang="tr">
        <head>
            <meta charset="UTF-8">
            <title>Erişim Engellendi</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">
            <div class="card shadow text-center p-5" style="max-width: 500px;">
                <div class="card-body">
                    <h1 class="text-danger display-1"><i class="fas fa-ban"></i></h1>
                    <h2 class="card-title text-danger">Yetkisiz Erişim!</h2>
                    <p class="card-text lead">Bu sayfayı görüntülemek için yetkiniz (Rol ID: '.$kullanici_rolu.') yeterli değil.</p>
                    <a href="../anasayfa.php" class="btn btn-primary mt-3">Ana Sayfaya Dön</a>
                </div>
            </div>
        </body>
        </html>';
        exit; // Kodun geri kalanını okutma!
    }
}

function aktif_personeller($ekKosul = "") {
    global $pdo;

    $sql = "SELECT id, ad_soyad
            FROM personel_bilgileri
            WHERE aktif = 1";

    if (!empty($ekKosul)) {
        $sql .= " AND $ekKosul";
    }

    $sql .= " ORDER BY ad_soyad";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Diğer genel amaçlı fonksiyonlarınız buraya eklenecektir.
?>

