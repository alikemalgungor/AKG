<?php
// includes/header.php

// 1. OTURUM BAŞLATMA
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. AKILLI YOL AYARI (PATH SYSTEM)
$yol = (isset($derinlik) && $derinlik == true) ? '../../' : '../';

// 3. GİRİŞ KONTROLÜ
if (!isset($_SESSION['user_id'])) {
    header("Location: " . $yol . "index.php");
    exit();
}

// 4. VERİTABANI VE FONKSİYONLAR
include_once $yol . 'config/db.php';

if (file_exists($yol . 'includes/functions.php')) {
    include_once $yol . 'includes/functions.php';
}

// Aktif Menü İçin Helper Değişkenler
$current_page = $_SERVER['REQUEST_URI']; 
$current_file = basename($current_page); 
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Görev Takip Sistemi</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.7/css/dataTables.bootstrap5.min.css">
    
    <link rel="stylesheet" href="<?php echo $yol; ?>assets/css/style.css"> 

    <style>
        body { background-color: #f8f9fa; }
        .page-content { padding-bottom: 50px; }
        
        /* Select2 ve Bootstrap Uyumsuzluk Düzeltmeleri */
        .select2-container .select2-selection--single { height: 38px !important; padding-top: 5px !important; }
        .select2-container--default .select2-selection--single .select2-selection__arrow { height: 36px !important; }
        
        /* Navbar Stilleri */
        .navbar-brand { font-weight: bold; letter-spacing: 1px; }
        .nav-link { font-weight: 500; }
        .dropdown-item.active, .dropdown-item:active { background-color: #0d6efd; }
    </style>
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo $yol; ?>anasayfa.php">
                <i class="fas fa-tasks me-2"></i>Görev Takip
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= is_active('anasayfa.php', $current_file) ?>" href="<?php echo $yol; ?>anasayfa.php">Ana Sayfa</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?= is_active('puantaj.php', $current_file) ?>" href="<?php echo $yol; ?>pages/puantaj.php">Puantaj İşlemleri</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?= is_active('resmi_arac_gorev.php', $current_file) ?>" href="<?php echo $yol; ?>pages/resmi_arac_gorev.php">Resmî Araç</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= is_active('ozel_arac_gorev.php', $current_file) ?>" href="<?php echo $yol; ?>pages/ozel_arac_gorev.php">Özel Araç</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link <?= is_active('izin_takip.php', $current_file) ?>" href="<?php echo $yol; ?>pages/izin_takip.php">İzin Takip</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="raporlarDropdown" role="button" data-bs-toggle="dropdown">
                            Raporlar
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/raporlar/rapor_puantaj.php"><i class="fas fa-file-invoice me-2"></i>Aylık Puantaj Raporu</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/raporlar/rapor_arac_gorev.php">Resmi Araç Raporu</a></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/raporlar/rapor_ozel_arac.php">Özel Araç Raporu</a></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/raporlar/rapor_izin.php">Personel İzin Raporu</a></li>
                        </ul>
                    </li>

                    <?php if (isset($_SESSION['rol_id']) && $_SESSION['rol_id'] == 1): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="tanimDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-cog"></i> Yönetim
                        </a>
                        <ul class="dropdown-menu">
                            <li><h6 class="dropdown-header">Tanımlamalar</h6></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/tanim_araclar.php">Araç Tanımları</a></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/tanim_personel.php">Personel Listesi</a></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/tanim_kurum.php">Kurum Ayarları</a></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>pages/tanim_gorev_turleri.php">Görev Türleri</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo $yol; ?>admin/kullanicilar.php">Kullanıcı Yönetimi</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link btn btn-sm btn-outline-danger text-light border-0" href="<?php echo $yol; ?>logout.php">
                            <i class="fas fa-sign-out-alt"></i> Çıkış
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <main class="page-content">